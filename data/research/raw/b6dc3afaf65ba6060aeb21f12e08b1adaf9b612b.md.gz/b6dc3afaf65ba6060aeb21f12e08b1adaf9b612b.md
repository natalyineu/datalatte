Title: Q2 2026 CTV Market Update for Small Businesses

URL Source: https://adwave.com/resources/q2-2026-ctv-market-report-small-business

Published Time: 2026-07-05T00:00:00+00:00

Markdown Content:
If you run a small business and you've been wondering whether streaming TV advertising is worth paying attention to, the second quarter of 2026 settled the question. Streaming isn't the future of television anymore, it's the present, and by a wider margin than most people realize. The data from Q2 tells a clear story: audiences have moved to streaming, the money is following them, and the cost of reaching those audiences has dropped to a point that finally makes sense for a local business.

Though: most of the coverage of this shift is written for media buyers at big agencies, not for the owner of a plumbing company or a boutique or a dental practice. So let's break down what happened in the CTV market this quarter, and more importantly, what it means for you. We'll cover where audiences are watching, who's winning, how much the ad market is growing, and why the economics have tipped in favor of small advertisers.

## The headline: streaming now more than doubles cable

The single most important number this quarter comes from Nielsen's The Gauge, the monthly measure of what Americans watch on their TV sets. In April 2026, the most recent month measured, streaming took 47.6% of all U.S. TV viewing, while cable held just 21.6% and broadcast 19.9%, according to Nielsen. (Source: Nielsen, The Gauge, April 2026.)

Sit with that for a second. Streaming now pulls more viewing than cable and broadcast combined. Less than four years ago, streaming and cable were roughly tied. Today streaming more than doubles cable, and the gap keeps widening. For a small business, this is the whole ballgame: the audience you want to reach is spending nearly half their TV time on streaming, and that share climbs every quarter.

This matters because advertising follows attention. When people watched cable, cable was where you advertised, if you could afford it. Now that people watch streaming, streaming is where the attention is, and unlike old cable buys, streaming ads can be targeted to your local area and bought on a small-business budget.

![Image 1: Q2 2026 CTV Market Report - Body1](https://media.adwave.com/fia320z3blxi/TkrO3Tsjx1aUAPLQiWJpv/e019c3f55b34fc8b3878c308e5051a56/body1.png)
## Who's winning the screen: YouTube, then everyone else

Among streaming services, Q2 confirmed a clear pecking order. YouTube held 13.4% of all U.S. TV viewing in April 2026, making it the single most-watched service on American television, ahead of any cable network or broadcaster, per Nielsen's The Gauge. Disney's streaming and networks combined put it second among media companies at 10.3%, and Netflix was the second most-watched individual service at 7.8%. No other single service cracked 5%. (Source: Nielsen, The Gauge, April 2026.)

The takeaway for a small business isn't to obsess over which platform is on top. It's that the streaming audience is spread across many services, YouTube, Netflix, Hulu, Roku's channel, Peacock, Tubi, and more, which is exactly why buying them one by one makes no sense for a local advertiser. The smart approach is to run your ad across a bundle of premium streaming channels at once, so you reach viewers wherever they happen to be watching, rather than betting on a single app.

That YouTube leads is especially relevant, because it means video advertising increasingly plays on the living-room TV screen, not just phones. A well-made 30-second ad now reaches people in the same full-screen, lean-back setting that made traditional TV so powerful, at a fraction of the old cost.

## Cord-cutting crossed a point of no return

The viewing shift is powered by a structural change in how households pay for TV. In 2026, an estimated 80.7 million U.S. households have either cut the cord or never had cable, outnumbering the households that still pay for traditional TV by more than 25 million, according to eMarketer. Traditional pay-TV now reaches only around 42% of households, down from roughly 88% in 2010. (Source: eMarketer, 2026.)

As more households watch streaming, include it when planning how to reach a broad local audience.

![Image 2: Q2 2026 CTV Market Report - Body2](https://media.adwave.com/fia320z3blxi/6EQpADvt0zhaheTcKyZyhj/2a24bc1bd28bb4aa860f3777b5b6a2ef/body2.png)
Where audiences go, ad budgets follow, and Q2 data shows the money moving fast. The U.S. connected TV advertising market is on track to reach $37.95 billion in 2026, up roughly 15% from a year earlier, according to eMarketer. And in a milestone that would have seemed impossible a decade ago, streaming outsold primetime broadcast and cable in the 2026 upfront negotiations for the first time. (Source: eMarketer, 2026.)

A 15% annual growth rate in a market this size tells you where the industry's conviction is. Big brands are shifting serious money from traditional TV into streaming, which validates the channel and pours investment into better ad tools, measurement, and inventory, the kind of infrastructure that eventually benefits small advertisers too.

But here's the part that matters most for you: this growth is no longer just a big-brand story. The same platforms and technology that let a national brand run streaming ads now let a local business do the same thing, in a single metro, on a small budget. The tools built for the enterprise have trickled down.

## The economics finally favor small businesses

The most important development for a small business isn't the audience or the ad-spend growth, it's the price. The average connected TV CPM (cost per thousand impressions) in 2026 sits around $26 blended across the market, with most campaigns landing in the $25 to $35 range, and critically, that price has been falling as a flood of new streaming ad inventory has come online.

Falling CPMs mean your ad dollar buys more impressions than it did a year or two ago. Combine that with two other shifts, the ability to target a single local area instead of buying a whole market, and AI tools that generate a broadcast-quality 30-second ad in minutes for free, and the entire cost structure of TV advertising has been rewritten. The two barriers that kept small businesses off TV for decades, huge minimum ad buys and expensive production, have both fallen away.

Streaming's growth coincides with lower entry costs for small advertisers. See our guide to the [average CTV CPM](https://adwave.com/resources/average-ctv-cpm) for advertising costs.

![Image 3: Q2 2026 CTV Market Report - Body3](https://media.adwave.com/fia320z3blxi/1Z0E5PD1SSCojdq8cCFmZ1/549747308f17171117ada72abe84f160/body3.png)
## What this means for your business

Pulling the quarter together, here's what the CTV market update means in practical terms for a small business owner:

*   **Your audience is on streaming.** Nearly half of all TV viewing is now streaming, and it grows every quarter. If you want to reach people on TV, that's where they are.

*   **Traditional TV alone won't cut it.** With pay-TV down to ~42% of households, cable and broadcast reach a shrinking, older slice of your market.

*   **You don't have to pick a platform.** The audience is spread across many services, so the winning move is to run across a bundle of premium streaming channels at once.

*   **The price is right.** Falling CPMs, local targeting, and free AI ad creation mean connected TV now fits budgets that could never touch TV before.

*   **It works best alongside your other channels.** Connected TV builds the awareness that makes your Google and social ads convert better, the core idea behind [multi-channel advertising](https://adwave.com/resources/multi-channel-advertising-for-small-business).

Compared with our [Q1 2026 CTV market report](https://adwave.com/resources/q1-2026-ctv-market-report-small-business), the direction of travel is unchanged and, if anything, accelerating: more streaming, less cable, more ad dollars, lower prices. The trend that's been building for years has become the settled reality of how TV works.

## Common questions answered

**How much of TV viewing is streaming in 2026?** As of April 2026, streaming accounted for 47.6% of all U.S. TV viewing, according to Nielsen's The Gauge, compared with 21.6% for cable and 19.9% for broadcast. That means streaming now pulls more viewing than cable and broadcast combined, and its share continues to grow each quarter. For advertisers, it confirms that the TV audience has largely moved to streaming.

**What is the most-watched streaming service right now?** YouTube is the most-watched single service on U.S. television, with 13.4% of all TV viewing in April 2026 per Nielsen's The Gauge, ahead of any cable network or broadcaster. Netflix is the second most-watched individual streaming service at 7.8%. Because viewing is spread across many services, most small businesses benefit from advertising across a bundle of streaming channels rather than picking one.

**How big is the connected TV advertising market in 2026?** The U.S. connected TV advertising market is projected to reach about $37.95 billion in 2026, up roughly 15% from the prior year, according to eMarketer. Streaming also outsold primetime broadcast and cable in the 2026 upfronts for the first time. This growth reflects advertisers following audiences from traditional TV to streaming.

**Is connected TV advertising affordable for a small business?** Yes, and increasingly so. The average CTV CPM in 2026 is around $26, with most campaigns in the $25 to $35 range, and prices have been falling as new ad inventory comes online. Combined with local targeting and free AI-generated ad creative, connected TV now fits small-business budgets in a way traditional TV never did. You can run a campaign in a single local market rather than buying an entire region.

**Should small businesses still advertise on cable TV?** For most small businesses, connected TV is the better use of a TV advertising budget, because traditional pay-TV now reaches only around 42% of households and skews older. Streaming reaches the majority of households, offers local targeting, and costs less to enter. Cable may still make sense for certain audiences, but it should no longer be the default way a small business thinks about TV.

## The bottom line

Q2 2026 didn't reveal a new trend so much as confirm, at scale, one that's been building for years: streaming has decisively won the TV audience, ad budgets are pouring in, cord-cutting has passed the point of no return, and the cost of running connected TV ads has dropped to small-business levels. For a local business, the strategic question is no longer "should I consider streaming TV?" It's "how soon can I get on it while my competitors are still figuring it out?"

Adwave makes that easy: generate a 30-second video ad from your website, then run it across 100+ premium streaming channels with local targeting, all from one place. See [how Adwave works](https://adwave.com/how-it-works), or check [pricing](https://adwave.com/pricing) to get started from $30 a day.
