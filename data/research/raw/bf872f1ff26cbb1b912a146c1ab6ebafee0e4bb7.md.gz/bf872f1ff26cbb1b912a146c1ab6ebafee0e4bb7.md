Title: What is Peacock’s share of TV viewing? (Q2 2026)

URL Source: https://adwave.com/resources/peacock-tv-viewing-share-q2-2026

Published Time: 2026-07-21T00:00:00+00:00

Markdown Content:
*   1.2%

Peacock's share of U.S. TV viewing (April 2026, Nielsen The Gauge)

*   46M

Peacock paid subscribers (Q1 2026, Comcast)

*   $50

Minimum to start advertising on connected TV with Adwave

Peacock, NBCUniversal's streaming service, held **1.2% of all U.S. TV viewing in April 2026**, according to Nielsen's The Gauge. That's a modest number on its own, but it hides one of the most dramatic swings in streaming: just two months earlier, in February 2026, Peacock hit a platform-best 3.0% of all TV viewing, its highest share ever, powered by Super Bowl LX and the Winter Olympics. Then it settled back to 1.2% by April.

That volatility tells you everything about Peacock's strategy and what it means for advertisers. Peacock is a sports-and-events machine, spiking when NBC's marquee properties are live and normalizing between them. It just added the NBA, crossed 46 million subscribers, and runs one of the most ad-supported subscriber bases in streaming. Let's break down Peacock's Q2 2026 share, the sports engine behind it, and what it means for reaching customers.

## What the data shows

[Nielsen's The Gauge](https://www.nielsen.com/data-center/the-gauge/) measures how Americans split their TV time. In the [April 2026 report](https://www.nielsen.com/news-center/2026/sports-and-dramas-drive-april-viewing-patterns-in-nielsens-latest-gauge-reports/), released June 25, 2026, Peacock held 1.2% of total TV viewing, up about 0.3 points from a year earlier.

Here's where Peacock sits among streaming services in April 2026:

*   **YouTube:** 13.4% (the leader)

*   **Netflix:** 7.8%

*   **Amazon Prime Video:** 4.2%

*   **Tubi 2.3%, Paramount+ 2.1%, Max 1.5%, Peacock 1.2%**

In April, Peacock ranked behind Paramount+, Tubi, and Max among named streaming services. But that April snapshot undersells Peacock, because Peacock's whole model is built around spikes. In February 2026, it reached a platform-best 3.0% of all TV viewing, a 64% jump in a single month and its highest share in the five-year history of the Gauge, on the back of Super Bowl LX and the Milano-Cortina Winter Olympics. Two months later, with those events over, it was back to 1.2%. Our [most-watched streaming service](https://adwave.com/resources/most-watched-streaming-service-q1-2026) rankings show how the field looks in a normal month.

That 1.2% sits inside a streaming category that hit a record 47.6% of TV viewing in April 2026. Peacock is a smaller piece of that pie between tentpoles, but a much bigger one when the sports calendar heats up.

![Image 1: What is Peacock's share of TV viewing? (Q2 2026) - Body1](https://media.adwave.com/fia320z3blxi/7um0a9yhuwK42hQf1rMh4M/87c9c2c58d0f186f121a25b1d059e845/body1.png)
## How Nielsen measures this, and why April is the latest number

Peacock's 1.2% comes from Nielsen's national panel, the same measurement behind its TV ratings, tracking actual viewing on TV sets. It's reported as its own streaming service.

A few points help you read it correctly:

*   **April 2026 is the latest confirmed month.** Nielsen delayed its March Gauge amid a methodology dispute, and a recalibrated version is expected in the fall, which may trim streaming shares slightly. Every figure here reflects data through April 2026.

*   **The February spike was real and huge.** Peacock's jump to 3.0% in February was Nielsen-reported, driven by the Super Bowl and Olympics. It's the clearest example in streaming of how live events move a platform's share.

*   **April is the normalization month.** With the tentpoles over, April is the first clean, ordinary month, which is why 1.2% is the right figure for Peacock's baseline rather than its peak.

The takeaway is that Peacock's share is unusually event-driven. To understand it, you have to look at both the spikes and the baseline, because Peacock lives on the swing between them.

## Breaking down the numbers

Peacock's viewing share is volatile, but its business is growing steadily underneath. The subscriber numbers tell that story.

Here's Peacock's scale as of Comcast's most recent report:

*   **46 million paid subscribers** at the end of the first quarter of 2026, its best quarter to date

*   **Up 5 million** year over year, and up 2 million from the prior quarter

*   **A record 4.9 million subscribers added in February 2026 alone**, its largest single-month gain ever, on the Super Bowl, Olympics, and NBA All-Star

That February subscriber surge is the same story as the viewing spike: live events don't just lift Peacock's viewing for a month, they pull in subscribers who stay. Peacock's revenue crossed $2 billion in the quarter, up 71% year over year, and its losses are narrowing as sports drive scale. Our [Peacock subscriber count](https://adwave.com/resources/peacock-subscriber-count) page tracks the growth in detail.

Major events bring new subscribers to Peacock, and some stay for other programming. Its viewing share can fluctuate between events even as subscriptions grow.

The single biggest change in Peacock's trajectory is the NBA. Starting with the 2025-26 season, the NBA returned to NBC and Peacock under an eleven-year agreement, bringing roughly 50 exclusive national games a year to the streaming service. Combined with NFL Sunday Night Football, the Olympics, Premier League soccer, and WWE, Peacock has assembled one of the deepest live-sports lineups in streaming. Our [live sports share of TV viewing](https://adwave.com/resources/live-sports-tv-viewing-share) page explains why that inventory is so valuable.

## The sports strategy behind the swings

Peacock's volatile viewing share isn't an accident, it's the direct result of a deliberate strategy: build a streaming service around live sports and events. Understanding that strategy explains both the spikes and why they matter for advertisers.

NBCUniversal bet that live sports would be the thing that drives subscribers and viewing to streaming, and it backed that bet with money. Consider what Peacock has assembled:

*   **The NBA**, back on NBC and Peacock for the 2025-26 season under an eleven-year deal worth roughly $2.45 billion a year, with around 50 exclusive national games annually

*   **The Olympics**, with Peacock as the streaming home for both Summer and Winter Games, which drove February 2026's record spike

*   **NFL Sunday Night Football**, one of the most-watched programs on all of television

*   **Premier League soccer and WWE**, adding year-round live inventory beyond the major seasons

The logic is that live sports is the last category traditional TV reliably owned, the one thing that kept viewers tethered to cable. By moving it to streaming, Peacock pulls that audience onto the connected screen and, importantly, into an ad-supported environment. Every Super Bowl, Olympics, and NBA game on Peacock is premium, live, unskippable inventory that used to exist only on broadcast and cable. For the connected TV ad market, this migration is enormous: it moves the most valuable advertising moments in television onto a platform built for digital targeting and measurement. Peacock's spiky share is really a map of where premium sports inventory is moving.

## Why it matters for your business

Peacock is one of the most advertiser-friendly streaming services, for two specific reasons: almost everyone on it sees ads, and much of what they watch is live sports.

Here's what makes Peacock valuable for advertisers:

*   **Most subscribers are on the ad tier.** By most estimates, roughly four out of five Peacock subscribers are on an ad-supported plan, one of the highest ad-tier adoption rates among major streamers. That means a large, addressable audience watching with ads.

*   **Premium live-sports inventory.** The NBA, NFL Sunday Night Football, the Olympics, and Premier League give Peacock the kind of live, DVR-proof, full-attention inventory that advertisers prize most. Live sports ads can't be skipped and command premium engagement.

*   **Event-driven reach spikes.** When Peacock carries a Super Bowl or Olympics, its audience balloons, offering moments of massive reach that few streaming services can match.

Now the practical part. Advertisers access Peacock's inventory through NBCUniversal's ad-buying platform, which is built primarily for larger brands and agencies. A small business generally won't buy Peacock directly. What changed for smaller advertisers is broader: Peacock's heavily ad-supported model, and the migration of premium sports to streaming, are part of why [connected TV advertising](https://adwave.com/resources/what-is-connected-tv-advertising) has become a rich, accessible market. Peacock proved that premium sports audiences will watch with ads on streaming, and that audience is reachable across the connected TV ecosystem at small-business budgets.

![Image 2: What is Peacock's share of TV viewing? (Q2 2026) - Body2](https://media.adwave.com/fia320z3blxi/7zFlVGyl9zTRwQZ6RpiZFP/7d98e50f4af88ec6b799b4cb284cd044/body2.png)
## How to take advantage

You won't buy a Peacock Super Bowl slot for $50, but you can reach the same premium, sports-loving, ad-supported streaming audience that Peacock cultivated, across the broader connected TV ecosystem at a local budget. Here's how to think about it.

*   **Reach the audience across services.** Peacock viewers also watch YouTube, Tubi, Roku channels, and more. Running across the whole ecosystem builds the frequency any single service can't.

*   **Match your service area.** Set a geographic radius, usually 15 to 25 miles, so every impression reaches a potential customer nearby.

*   **Budget for repetition.** Plan enough spend to reach the same households several times over two to three weeks. On connected TV, meaningful frequency costs hundreds of dollars, not thousands.

*   **Let AI make the ad.** You don't need a studio. AI tools turn your existing website into a broadcast-quality 30-second ad in about two minutes.

*   **Measure brand lift.** Track branded search, direct traffic, and calls during and after a campaign rather than chasing clicks.

The mechanics are simple. With Adwave, ad creation is free, a campaign starts at a $30-a-day minimum, and you can be live across 100+ premium streaming channels in under 10 minutes. You point it at your website, it builds the spot, and you're reaching the premium living-room audience that services like Peacock helped make mainstream. For what that budget buys, our guide to the [average CTV CPM](https://adwave.com/resources/average-ctv-cpm) lays out the costs.

![Image 3: What is Peacock's share of TV viewing? (Q2 2026) - Body3](https://media.adwave.com/fia320z3blxi/4rGm6hnOgIpANICVs1VcMz/18b244334483106e4de452259f881ac3/body3.png)
## The bigger picture

Peacock's Q2 2026 numbers, a 1.2% baseline that spikes to 3.0% around big events, capture a service betting its future on live sports, and that bet is reshaping where premium sports inventory lives.

A few forces give the numbers their weight:

*   **Sports is migrating to streaming.** The NBA's return to NBC and Peacock, alongside deals moving other leagues to streaming, is pulling the most valuable TV inventory onto connected TV. Peacock is at the center of that shift. Every game that moves to streaming is more premium ad inventory on the connected screen.

*   **Ad-supported is the model.** With roughly four in five Peacock subscribers on the ad tier, Peacock reinforces the industry-wide truth that viewers accept ads on premium streaming, including for live sports. That acceptance is the foundation of affordable [connected TV advertising](https://adwave.com/resources/ctv-advertising-market-size-q1-2026).

*   **The business is scaling.** Peacock's revenue crossed $2 billion in a quarter and its losses are narrowing, showing that a sports-and-events streaming strategy can build a real, growing business, one that keeps investing in the content that draws audiences.

It's worth noting the corporate reshuffling behind Peacock, because it signals how central streaming has become. In early 2026, NBCUniversal spun off most of its cable networks into a separate company, keeping Peacock, NBC, and NBC Sports at the core, and by mid-2026 Comcast had announced a further separation to concentrate on its streaming and entertainment assets. The direction of all this corporate maneuvering is clear: the legacy players are reorganizing themselves around streaming and sports, shedding the declining cable bundle to focus on the connected future. Peacock is the streaming vehicle at the center of NBCUniversal's version of that bet.

For small businesses, the throughline is that Peacock helped move premium sports and events, the last stronghold of traditional TV, onto streaming. The audience that used to watch the big game on cable now increasingly watches it on a connected TV, where advertising is targeted, measurable, and open to businesses of every size. Peacock's spikes are a preview of a future where all the biggest moments in television happen on the connected screen.

## What experts are saying

Analysts see Peacock as the clearest example of the sports-driven streaming strategy. By securing the NBA, the Olympics, and NFL Sunday Night Football, NBCUniversal positioned Peacock to capture the live inventory that anchors premium ad sales, even at the cost of near-term losses. When Peacock added a record 4.9 million subscribers in a single month around the Super Bowl and Olympics, and crossed $2 billion in quarterly revenue, observers read it as validation that live sports drives streaming growth like nothing else.

The consensus is that Peacock's volatility is a feature, not a bug: it's the signature of a service built around appointment television. For advertisers, the takeaway is that Peacock delivers a heavily ad-supported audience and scarce live-sports inventory, some of the most valuable placements in all of media. Even advertisers who reach this audience indirectly, through the broader connected TV ecosystem, benefit from the fact that Peacock and its peers moved premium sports to streaming, expanding the pool of high-value, ad-supported inventory that makes connected TV work for businesses of every size.

## What the numbers don't tell you

Peacock's figures require careful reading, so keep a few caveats in mind.

*   **The 1.2% is a baseline, not a peak.** Peacock spikes dramatically around events, to 3.0% in February 2026. Judging Peacock only by a quiet month like April understates its reach during tentpoles.

*   **Subscriber numbers are current, viewing share lags.** Peacock's 46 million subscribers reflect Q1 2026, its best quarter. The 1.2% viewing share is a single month that happened to fall between big events.

*   **The fall recalibration may trim the number.** Nielsen's coming methodology change is expected to reduce measured streaming shares slightly, so 1.2% could edge down later in 2026.

*   **Ad-tier percentages are estimates.** The roughly four-in-five ad-tier figure comes from third-party trackers, not Peacock, and estimates vary. Read it as a strong directional signal.

Read Peacock's numbers as proof of a sports-first strategy working: a growing, heavily ad-supported subscriber base and a viewing share that swings with the biggest events in television.

## Common questions answered

**What is Peacock's share of TV viewing?** Peacock held 1.2% of U.S. TV viewing in April 2026, per Nielsen's The Gauge, up about 0.3 points year over year. That's a baseline figure, though. Peacock spiked to a platform-best 3.0% in February 2026 on the Super Bowl and Winter Olympics before normalizing, so its share swings sharply with the sports calendar.

**Why does Peacock's viewing spike and drop?** Live events. Peacock carries NBC's marquee sports and events, the Super Bowl, the Olympics, the NBA, and NFL Sunday Night Football, so its viewing surges when those are live and settles between them. February 2026's 3.0% share came from the Super Bowl and Olympics; by April, with those over, it was back to 1.2%. This pattern is by design: Peacock's whole strategy is built around live sports and events, which draw huge audiences in bursts rather than steady month-to-month viewing like a catalog service.

**How many subscribers does Peacock have?** Peacock reached 46 million paid subscribers at the end of the first quarter of 2026, its best quarter to date, up 5 million year over year. It added a record 4.9 million subscribers in February 2026 alone, driven by the Super Bowl, Olympics, and NBA All-Star.

**Can a small business advertise on Peacock?** Peacock's ad inventory is sold primarily through NBCUniversal's platform, built for larger brands. Most small businesses reach the same premium, ad-supported streaming audience more simply through connected TV platforms. With Adwave, you can run 30-second ads across 100+ premium channels from a $30-a-day minimum.

**How much does streaming TV advertising cost?** The [average CTV CPM](https://adwave.com/resources/average-ctv-cpm) runs roughly $15 to $35, and with Adwave a campaign starts at a $30-a-day minimum with free ad creation. That reaches the premium living-room audiences that Peacock and the wider streaming shift created, without a national-brand budget.

## The numbers at a glance

Key figures behind Peacock's Q2 2026 standing, with sources:

*   **1.2%**: Peacock's share of U.S. TV viewing, April 2026 (Nielsen, The Gauge)

*   **3.0%**: Peacock's platform-best share in February 2026, on the Super Bowl and Olympics (Nielsen)

*   **+0.3 pts**: Peacock's year-over-year change (Nielsen)

*   **46 million**: Peacock paid subscribers, Q1 2026, its best quarter (Comcast)

*   **4.9 million**: record subscribers added in February 2026 alone (Comcast/Bloomberg)

*   **~80%**: estimated share of Peacock subscribers on an ad-supported plan (third-party estimates)

*   **$2 billion+**: Peacock revenue in Q1 2026, up 71% year over year (Comcast)

*   **2025-26 season**: when the NBA returned to NBC and Peacock, adding ~50 exclusive games a year (NBCUniversal)

## Reach premium streaming audiences, starting at $30 a day

Peacock is a sports-and-events streaming service whose viewing share swings from a 1.2% baseline to a 3.0% peak around the Super Bowl and Olympics, backed by 46 million subscribers and one of the most ad-supported bases in streaming. It helped move premium sports onto the connected screen.

You don't need a Peacock-sized budget to reach premium streaming viewers. See [how Adwave works](https://adwave.com/how-it-works) to turn your website into a broadcast-quality 30-second ad in minutes, or check [pricing](https://adwave.com/pricing) to launch a connected TV campaign from a $30-a-day minimum. The premium screen opened up. It's a good time to be on it.
