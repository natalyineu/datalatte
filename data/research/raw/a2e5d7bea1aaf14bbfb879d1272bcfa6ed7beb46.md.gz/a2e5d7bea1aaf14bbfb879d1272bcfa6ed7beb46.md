Title: Supporting Local Entrepreneurs in Enhancing Sanitation

URL Source: https://madagascar.co.uk/blog/2021/11/supporting-local-entrepreneurs-enhancing-sanitation-southeast-madagascar

Published Time: 2021-11-17T14:10:48+03:00

Markdown Content:
![Image 4: Revisit consent button](https://cdn-cookieyes.com/assets/images/revisit.svg)

![Image 5](https://cdn-cookieyes.com/assets/images/close.svg)

We value your privacy

We use cookies and other tracking technologies to improve your browsing experience, serve personalised ads or content, and to analyse our website traffic. By clicking "Accept All", you consent to our use of cookies.[Cookie Policy](https://madagascar.co.uk/cookie-policy)

Change my preferences Reject All Accept All

Customise Consent Preferences![Image 6](https://cdn-cookieyes.com/assets/images/close.svg)

We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.

The cookies that are categorised as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. ...Show more

For more information on how Google's third-party cookies operate and handle your data, see:[Google Privacy Policy](https://business.safety.google/privacy)

Necessary Always Active

Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.

*   Cookie __cf_bm 
*   Duration 1 hour 
*   Description This cookie, set by Cloudflare, is used to support Cloudflare Bot Management.  

Functional

- [x] 

Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.

*   Cookie yt-remote-device-id 
*   Duration Never Expires 
*   Description YouTube sets this cookie to store the user's video preferences using embedded YouTube videos. 

*   Cookie ytidb::LAST_RESULT_ENTRY_KEY 
*   Duration Never Expires 
*   Description The cookie ytidb::LAST_RESULT_ENTRY_KEY is used by YouTube to store the last search result entry that was clicked by the user. This information is used to improve the user experience by providing more relevant search results in the future. 

*   Cookie yt-remote-connected-devices 
*   Duration Never Expires 
*   Description YouTube sets this cookie to store the user's video preferences using embedded YouTube videos. 

*   Cookie yt-remote-session-app 
*   Duration session 
*   Description The yt-remote-session-app cookie is used by YouTube to store user preferences and information about the interface of the embedded YouTube video player. 

*   Cookie yt-remote-cast-installed 
*   Duration session 
*   Description The yt-remote-cast-installed cookie is used to store the user's video player preferences using embedded YouTube video. 

*   Cookie yt-remote-session-name 
*   Duration session 
*   Description The yt-remote-session-name cookie is used by YouTube to store the user's video player preferences using embedded YouTube video. 

*   Cookie yt-remote-fast-check-period 
*   Duration session 
*   Description The yt-remote-fast-check-period cookie is used by YouTube to store the user's video player preferences for embedded YouTube videos. 

*   Cookie yt-remote-cast-available 
*   Duration session 
*   Description The yt-remote-cast-available cookie is used to store the user's preferences regarding whether casting is available on their YouTube video player. 

Analytics

- [x] 

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.

*   Cookie _fbp 
*   Duration 3 months 
*   Description Facebook sets this cookie to display advertisements when either on Facebook or on a digital platform powered by Facebook advertising after visiting the website. 

*   Cookie _ga_* 
*   Duration 1 year 1 month 4 days 
*   Description Google Analytics sets this cookie to store and count page views. 

*   Cookie _ga 
*   Duration 1 year 1 month 4 days 
*   Description Google Analytics sets this cookie to calculate visitor, session and campaign data and track site usage for the site's analytics report. The cookie stores information anonymously and assigns a randomly generated number to recognise unique visitors. 

*   Cookie _gid 
*   Duration 1 day 
*   Description Google Analytics sets this cookie to store information on how visitors use a website while also creating an analytics report of the website's performance. Some of the collected data includes the number of visitors, their source, and the pages they visit anonymously. 

*   Cookie _gat_UA-* 
*   Duration 1 minute 
*   Description Google Analytics sets this cookie for user behaviour tracking.  

*   Cookie gaVisitorUuid 
*   Duration 1 year 
*   Description Google Analytics Getresponse sets this cookie to track online user behaviour statistically. 

Performance

Performance cookies are used to understand and analyse the key performance indexes of the website which helps in delivering a better user experience for the visitors.

No cookies to display.

Advertisement

- [x] 

Advertisement cookies are used to provide visitors with customised advertisements based on the pages you visited previously and to analyse the effectiveness of the ad campaigns.

*   Cookie YSC 
*   Duration session 
*   Description Youtube sets this cookie to track the views of embedded videos on Youtube pages. 

*   Cookie VISITOR_INFO1_LIVE 
*   Duration 6 months 
*   Description YouTube sets this cookie to measure bandwidth, determining whether the user gets the new or old player interface. 

*   Cookie VISITOR_PRIVACY_METADATA 
*   Duration 6 months 
*   Description YouTube sets this cookie to store the user's cookie consent state for the current domain.  

*   Cookie _gcl_aw 
*   Duration 3 months 
*   Description DoubleClick sets this cookie to understand user interaction with the site and advertising. 

Uncategorised

- [x] 

Other uncategorised cookies are those that are being analysed and have not been classified into a category as yet.

*   Cookie timeout 
*   Duration 12 hours 
*   Description No description available. 

*   Cookie webformv2_opened_95663804 
*   Duration 4 months 
*   Description Description is currently not available. 

*   Cookie CONCRETE 
*   Duration session 
*   Description Description is currently not available. 

*   Cookie webformv2_opened_56758004 
*   Duration 4 months 
*   Description Description is currently not available. 

*   Cookie __Secure-ROLLOUT_TOKEN 
*   Duration 6 months 
*   Description Description is currently not available. 

*   Cookie _gcl_gs 
*   Duration 3 months 
*   Description Description is currently not available. 

*   Cookie _gac_UA-15540636-1 
*   Duration 3 months 
*   Description Description is currently not available. 

Reject All Save My Preferences Accept All

Powered by [![Image 7](https://cdn-cookieyes.com/assets/images/poweredbtcky.svg)](https://www.cookieyes.com/product/cookie-consent/?ref=cypbcyb&utm_source=cookie-banner&utm_medium=powered-by-cookieyes)

[Skip to content](https://madagascar.co.uk/blog/2021/11/supporting-local-entrepreneurs-enhancing-sanitation-southeast-madagascar#skip-nav)

# [SEED Madagascar](https://madagascar.co.uk/)

[](https://www.facebook.com/SEEDMadagascar "Find us on Facebook")[](https://www.instagram.com/seedmadagascar/ "Find us on Instagram")[](https://www.linkedin.com/company/seedmadagascar "Find us on LinkedIn")[](https://twitter.com/SEEDMadagascar "Find us on X")[](https://youtube.com/SEEDMadagascarOrg "Find us on Youtube")[Donate now!](https://madagascar.enthuse.com/)

[Menu](https://madagascar.co.uk/blog/2021/11/supporting-local-entrepreneurs-enhancing-sanitation-southeast-madagascar#toggle-menu)[](https://madagascar.co.uk/blog/2021/11/supporting-local-entrepreneurs-enhancing-sanitation-southeast-madagascar#toggle-search-mobile "Toggle search box")

[](https://www.facebook.com/SEEDMadagascar "Find us on Facebook")[](https://www.instagram.com/seedmadagascar/ "Find us on Instagram")[](https://www.linkedin.com/company/seedmadagascar "Find us on LinkedIn")[](https://twitter.com/SEEDMadagascar "Find us on X")[](https://youtube.com/SEEDMadagascarOrg "Find us on Youtube")

    *   [Sustainable Development Goals](https://madagascar.co.uk/about/sustainable-development-goals)

    *   [Education Infrastructure](https://madagascar.co.uk/projects/education-infrastructure)
    *   [Environmental Conservation](https://madagascar.co.uk/projects/environmental-conservation)
    *   [Water, Sanitation and Hygiene (WASH)](https://madagascar.co.uk/projects/water-sanitation-and-hygiene-wash)

    *   [Conservation Research Programme](https://madagascar.co.uk/volunteer/conservation-research-programme)

    *   [Information for Our Supporters](https://madagascar.co.uk/news-media/information-our-supporters)
    *   [Mining Activities in Fort Dauphin](https://madagascar.co.uk/news-media/mining-activities-fort-dauphin-madagascar)
    *   [Connect with us](https://madagascar.co.uk/news-media/seed-madagascar-connect-with-us)

    *   [Earth Raise Campaign](https://madagascar.co.uk/support-us/brighter-together-earth-raise-campaign)
    *   [Tax efficient donations for USA](https://www.globalgiving.org/projects/holistically-alleviating-poverty-in-madagascar)
    *   [Run a marathon for SEED](https://madagascar.co.uk/volunteer/fundraising-advice/marathons)
    *   [Donating Cryptocurrency](https://madagascar.co.uk/support-us/donating-cryptocurrency)
    *   [Leave a gift in your Will](https://madagascar.co.uk/support-us/leave-gift-your-will)

[](https://madagascar.co.uk/blog/2021/11/supporting-local-entrepreneurs-enhancing-sanitation-southeast-madagascar#toggle-search "Toggle search box")Search query 

![Image 8: Women sit at as community meeting held in rural Madagascar to discuss setting up a savings and loan association](https://madagascar.co.uk/application/files/7016/3714/8580/initialising-the-vsla-groups.jpg)

Wednesday, 17th November 2021

## Supporting Local Entrepreneurs in Enhancing Sanitation in Southeast Madagascar

By Adèle Pavé

* * *

Whilst in the past NGOs have tended to work outside of the private sector, increasingly charities are recognising the value of working in partnership with local small-scale businesses and entrepreneurs to create positive and sustainable change. As part of its [Rural WASH project](https://madagascar.co.uk/projects/water-sanitation-and-hygiene-wash/rural-wash-collaboration-unicef-madagascar), SEED has adopted a market-based strategy which aims to improve sanitation through the creation of a local market for sanitary goods in southeast Madagascar. To achieve this, SEED, in partnership with UNICEF, is supporting local artisanal workers in building latrine platforms. SEED is encouraging local communities to consider the value of owning these goods through events and marketing, thereby helping to increase demand for new transformative products, which can increase levels of household hygiene and lower risk of infection and disease.

Initiating a sanitation market in southern Madagascar requires moving beyond the idea that local communities are simply passive beneficiaries who receive charitable services. On the contrary, the community members who are participating in this project are clients and customers. These customers have a crucial part to play in the success of market-based sanitation because they purchase the products that sustain regional markets. Local people are thus empowered to transform their own homes and communities through individual financial decisions.

One of the key products promoted by this initiative are mason-built sanitary platforms for household latrines (San Plats). These small concrete slabs can improve hygiene through ease of cleaning, reduce smell thanks to a tight-fitting lid, and so in turn limit flies. Their simple but safe design can also make household latrines significantly safer for younger children.

![Image 9: Visite-VOAMAMI-(14).jpg](https://madagascar.co.uk/application/files/6816/3714/9325/Visite-VOAMAMI-14.jpg)

_Above and top_:Visit for the initiation of VSLA groups

SEED has begun to focus its activities on growing the demand from customers for sanitary products like San Plats. Awareness campaigns about sanitation, on the radio and through meetings with the community, are used to nudge households to consider purchasing sanitary products and sustainable toilets. Village savings and loan association (VSLA) groups are also used as financing mechanisms to launch market-based sanitation in low-income settings. The goal of these VSLA groups is to create savings associations within villages, the collective savings of which are used as a source of zero-interest loans. This enables the whole community to take advantage of the opportunity to purchase sanitary products. SEED have so far established 103 VSLA groups.

Alongside preparing potential customers to purchase sanitary goods, SEED is also supporting sanitation business owners in their activities. In June SEED partnered with UNICEF and CARA, the regional business centre for the Anosy region, to train masons in entrepreneurship and San Plat design. So far 17 masons have applied their training to set up their own sanitary product businesses.

Alexandre Razafimandimby, 48, was one of the 17 masons participating in the training provided by CARA. Alexandre originally worked as a mason, but the lack of a market for him to sell his goods in Tsivory commune forced him to leave his profession and take up work as a farmer. However, SEED’s training enabled this businessman-in-the-making to create a business plan and establish a solid foundation for his new enterprise making and selling latrine platforms (San Plats). The outcome of this training has meant that Alexandre has been able to create a local market for sanitation in Tsivory, which has increased his income and enabled him to return to his original profession of choice.

![Image 10: IMG_2417.JPG](https://madagascar.co.uk/application/files/2416/3714/9464/IMG_2417.JPG)

Alexandre Razafimandimby and his certificate of completion in entrepreneurship.

The results of surveys conducted by SEED at the start of this project demonstrated that although many households would like to purchase a San Plat, most simply could not afford the high prices attached to them. By supporting entrepreneurs to learn new skills to increase their incomes, and empowering households to make financial decisions which will safeguard the health and wellbeing of their children, we aim to help community members overcome individual financial barriers and see communities develop long-term sustainable standards of household hygiene and sanitation in the southeast of Madagascar.

* * *

Join the SEED team in Madagascar[View jobs and opportunities](https://madagascar.co.uk/jobs)

### Topics

### Related posts

[![Image 11: One of the public toilets installed as part of SEED's urban sanitation programme.-min.jpg](https://madagascar.co.uk/application/files/thumbnails/w99_3by2/7915/5247/3115/One_of_the_public_toilets_installed_as_part_of_SEEDs_urban_sanitation_programme.-min.jpg)](https://madagascar.co.uk/blog/education-long-term-and-sustainable-investment-wash)

[Education, a long-term and sustainable investment in WASH](https://madagascar.co.uk/blog/education-long-term-and-sustainable-investment-wash)

Mar 11, 2019

[![Image 12: Mamitiana.jpg](https://madagascar.co.uk/application/files/thumbnails/w99_3by2/1916/4459/6608/Mamitiana.jpg)](https://madagascar.co.uk/blog/2022/01/sticking-sanitation-combatting-slippage-open-defecation-free-communities)

[Sticking with Sanitation: Combatting slippage in open defecation free communities](https://madagascar.co.uk/blog/2022/01/sticking-sanitation-combatting-slippage-open-defecation-free-communities)

Jan 14, 2022

### Newsletter

Sign up for our newsletter to get all the latest news and updates from our teams in Madagascar.

### Share this

[![Image 13: Facebook icon](https://madagascar.co.uk//packages/seed/themes/seed/imgs/social-icons/facebook.png)](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmadagascar.co.uk%2Fblog%2F2021%2F11%2Fsupporting-local-entrepreneurs-enhancing-sanitation-southeast-madagascar)[![Image 14: X icon](https://madagascar.co.uk//packages/seed/themes/seed/imgs/social-icons/twitter.png)](https://twitter.com/intent/tweet?url=https%3A%2F%2Fmadagascar.co.uk%2Fblog%2F2021%2F11%2Fsupporting-local-entrepreneurs-enhancing-sanitation-southeast-madagascar)[![Image 15: LinkedIn icon](https://madagascar.co.uk//packages/seed/themes/seed/imgs/social-icons/linkedin.png)](https://www.linkedin.com/shareArticle?mini-true&url=https%3A%2F%2Fmadagascar.co.uk%2Fblog%2F2021%2F11%2Fsupporting-local-entrepreneurs-enhancing-sanitation-southeast-madagascar&title=Supporting+Local+Entrepreneurs+in+Enhancing+Sanitation+in+Southeast+Madagascar)

#### You can also find us on:

[![Image 16: Facebook icon](https://madagascar.co.uk/packages/seed/themes/seed/imgs/social-icons/facebook.png)](https://www.facebook.com/SEEDMadagascar "facebook.com/SEEDMadagascar")[![Image 17: Instagram icon](https://madagascar.co.uk/packages/seed/themes/seed/imgs/social-icons/instagram.png)](https://www.instagram.com/seedmadagascar/ "instagram.com/seedmadagascar")[![Image 18: LinkedIn icon](https://madagascar.co.uk/packages/seed/themes/seed/imgs/social-icons/linkedin.png)](https://www.linkedin.com/company/seedmadagascar "linkedin.com/company/seedmadagascar")[![Image 19: Youtube icon](https://madagascar.co.uk/packages/seed/themes/seed/imgs/social-icons/youtube.png)](https://youtube.com/SEEDMadagascarOrg "youtube.com/SEEDMadagascarOrg")

#### Get our newsletter

Monthly news from Madagascar, straight to your inbox![Subscribe now](https://madagascar.co.uk/news-media/newsletter)

 Copyright © SEED Madagascar 2001-26, all rights reserved. UK Charity No. 1079121, Company No. 3796669.   
[Privacy policy](https://madagascar.co.uk/privacy)[Cookie policy](https://madagascar.co.uk/cookie-policy)

#### About

#### Impact

*   [Environmental Conservation](https://madagascar.co.uk/projects/environmental-conservation)
*   [Water, Sanitation & Hygiene (WASH)](https://madagascar.co.uk/projects/water-sanitation-and-hygiene-wash)

#### Volunteering

*   [Conservation volunteering](https://madagascar.co.uk/volunteer/conservation-research-programme)

##### Awards & Memberships

[![Image 20: GlobalGiving Vetted 2019](https://madagascar.co.uk/application/files/3516/0517/8502/footer-globalgiving-vetted.png)](https://madagascar.co.uk/about/supporters-awards "GlobalGiving Vetted 2019")[![Image 21: GlobalGiving Staff Favourite 2019](https://madagascar.co.uk/application/files/2516/0517/8501/footer-globalgiving-stafffavourite.png)](https://madagascar.co.uk/about/supporters-awards "GlobalGiving Staff Favourite 2019")[![Image 22: Lemur Conservation Network member](https://madagascar.co.uk/application/files/2216/0517/8684/footer-lcn.png)](https://madagascar.co.uk/about/partners "Lemur Conservation Network member")[![Image 23: Conservation Optimism member](https://madagascar.co.uk/application/files/3416/0517/8501/footer-conservation-optimism.png)](https://madagascar.co.uk/about/partners "Conservation Optimism member")[![Image 24: Inter-Agency Misconduct Disclosure Scheme member](https://madagascar.co.uk/application/files/3716/0517/8503/footer-schr.png)](https://madagascar.co.uk/about "Inter-Agency Misconduct Disclosure Scheme member")[![Image 25: End Water Poverty member](https://madagascar.co.uk/application/files/3916/0517/8500/footer-ewp.png)](https://madagascar.co.uk/about/partners "End Water Poverty member")
