Title: What is the Max plan?

URL Source: https://support.claude.com/en/articles/11049741-what-is-the-max-plan

Markdown Content:
[All Collections](https://support.claude.com/en/)[Pro, Max, and Ultra plans](https://support.claude.com/en/collections/5953830-pro-max-and-ultra-plans)[Max plan](https://support.claude.com/en/collections/12394590-max-plan)What is the Max plan?

Updated over a week ago

This article is about paid Max plans for individual consumers. If you're part of an organization looking to use Claude with your team, refer to **[Team and Enterprise plans](https://support.claude.com/en/collections/9387370-team-and-enterprise-plans)**.

The Max plan is designed for users who collaborate with Claude frequently and need more usage to work on a variety of tasks. In addition to providing higher usage limits than the Pro plan, Max plan subscribers will also receive priority access to our newest features and models.

## Key benefits

**Need more usage?** Learn more about the **[Ultra plan](https://support.claude.com/en/articles/17728952)**.

## How much does the Max plan cost?

### Pricing

The Max plan is available for $100 per month.

Price and plans are subject to change at Anthropic's discretion.

### Billing information

### How can I get a free or discounted Max plan?

We don't offer standard discounted pricing for individual plans (Pro, Max, and Ultra), but anyone in a supported location can access the free version of Claude by navigating to[**claude.ai**](https://claude.ai/) and signing up using an email address.

We occasionally run limited-time promotions, but we don't have any standing discounts available upon request. These promotional offers are typically announced through our official channels when available. If you're interested in potential future promotions, we recommend following our official social media accounts or signing up for our newsletter to be notified of any special offers. Our Support team cannot issue one-off discounts or coupons.

Eligible nonprofit organizations can get discounted pricing on Team and Enterprise plans. Learn more about **[Claude for Nonprofits](https://claude.com/solutions/nonprofits)**.

## Does the Max plan have any usage limits?

Yes. The Max plan includes five times the Pro plan's usage every five hours and every week. If you need more usage, learn more about the **[Ultra plan](https://support.claude.com/en/articles/17728952)**.

Max plans have a five-hour limit, a weekly usage limit that applies across all models, and a separate weekly limit for Fable. The weekly limit resets at a fixed time each week that is assigned to your account. Your reset day and time stay the same regardless of when you start using Claude or when your subscription begins, and you receive your full weekly allowance each cycle. You can see your next reset time in **[Settings > Usage](https://claude.ai/new#settings/usage)**.

Additional usage limits may apply to manage capacity and ensure fair access to all users. For example, we may limit your usage in other ways, such as weekly and monthly caps or model and feature usage, at our discretion. We don't guarantee uninterrupted service.

## Related Articles

*   [What is the Pro plan?](https://support.claude.com/en/articles/8325606-what-is-the-pro-plan)
*   [Use Claude Code with your Pro, Max, or Ultra plan](https://support.claude.com/en/articles/11145838-use-claude-code-with-your-pro-max-or-ultra-plan)
*   [Manage usage credits for paid Claude plans](https://support.claude.com/en/articles/12429409-manage-usage-credits-for-paid-claude-plans)
*   [Claude Fable models on your plan](https://support.claude.com/en/articles/15424964-claude-fable-models-on-your-plan)
*   [What is the Ultra plan?](https://support.claude.com/en/articles/17728952-what-is-the-ultra-plan)
