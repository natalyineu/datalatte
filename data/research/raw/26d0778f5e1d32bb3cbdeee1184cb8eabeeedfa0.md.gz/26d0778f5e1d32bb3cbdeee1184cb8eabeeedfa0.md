Title: What percentage of U.S. TV time is ad-supported vs. ad-free? (Q2 2025)

URL Source: https://adwave.com/resources/us-tv-ad-supported-share-q2-2025

Published Time: 2025-12-09T00:00:00+00:00

Markdown Content:
*   73.6%

U.S. TV time is ad-supported

*   +1.2 pts

Quarterly growth in ad-supported viewing

*   45%

Streaming's share of ad-supported TV

Nearly three-quarters of all U.S. TV viewing happens in ad-supported environments, according to [Nielsen's Ad-Supported Gauge](https://www.nielsen.com/news-center/2025/nielsen-launches-the-ad-supported-gauge/) data (Q2 2025). Specifically, 73.6% of all TV time includes advertising, whether viewers are watching streaming services, cable, or broadcast. This represents a 1.2 percentage point increase from Q1 2025 and signals a continued shift toward ad-funded content. For small businesses, this data confirms what many suspected: your customers are watching ads when they watch TV, and reaching them has never been more accessible.

## What the data shows

Nielsen's Ad-Supported Gauge, launched in 2025, provides the most detailed view of advertising's reach in all TV viewing. The data reveals just how dominant ad-supported content has become.

Key findings from the Q2 2025 report:

*   **Total ad-supported share:**73.6% of all U.S. TV viewing time included advertising in Q2 2025

*   **Quarterly growth:**Ad-supported viewing rose 1.2 percentage points from Q1 2025 (72.4%)

*   **Streaming leads:**Within ad-supported TV, streaming accounts for approximately 45%, followed by cable (29%) and broadcast (26%)

*   **Ad-free minority:**Only 26.4% of TV viewing happens on ad-free tiers and content

*   **Historic milestone:**May 2025 marked the first time streaming surpassed broadcast + cable combined

*   **Streaming with ads:**Ad-supported streaming is now the single largest driver of ad-funded TV viewing

The shift toward ad-supported content has accelerated as streaming services expand their ad tiers. Netflix, Disney+, Max, and others have introduced lower-cost ad-supported options, and consumers are increasingly choosing them. Meanwhile, free ad-supported streaming TV (FAST) services like [Tubi](https://adwave.com/resources/tubi-advertising-small-business) and [Pluto TV](https://adwave.com/resources/pluto-tv-advertising-small-business) continue to grow rapidly.

What's notable is that ad-supported viewing grew even as total TV viewing dipped 9% quarter-over-quarter. This suggests that the remaining TV viewers are increasingly concentrated in ad-supported environments, creating more value for advertisers per viewer.

![Image 1: Platform Comparison V2](https://adwave.com/assets/images/resources/optimized/649eb61112f6c7e8ddb6-1280w-3b65b7c98fb68a2eb76d06dfefeca539.webp)
## Breaking down the numbers

![Image 2: Chart Ad Distribution](https://adwave.com/assets/images/resources/optimized/b3283f579c3b31809ade-1280w-85b3959d76d0a5c31c56c68ba80830fd.webp)
Understanding where ad-supported viewing happens helps advertisers make smarter decisions about channel allocation.

### By content source

Within the 73.6% of TV time that's ad-supported, streaming now leads the mix. Approximately 45% of ad-supported viewing happens on streaming platforms. Cable accounts for about 29%, while broadcast represents roughly 26%. This breakdown has shifted significantly over the past three years, with streaming gaining share primarily at cable's expense.

### By platform type

Ad-supported streaming includes several categories: AVOD (advertising video on demand) services like YouTube and Peacock; FAST services like Tubi and Pluto TV; and ad-supported tiers of premium services like Netflix, Disney+, and Max. YouTube alone represents over 10% of all TV viewing and is almost entirely ad-supported. [YouTube's TV viewing share](https://adwave.com/resources/youtube-tv-viewing-share) continues to grow as the platform invests in living room experiences.

The 26.4% of TV viewing that's ad-free comes primarily from premium subscription tiers (Netflix Premium, Disney+ ad-free, etc.) and some cable premium channels. However, as subscription fatigue grows and services increase prices for ad-free tiers, consumers are migrating toward ad-supported options. This trend is expected to continue through 2026 and beyond.

![Image 3: Age Demographics V2](https://adwave.com/assets/images/resources/optimized/133650469ab3913aae7b-1280w-a1b0f754edc1f3f7a513c5b7e2509e90.webp)
## Why it matters for your business

The bottom line is simple: when your customers watch TV, they're seeing ads. Nearly three out of every four TV minutes include advertising. This creates enormous opportunity for businesses of all sizes.

### More inventory, better access

The growth of ad-supported streaming has dramatically expanded available advertising inventory. More inventory means more competition among sellers, which helps keep prices accessible. Small businesses can now access premium TV placement at CPMs (cost per thousand impressions) that would have been unthinkable five years ago.

### The opportunity by business type

**Local service businesses**([home services](https://adwave.com/industries/home-services), [healthcare](https://adwave.com/industries/healthcare), [legal](https://adwave.com/industries/legal)): Target households in your service area during evening hours when viewers are relaxed and thinking about home projects or services they need.

**Restaurants and retail:**Reach local audiences during meal times or promote weekend specials. [Restaurant advertising](https://adwave.com/industries/food-beverage) on streaming TV can drive same-day visits.

**E-commerce and DTC brands:**Build brand awareness with audiences who are engaged and receptive, then retarget with performance ads.

### Accessible entry point

You no longer need a national budget to reach TV viewers. With platforms like Adwave, you can run [TV advertising campaigns](https://adwave.com/resources/how-to-advertise-on-tv) starting at just $30 a day. AI generates your commercial from your website, so there's no production budget required. Your ad can be live in minutes, reaching the same audiences that major brands target.

![Image 4: Business Opportunity V2](https://adwave.com/assets/images/resources/optimized/029857e33ed3eaaa9fb4-1280w-fa7eac1b56d98e953798f8a630e4a8a7.webp)
## How to take advantage of this trend

![Image 5: Chart Platform Tiers](https://adwave.com/assets/images/resources/optimized/81e70c92b95a15fb5f4c-1280w-9edc7ed3cb87e80ce64b65eb0d71a3d0.webp)
Knowing that 73.6% of TV viewing is ad-supported is valuable. Acting on that information is what grows your business.

### Start with streaming

Streaming now leads ad-supported TV, and it offers the best targeting capabilities. Consider starting with platforms like [Roku](https://adwave.com/resources/roku-advertising-small-business), [Hulu](https://adwave.com/resources/hulu), or YouTube via [connected TV advertising](https://adwave.com/resources/what-is-connected-tv-advertising).

### Test with a small budget

Begin with $100-$200 to gather initial data. Run for 2 weeks to capture viewing patterns. Focus on your local area for local businesses, or test national targeting for e-commerce.

### Measure brand lift

TV advertising works differently than performance marketing. Track brand search lift, website traffic increases, and customer surveys asking how people heard about you.

## The bigger picture

The rise of ad-supported TV is part of a larger shift in how Americans consume video content.

The average U.S. household now subscribes to 4+ streaming services. As prices rise and budgets tighten, consumers are increasingly choosing ad-supported tiers over premium ad-free options. Netflix reported that 40%+ of new subscribers in ad-supported markets choose the ad tier.

### FAST growth accelerates

Free ad-supported streaming TV services are among the fastest-growing segments of TV viewing. Services like Tubi, Pluto TV, and Freevee offer premium content at no cost to viewers, funded entirely by advertising. This creates substantial inventory for advertisers.

### What's next

Industry analysts project ad-supported viewing will reach 75%+ of total TV time by 2026. The days when [TV advertising](https://adwave.com/resources/how-to-advertise-on-tv) required six-figure budgets are definitively over. Every shift toward ad-supported content represents more opportunity for small businesses.

![Image 6: Growth Trend V2](https://adwave.com/assets/images/resources/optimized/ebd8d679a6ec39b37bf1-1280w-f40c60710dcc27d3bfb1396d722b0bf0.webp)
## What experts are saying

![Image 7: Concept Ads](https://adwave.com/assets/images/resources/optimized/558a51d9c4e3099a110c-1280w-0728c994756191ca925e2a605f61403a.webp)
Industry analysts have noted the ad-supported shift as a fundamental change in television economics.

Nielsen's launch of the Ad-Supported Gauge reflects industry demand for better measurement of advertising reach. As Nielsen stated: "Understanding what share of TV is ad-supported versus ad-free is critical for advertisers planning their media mix."

The Interactive Advertising Bureau (IAB) has highlighted the democratization aspect: "Ad-supported streaming has opened TV advertising to businesses that could never afford it before. Combined with programmatic buying and AI creative tools, the barriers have essentially disappeared."

## Common questions answered

Ad-supported TV includes any content where advertising appears during viewing. This includes streaming services with ads (YouTube, Hulu, Peacock, ad tiers of Netflix/Disney+/Max), FAST services (Tubi, Pluto TV), traditional cable, and broadcast television. It does not include ad-free subscription tiers.

Several factors drive growth: subscription fatigue as consumers manage multiple services, price sensitivity leading viewers to choose cheaper ad-supported tiers, expansion of FAST services with quality content, and streaming services actively promoting ad tiers with lower prices.

Nielsen's Ad-Supported Gauge uses the same panel methodology as the traditional Gauge report, combined with automatic content recognition (ACR) data from smart TVs and set-top boxes. It tracks which content includes advertising versus ad-free viewing.

### Can small businesses afford TV advertising now?

Yes. With programmatic buying and platforms like Adwave, small businesses can run TV campaigns starting at $30 a day. CPMs typically range from $15-$35, meaning $100 can reach 3,000-6,000 households. AI tools generate broadcast-ready ads without production costs.

All forecasts point to continued growth. As streaming services expand ad tiers, FAST services grow, and subscription fatigue increases, ad-supported viewing is projected to reach 75%+ by 2026.

## Supporting data

Additional context on ad-supported TV viewing:

*   **Ad-supported share:**73.6% of U.S. TV time includes advertising ([Nielsen](https://www.nielsen.com/news-center/2025/nielsen-launches-the-ad-supported-gauge/), Q2 2025)

*   **Streaming share:**Streaming accounts for 47.3% of total TV time ([Nielsen Gauge](https://www.nielsen.com/data-center/the-gauge/), July 2025)

*   **Netflix ad tier adoption:**40%+ of new subscribers in ad-supported markets choose ad tier (Netflix Earnings, Q2 2025)

*   **FAST growth:**Free ad-supported streaming grew 25%+ YoY ([eMarketer](https://www.emarketer.com/), 2025)

*   **CTV ad spend:**U.S. CTV advertising projected to reach $30+ billion in 2025 ([eMarketer](https://www.emarketer.com/))

*   **Smart TV penetration:**85% of U.S. households have at least one smart TV ([Parks Associates](https://www.parksassociates.com/), 2025)

All sources linked above. Data current as of Q2 2025.

## Get started with TV advertising

[See how it works](https://adwave.com/how-it-works) | [View pricing](https://adwave.com/pricing)
