Title: AppsFlyer pricing | A plan for every marketing budget

URL Source: https://www.appsflyer.com/pricing/

Markdown Content:
[](https://www.appsflyer.com/) Back 

## Products

    *   [Mobile Attribution](https://www.appsflyer.com/products/measurement/mobile-attribution/)
    *   [PC & Console Attribution](https://www.appsflyer.com/products/measurement/pc-console-attribution/)
    *   [Cross-Platform Measurement](https://www.appsflyer.com/products/measurement/cross-platform-measurement/)
    *   [Marketing Analytics](https://www.appsflyer.com/products/measurement/marketing-analytics/)
    *   [Creative Optimization](https://www.appsflyer.com/products/measurement/creative-optimization/)
    *   [Audience Segmentation](https://www.appsflyer.com/products/measurement/audience-segmentation/)
    *   [Fraud Protection](https://www.appsflyer.com/products/measurement/fraud-protection/)
    *   [Product Analytics](https://www.appsflyer.com/products/measurement/product-analytics/)

    *   [Referral-to-App](https://www.appsflyer.com/products/deep-linking/referral-to-app/)
    *   [Deferred Deep Linking](https://www.appsflyer.com/products/deep-linking/deferred-deep-linking/)
    *   [Link Management](https://www.appsflyer.com/products/deep-linking/link-management/)

    *   [Data Management](https://www.appsflyer.com/products/data-collaboration/data-management/)
    *   [Audience Activation](https://www.appsflyer.com/products/data-collaboration/audience-activation/)
    *   [Retail Media Measurement](https://www.appsflyer.com/products/data-collaboration/retail-media-measurement/)
    *   [Data Clean Room](https://www.appsflyer.com/products/data-collaboration/data-clean-room/)

#### Featured

    *   [![Image 13](https://www.appsflyer.com/wp-content/uploads/2025/11/slot-content-6-1.svg)Product tours](https://www.appsflyer.com/interactive-product-tours/)
    *   [![Image 14](https://www.appsflyer.com/wp-content/uploads/2025/11/slot-content-8-1.svg)Product news](https://www.appsflyer.com/product-news/)
    *   [![Image 15: icon enterprise grade security](https://www.appsflyer.com/wp-content/uploads/2025/12/typetype7.svg)Enterprise-Grade Security](https://www.appsflyer.com/products/enterprise-grade-security)

## Solutions

    *   [User acquisition and ROAS](https://www.appsflyer.com/solutions/user-acquisition-roas/)
    *   [Customer retention and LTV](https://www.appsflyer.com/solutions/customer-retention-ltv)
    *   [Omnichannel media buying](https://www.appsflyer.com/solutions/omnichannel-media-buying)
    *   [Media selling and monetization](https://www.appsflyer.com/solutions/media-selling-monetization)

 Partnerships 

#### Featured

    *   [![Image 16](https://www.appsflyer.com/wp-content/uploads/2025/11/slot-content-6-1.svg)Product tours](https://www.appsflyer.com/interactive-product-tours/)
    *   [![Image 17](https://www.appsflyer.com/wp-content/uploads/2026/10/slot-content.svg)Enterprise solutions](https://www.appsflyer.com/solutions/enterprise/)
    *   [![Image 18](https://www.appsflyer.com/wp-content/uploads/2025/11/slot-content-9.svg)Customer stories](https://www.appsflyer.com/customers/)

## Resources

    *   [Marketing Attribution](https://www.appsflyer.com/blog/topic/measurement-attribution/)
    *   [Cross-platform Measurement](https://www.appsflyer.com/blog/topic/omnichannel-marketing/)

    *   [State of Creative](https://www.appsflyer.com/resources/reports/creative-optimization/)
    *   [State of Gaming](https://www.appsflyer.com/resources/reports/gaming-app-marketing/)
    *   [State of eCommerce](https://www.appsflyer.com/resources/reports/ecommerce-app-marketing/)
    *   [State of Fraud](https://www.appsflyer.com/resources/reports/state-fraud-marketers/)
    *   [Performance Index](https://www.appsflyer.com/resources/reports/performance-index/)

 Customer Resources 

[Blog Get the latest marketing news and expert insights delivered to your inbox ![Image 19](https://www.appsflyer.com/wp-content/uploads/2026/09/slot-menu-banner-300x166-1.png)](https://www.appsflyer.com/blog/)

## Company

 Company 

 Get in touch 

#### Social

    *   [![Image 20](https://www.appsflyer.com/wp-content/uploads/2026/09/slot-content-linkedin.svg)LinkedIn](https://www.linkedin.com/company/appsflyerhq/posts/?feedView=all)
    *   [![Image 21](https://www.appsflyer.com/wp-content/uploads/2026/09/slot-content-YT.svg)YouTube](https://www.youtube.com/c/Appsflyer)
    *   [![Image 22](https://www.appsflyer.com/wp-content/uploads/2026/09/slot-content-Instegram.svg)Life at AF](https://www.instagram.com/appsflyer_hq/)

*   English

# A plan for every app

Fuel growth and maximize your budget with the industry’s #1 measurement partner.

[FULL PLATFORM](https://www.appsflyer.com/pricing/)[DEEP LINKING](https://www.appsflyer.com/pricing/deep-linking)

Free

### Zero

Ideal for apps seeking a simple tool for owned media activities*

What’s included:

*   Land your first installs
*   Create smooth discovery to install experiences

 * Not suitable for apps with paid activities

 * Zero plan includes a Welcome Package with 12K free conversions for the first year, core marketing analytics, and 30 days of access to select premium add-ons.

Pay-as-you-go

### Growth

Best for startups requiring basic measurement as they start their paid campaigns

What’s included:

*   Kickstart app growth
*   Measure paid campaigns with basic mobile attribution
*   Boost engagement with seamless journeys

 * Growth plan includes a Welcome Package with 12K free conversions for the first year, core marketing analytics, and 30 days of access to select premium add-ons. Following the Welcome Package, conversions are priced at $0.07 each.

Most popular

Custom pricing

### Enterprise

Perfect for brands aiming to efficiently scale their revenue with a tailored plan

What’s included:

*   Increase revenue with cross-channel attribution insights
*   Overcome marketing signal loss
*   Maximize ROAS
*   Scale user acquisition
*   Increase engagement and LTV
*   Boost efficiency with AI insights
*   Detect and prevent mobile fraud

## Compare plans

Want to know which plan is right for you? Here are all the details.

Zero

Growth

Enterprise

### Attribution

Mobile attribution

Real-time mobile measurement and reporting

Multi-touch attribution

Configurable, rich in-app events

Configurable lookback windows

Customizable targeting validation rules

SKAN Conversion Studio

Single Source of Truth 1.0

SKAN Null CV modeling

SKAN CV recommendations

SKAN LTV Modeling

Partner API & data management

Support for domestic China

Cross-platform attribution

Real-time cross-device and web attribution

Conversion path visualization

CTV/OTT attribution

CTV/OTT attribution and measurement

 SDKs and plugins

Support for all major platforms and plugins

SDK-less (S2S APIintegration)

### Marketing analytics

Cohort and retention reports

Customizable dashboards

Activity dashboard

LTV analytics

Pivot reports

AppsFlyer mobile app

Advanced analytics & APIs

Programmatic cohort analytics API

Aggregated data API

Aggregated Data report export

### Deep Linking Suite

Shortlinks, deep links and QR code creation

Link Management

AI Link Generator

Click reporting

Social-to-app landing pages

Deferred Deep Linking

Advanced Analytics

Smart Banners and Smart Script

Branded Links

Referrals & user invites

Bulk Links

Email Service Provider (ESP) Integration

OneLink API

### ROI reporting

Basic ad spend reporting

Real-time ad spend aggregation and reporting

CSV uploads

Data corrections

Agency fee cost calculation

Retargeting cost data

Cost ETL

Cost API integrations

Store Receipt-Validated In-App Purchases measurement

Real-time impression level ad-revenue measurement

In-App Subscription revenue measurement

### Audience segmentation

Custom audiences

Exclusion lists

A/B split testing

Audience campaign analytics

Audience size and overlap visualization

Dynamic sync with 90+ API partners

Audience ingestion through CSV/API

Audience enrichment with 1st party data

Owned media segmentation

Built in consent management

### Incrementality lift testing & measurement

Impact based measurement through RCT

Incremental KPIs

Automated Incrementality experiments

### Fraud protection

Basic fraud protection

Advanced fraud protection (Protect360™)

Advanced behavioral biometrics

Post-attribution protection

Advanced anomaly detection

In-app event and CPA fraud protection

Fraud validation rules

Professional fraud analysis

### Raw Data and APIs

Push API

Pull API

Data Locker

Data report exports

### Integrations

 Media partners

Direct publishers & SRNs

Ad networks

Domestic China ad networks

Marketing partners

DSPs (Demand-side platforms)

Remarketing networks

 Tech partners

ESPs (Email service providers)

Customer data platforms

Campaign management platforms

Customer engagement platforms

Marketing cloud platforms

Product analytics platforms

Affiliate marketing and platforms

TV & OTT attribution platforms

AppsFlyer solutions partners

Partner marketplace

### Compliance and security

 Compliance

iOS 14+

Android 12

SSAE16 SOC2

ePrivacy

TRUSTe

ISO 27001, 27017, 27018, 27032

CSA STAR

EU-US, Swiss-US Privacy Shield

Data protection compliance under GDPR, CCPA, LGPD and more

OpenDSR (Data Subject Request) API

 Enhanced access

2-factor-authentication (2FA)

Login and password management

Single sign-on (SSO)

User management

 Audit log

Audit log

API usage logs

### Support and services

Self-service help center

Email support

Dedicated Customer Success Manager

Migration & onboarding support

Advanced online & onsite training access

## You’ll be in good company

![Image 23: Logo image](https://webdev.appsflyer.com/wp-content/uploads/2025/11/lulu-logo-c.svg)

![Image 24: scopely logo](https://webdev.appsflyer.com/wp-content/uploads/2025/11/scopely-logo-c.svg)

![Image 25: TiKTok logo](https://webdev.appsflyer.com/wp-content/uploads/2025/10/TiKTok.svg)

![Image 26: Ubisoft-logo](https://webdev.appsflyer.com/wp-content/uploads/2025/11/%F0%9F%9A%A8logo-box-28.svg)

![Image 27: pepsi-logo](https://webdev.appsflyer.com/wp-content/uploads/2025/11/pepsi-logo-c.svg)

![Image 28: carrefour-logo](https://webdev.appsflyer.com/wp-content/uploads/2025/11/carrefour-logo-c.svg)

![Image 29: hsbc-logo](https://webdev.appsflyer.com/wp-content/uploads/2025/11/hsbc-logo-c.svg)

![Image 30: logo-burger-king](https://webdev.appsflyer.com/wp-content/uploads/2024/04/hp-logo-burger-king.png)

![Image 31: gap-logo](https://webdev.appsflyer.com/wp-content/uploads/2025/11/gap-logo-c.svg)

![Image 32: barclays logo](https://webdev.appsflyer.com/wp-content/uploads/2025/11/barclays.png)

![Image 33: king logo](https://webdev.appsflyer.com/wp-content/uploads/2025/11/king.svg)

![Image 34: netflix-logo](https://webdev.appsflyer.com/wp-content/uploads/2025/11/netflix-logo-c.svg)

## Frequently asked questions

##### What is included in the AppsFlyer Welcome Package?

**The AppsFlyer Welcome Package includes:**  
  
12,000 free conversions to be used within the first 12 months of signing up.  
  
Access to core marketing analytics tools.  
  
SKAdNetwork support for iOS campaign measurement.  
  
  
  
**A 30-day trial of select premium add-ons, including:**  
  
Raw Data API Access.  
  
API Analytics Suite.  
  
Custom Dashboards.  
  
The 30-day trial period for the premium add-ons begins immediately upon completing the sign-up process. After the trial ends, continued access to these features requires a subscription to the respective premium plans.  

##### How do I switch or upgrade to a different plan?

 You can switch or upgrade to a different plan at any time by simply heading over to “my plan” under your account within the AppsFlyer platform. 

##### Is there a free trial for paid plans?

 Both the Zero and Growth plans get a special one-time bonus: your first 12,000 conversion measurements are free and you get access to AppsFlyer’s add-ons free for 30 days. This is non-inclusive of premium features included in the Enterprise plan. 

##### What is a conversion?

 A conversion is a successful app install or user action that your efforts drove and that you measured with AppsFlyer. This can be an app install, a re-engagement, or a re-attribution driven by a campaign that you are measuring with AppsFlyer. “Organic” installs or actions, those that AppsFlyer does not attribute, are not counted as conversions and are totally free. 

##### What are AppsFlyer’s premium features?

 Premium features include API access, Protect360 – Fraud Protection Suite, Audiences – Audience Segmentation, Data Locker, and more. 

##### What are my payment options?

 We accept all major credit cards, PayPal and (in select countries) direct debit. 

Ready to start making good choices?

[Request a Demo](https://www.appsflyer.com/pricing/#request_demo)[Sign up free](https://webdev.appsflyer.com/sign-up/)

### Product

*   [Measurement Suite](https://www.appsflyer.com/products/measurement/ "Measurement Suite")
*   [Deep Linking Suite](https://www.appsflyer.com/products/deep-linking/ "Deep Linking Suite")
*   [Data Collaboration Suite](https://www.appsflyer.com/products/data-collaboration/ "Data Collaboration Suite")

### Solutions

*   [Enterprise grade security](https://www.appsflyer.com/products/enterprise-grade-security/ "Enterprise grade security")

### Resources

*   [Customer Learning Portal](https://elevate.appsflyer.com/learn/signin "Customer Learning Portal")

### Get started

*   [Metrics comparison](https://www.appsflyer.com/metrics-comparison/ "Metrics comparison")

### Company

![Image 35](https://www.appsflyer.com/wp-content/themes/AF2020/assets/images/background-footer-static.webp)

©2026 AppsFlyer Ltd. All rights reserved.

×

![Image 36: AppsFlyer Logo](https://www.appsflyer.com/wp-content/plugins/af-marketo-forms-core/forms/request-demo/images/conpany_logo_black.svg)

##### Submit your request to see AppsFlyer in action

###### Which solutions are you most interested in? Select all that apply

- [x] 

###### Measurement

Measure every step across mobile, web, CTV and PC & console

![Image 37: Attribution](https://www.appsflyer.com/wp-content/plugins/af-marketo-forms-core/forms/request-demo/images/suites-icons-1.svg)

 - [x] 

###### Data Collaboration Platform

Unlock first-party data value through privacy-preserving partnerships

![Image 38: Data Collaboration](https://www.appsflyer.com/wp-content/plugins/af-marketo-forms-core/forms/request-demo/images/suites-icons-4.svg)

 - [x] 

###### Deep Linking

Guide customers from any channel to the in-app moments that drive growth

![Image 39: Deep Linking](https://www.appsflyer.com/wp-content/plugins/af-marketo-forms-core/forms/request-demo/images/suites-icons-3.svg)

 - [x] 

###### Creative Optimization

Manage and analyze creative performance with AI-powered insights

![Image 40: Creative Optimization](https://www.appsflyer.com/wp-content/plugins/af-marketo-forms-core/forms/request-demo/images/suites-icons-2.svg)

 

Next

##### Help us customize your experience

###### Select your company type

### Advertiser

We have a mobile app or are launching one soon

 

### Partner

We provide services or tools for mobile apps

 

![Image 41: Agency](https://www.appsflyer.com/wp-content/plugins/af-marketo-forms-core/forms/request-demo/images/ill_spot.svg)

### Agency

We manage mobile apps for our clients

 

By clicking on "Next" you agree to AppsFlyer's [Terms of Use](https://www.appsflyer.com/legal/site-terms/) and [Privacy Policy](https://www.appsflyer.com/legal/privacy-policy/)

This site is protected by reCAPTCHA and the Google Privacy Policy and Terms of Service apply.

###### Do you have customers already working with AppsFlyer?

Yes No 

To manage your customers' activity with AppsFlyer, please go ahead to create an AppsFlyer agency account

We currently offer demos only to businesses evaluating AppsFlyer for their own apps. However, there’s always tomorrow - and we’d be happy to help you build your AppsFlyer expertise to better support your future clients.

Take a [self-guided](https://www.appsflyer.com/interactive-product-tours/) tour of the platform.

To learn more about our Agencies program or for general inquiries, feel free to reach out to us at [agency@appsflyer.com](mailto:agency@appsflyer.com).

###### Are you already an integrated partner with AppsFlyer?

Yes No 

For any question, please [sign in](https://hq1.appsflyer.com/auth/login) to your existing AppsFlyer account and go to Help → Contact our team

We appreciate your interest in becoming an AppsFlyer partner. In order to begin the integration process, you must be referred by an existing AppsFlyer customer via our platform. If you'd like to start the process, please reach out to your customer and kindly request to receive an invite link. You can find additional resources in our [Help Center](https://support.appsflyer.com/hc/en).

Back Next

1/3

##### Tell us about your business

###### Numbers of employees

1-50 51-250 251-1,000 1,001-5,000 Over 5,000 

###### Annual mobile advertising budget

$0 $1-$50K $51K–$200K $201K–$500K $501K–$1M $1M–$2.5M $2.5M+ 

###### Annual paid downloads

0 1–100K 101K–250K 251K–600K 601K–2M 2M+ 

Back Next

2/3

##### Just a few last details

###### What challenges can we help you solve?

###### How did you hear about AppsFlyer?

By clicking on "Next" you agree to AppsFlyer's [Terms of Use](https://www.appsflyer.com/legal/site-terms/) and [Privacy Policy](https://www.appsflyer.com/legal/privacy-policy/)

This site is protected by reCAPTCHA and the Google Privacy Policy and Terms of Service apply.

Next

1/3

##### Help us customize your experience

###### Numbers of employees

1-50 51-250 251-1,000 1,001-5,000 Over 5,000 

By clicking on "Next" you agree to AppsFlyer's [Terms of Use](https://www.appsflyer.com/legal/site-terms/) and [Privacy Policy](https://www.appsflyer.com/legal/privacy-policy/)

This site is protected by reCAPTCHA and the Google Privacy Policy and Terms of Service apply.

Back Next

3/3

##### Meet your AppsFlyer expert

Based on your needs, we've matched you with the right AppsFlyer expert. Book a 15-minute discovery call to discuss your goals and schedule your personalized demo

### Thanks for reaching out! 🎉

We can't wait to show you around and learn more about your goals and challenges.

###### In the meantime, here are two great ways to learn more about AppsFlyer:

*   ![Image 42](https://www.appsflyer.com/wp-content/plugins/af-marketo-forms-core/forms/request-demo/images/icon_check.svg) Get inspired by [customer success stories](https://www.appsflyer.com/customers/)
*   ![Image 43](https://www.appsflyer.com/wp-content/plugins/af-marketo-forms-core/forms/request-demo/images/icon_check.svg) Take a [self-guided tour](https://www.appsflyer.com/interactive-product-tours/) of the platform 

##### <p>Trusted by 100,000+<br /> apps worldwide</p>

![Image 44](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)![Image 45](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)![Image 46](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)![Image 47](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)![Image 48](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)

“No marketing stack is complete without AppsFlyer.”

![Image 49: ebay logo](https://www.appsflyer.com/wp-content/uploads/2026/03/ebay.svg)

![Image 50](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)![Image 51](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)![Image 52](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)![Image 53](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)![Image 54](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)

“In 3 weeks, we knew more than 2 years with our former provider.”

![Image 55](https://www.appsflyer.com/wp-content/uploads/2026/03/Mobly.svg)

![Image 56](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)![Image 57](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)![Image 58](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)![Image 59](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)![Image 60](https://www.appsflyer.com/wp-content/uploads/2026/03/star.svg)

“We were able to scale our remarketing efforts with confidence.”

![Image 61](https://www.appsflyer.com/wp-content/uploads/2026/03/Kabam.svg)

## Our Cookies Policy

AppsFlyer respects your privacy as our website user. We use cookies to improve your user experience and for remarketing. Some of this data may be shared with select partners. See our [cookies policy](https://www.appsflyer.com/legal/cookie-policy/) for more information.

![Image 62: Company Logo](https://cdn.cookielaw.org/logos/static/ot_company_logo.png)

## Privacy Preference Center

When you visit any website, it may store or retrieve information on your browser, mostly in the form of cookies. This information might be about you, your preferences, or your device, and is mostly used to make the site work as you expect. The information does not usually identify you directly, but it can give you a more personalized web experience. Because we respect your right to privacy, you can choose not to allow some types of cookies. Click on the different category headings to learn more and change our default settings. Blocking some types of cookies may impact your experience of the site and the services we are able to offer.   

Allow All
### Manage Consent Preferences

#### Strictly Necessary Cookies

Always Active

Necessary Cookies are enabled for the assurance and function of a properly run website, and they cannot be disabled. They are usually only set in response to actions permitted by you, such as, enabling functions like navigation and access to secure areas of the website. These Cookies do not store personal information that will be used for other purposes.

#### Performance Cookies

Always Active

These Cookies provide us with aggregated (anonymous) insights into website enhancement and performance improvement. These cookies allow us to measure and improve the performance of our Sites. They help us know which pages are the most and least popular and see how visitors move around the website.

#### Functional Cookies

Always Active

These Cookies enable us to provide enhanced functionality and personalization through our Sites and allow for a better user experience. These may be set by us (first-party Cookies) or by third-party providers who work with us (third-party Cookies).

#### Marketing Cookies

Always Active

These cookies may be set through our site by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant adverts on other sites. They do not store directly personal information, but are based on uniquely identifying your browser and internet device. If you do not allow these cookies, you will experience less targeted advertising.

### Cookie List

Clear
*   - [x] checkbox label label 

Apply Cancel

Consent Leg.Interest

- [x] checkbox label label

- [x] checkbox label label

- [x] checkbox label label

Reject All Confirm My Choices

[![Image 63: Powered by Onetrust](https://cdn.cookielaw.org/logos/static/powered_by_logo.svg)](https://www.onetrust.com/solutions/consent-and-preferences/)

![Image 64](https://bat.bing.com/action/0?ti=12057351&tm=gtm002&Ver=2&mid=786158af-9038-4d92-b0b6-e38055d7f6ba&bo=1&sid=6dd16af0ddd311f1af7f5532648d363f&vid=6dd19470ddd311f180c0d1961063bf1c&vids=1&msclkid=N&pi=918639831&lg=en-US&sw=1280&sh=1280&sc=24&tl=AppsFlyer%20pricing%20%7C%20A%20plan%20for%20every%20marketing%20budget&p=https%3A%2F%2Fwww.appsflyer.com%2Fpricing%2F&r=&lt=1252&evt=pageLoad&sv=2&cdb=AQER&rn=401563)

![Image 65](https://id.rlcdn.com/464526.gif)
