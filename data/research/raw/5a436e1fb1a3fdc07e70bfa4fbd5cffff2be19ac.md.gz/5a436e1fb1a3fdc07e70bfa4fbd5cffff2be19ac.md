Title: How Many People Use Netflix’s Ad-Supported Plan?

URL Source: https://adwave.com/resources/netflix-ad-tier-subscribers

Published Time: 2025-11-18T00:00:00+00:00

Markdown Content:
*   70M

Netflix ad-tier monthly active users globally

*   40%

Share of new Netflix signups choosing ad tier

*   $6.99

Monthly cost of Netflix ad-supported plan

Netflix's ad-supported tier now reaches 190 million monthly active viewers globally, according to the company's [November 2025 announcement](https://deadline.com/2025/11/netflix-ads-1236606573/). In just three years since launching with ads, Netflix has built an advertising audience that rivals traditional television networks. For advertisers, this represents a fundamental shift: premium content that was once ad-free is now accessible to brands of all sizes.

## What the data shows

Netflix's advertising business has grown from zero to industry-leading scale in three years. According to Netflix's November 2025 update, the ad-supported tier reaches more than 190 million monthly active viewers globally. This represents the most detailed count Netflix has provided of its advertising audience.

In the United States specifically, [Comscore data](https://www.adweek.com/convergent-tv/netflix-ad-tier-household-viewing-hours-comscore/) shows that 45% of Netflix households now watch on the ad-supported tier. This is up from 34% in 2024. Nearly half of all Netflix viewing in America now includes advertising.

Netflix's total subscriber base provides context. With over 300 million paid memberships worldwide, the 190 million ad-tier viewers represent roughly 60% of Netflix's total audience when accounting for household co-viewing.

![Image 1: Netflix Ad Tier Subscribers Images - Netflix Ad Tier Growth](https://media.adwave.com/fia320z3blxi/sqi7U3yKjFZdtR8NcXsP4/671d105cbf6670e861726c5f7e7ca508/netflix-ad-tier-growth.png)
## Breaking down the numbers

Understanding Netflix's ad tier metrics requires examining several distinct measurements.

### Monthly active viewers vs. subscribers

Netflix's shift from reporting "monthly active users" to "monthly active viewers" reflects an important distinction. Monthly active users counted subscriber accounts accessing the ad tier. Monthly active viewers multiplies by co-viewing, capturing all people watching Netflix ads, not just the account holder.

### Household penetration in the U.S.

Comscore's finding that 45% of U.S. Netflix households watch on the ad tier provides a different lens on adoption patterns. Several factors drive this adoption: price sensitivity as streaming costs rise, tier restructuring that eliminated lower-priced ad-free options, and growing viewer acceptance of ads on streaming.

![Image 2: Netflix Ad Tier Subscribers Images - Us Household Penetration](https://media.adwave.com/fia320z3blxi/UjMZhHdlKe2U7BlaJxdSe/afaba2bb61b1e7cdcdc482e00ac60626/us-household-penetration.png)
## Why it matters for your business

Netflix's advertising transformation has implications for businesses across the advertising spectrum.

For large advertisers, Netflix offers premium inventory at premium prices with CPMs ranging from $25 to $65. The 190 million viewer audience provides scale comparable to traditional television events.

For small and mid-sized businesses, Netflix's growth matters even if direct Netflix advertising isn't accessible. The broader trend of premium streaming audiences becoming available to advertisers creates opportunity throughout the ecosystem. [Streaming TV advertising](https://adwave.com/resources/streaming-tv-ad-cost) through aggregated platforms enables small businesses to reach the same demographics that watch Netflix, just on different content.

![Image 3: Netflix Ad Tier Subscribers Images - Streaming Advertising Opportunity](https://media.adwave.com/fia320z3blxi/7HqRulZKtiD081QHKdP0AH/8507e42c2df047cb749913bf54cc546a/streaming-advertising-opportunity.png)
## How to take advantage of this trend

The growth of Netflix's ad tier reflects broader streaming advertising trends that benefit advertisers of all sizes.

While Netflix itself may be inaccessible to smaller advertisers, the streaming audience is reachable through other means. Aggregated platforms like [Adwave](https://adwave.com/how-it-works) enable advertising across 100+ streaming services, reaching the same viewers who watch Netflix when they're on other platforms.

The most effective [small business advertising strategies](https://adwave.com/resources/how-to-market-small-business-guide) combine streaming TV with search advertising, social media, and local targeting to reach customers at multiple touchpoints.

## The bigger picture

Netflix's advertising transformation reflects fundamental shifts in how video content is monetized and consumed. If Netflix has ads, every streamer can have ads. The expectation that streaming equals ad-free has been replaced by acceptance that ads are part of the streaming ecosystem.

Technology has enabled broader access. [AI tools generate broadcast-quality commercials](https://adwave.com/resources/ai-tv-commercials-small-business) in minutes from existing business content. The combination of accessible ad platforms and automated creative production means any business can advertise on streaming television.

## What experts are saying

Netflix noted it now has "thousands of advertising clients around the world" and has reached "critical scale" in all markets where the ad tier operates. Media analysts have highlighted the speed of adoption, with Comscore's finding showing 45% of U.S. Netflix households on the ad tier, up from 34% a year earlier.

## Common questions answered

Netflix's ad-supported tier reaches 190 million monthly active viewers globally as of November 2025. In the United States specifically, 45% of Netflix households watch on the ad-supported tier.

Netflix launched its ad-supported tier on November 3, 2022, initially called "Basic with Ads." The tier launched at $6.99 per month in the United States.

### How many ads do Netflix viewers see per hour?

Netflix serves approximately 4-5 minutes of advertising per hour of content, far less than traditional television which typically shows 15-20 minutes of ads per hour.

### Can small businesses advertise on Netflix?

Netflix's advertising is primarily designed for large brands with substantial budgets. However, small businesses can reach Netflix's audience demographic through other streaming platforms via aggregated services like [Adwave](https://adwave.com/resources/best-streaming-tv-advertising-platforms), which offer campaigns starting at $30 a day.

## Supporting data

Key statistics on Netflix's ad-supported tier:

*   Monthly active viewers (global): 190 million (Netflix, November 2025)

*   U.S. household ad-tier penetration: 45% (Comscore, August 2025)

*   U.S. household penetration 2024: 34% (Comscore, 2024)

*   Total Netflix subscribers: 300+ million (Netflix IR, 2025)

*   Ad tier launch date: November 3, 2022

*   Ad load: 4-5 minutes per hour

*   CPM range: $25-65

All sources linked above. Data current as of December 2025.

## Get started with streaming TV advertising

Netflix's 190 million ad-tier viewers demonstrate that premium streaming audiences are available to advertisers. While Netflix itself may require substantial budgets, the broader streaming ecosystem offers access to similar audiences at accessible price points.

[Adwave](https://adwave.com/) enables streaming TV advertising for businesses at any budget. Reach viewers on 100+ streaming services including Hulu, Peacock, Discovery, and more. Campaigns start at just $50, with AI-powered creative that generates broadcast-quality commercials from your website in minutes.

[See how it works](https://adwave.com/how-it-works) | [View pricing](https://adwave.com/pricing)
