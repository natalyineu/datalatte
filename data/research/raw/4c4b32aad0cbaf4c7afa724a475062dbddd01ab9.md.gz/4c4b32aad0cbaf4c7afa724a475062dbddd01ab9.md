Title: What to know about 3rd-party audiences and how to use them in campaigns

URL Source: https://www.stackadapt.com/resources/blog/third-party-audiences

Published Time: 2024-09-27T14:56:38+00:00

Markdown Content:
Reaching the right audience is one of the most important factors in the success of a digital marketing campaign. You can have [great creatives](https://www.stackadapt.com/our-solutions/creative-studio), but if you don’t reach the right audience, they’re unlikely to resonate.

There are so many types of [audience targeting](https://www.stackadapt.com/resources/blog/audience-targeting), it can be overwhelming to choose the best option for your brand and goals, especially if you’re focused on driving awareness, and don’t exactly know where to find your ideal customer.

That’s where 3rd-party audiences come in.

## **What is a 3rd-party audience**?

Third-party audiences are curated data sets made of specific segments collected and aggregated by data intelligence companies. These companies collect user data based on demographic characteristics (like age and household income), online behaviour (such as browsing history), and interests (including hobbies and shopping preferences) from various sources, including websites, apps, and data providers. This information is then organized into relevant audience segments that advertisers can use to expand their reach and improve the precision of their targeting.

## **What’s the difference between 1st-party and 3rd-party audiences?**

First-party audiences and 3rd-party audiences serve different purposes in digital advertising. Knowing when to use each type can improve your campaign results.

[First-party data](https://www.stackadapt.com/resources/blog/1st-party-data) is collected directly from a company’s website, app, or social media channels. It often includes valuable insights like demographic details, behavioural patterns, and user preferences. This data is particularly useful for creating targeted marketing campaigns, allowing companies to reach and engage existing customers and leads with [personalized messaging](https://www.stackadapt.com/resources/blog/b2b-first-party-data-personalization) that’s more likely to convert.

Third-party data, on the other hand, is collected externally and offers advertisers a wide range of information about potential customers, such as their online behaviour, demographic data, and purchase history. This data helps advertisers identify and target new audiences based on their interests and behaviours, allowing them to scale their campaigns beyond their existing customer base.

Although 1st-party and 3rd-party audiences both have their benefits, if you only relied on 1st-party audiences for your campaigns, you’d end up targeting the same group of people over and over again, increasing the likelihood of [ad fatigue](https://www.stackadapt.com/resources/blog/ad-fatigue) and limiting your reach. If you’re looking to expand your reach, 3rd-party data can help fill in the gaps. When used together, [studies show](https://digiday.com/media-buying/study-examines-combining-first-party-and-third-party-data-to-reach-wider-audiences-reduce-costs/) that 1st-party and 3rd-party data can improve brand favourability and purchase intent.

![Image 1: The differences between zero-party, 1st-party, 2nd-party, and 3rd-party data](https://www.stackadapt.com/main/wp-content/uploads/sites/2/2022/11/20240913_4-Different-Data-Types_graphic.webp?resize=1200%2C961)
## **Why use 3rd-party audiences in digital marketing?**

Third-party data gives you more data points than 1st and 2nd-party data alone, helping you reach a wider audience and providing information about users you wouldn’t have access to otherwise.

That’s why 3rd-party audiences are so important: they bring users to the top of the funnel, allowing you to reach new users who may not have previously interacted with your brand, but have shown interest in similar products or services. Your goal is to get enough scale to increase awareness while still ensuring you’re capturing the attention of individuals who are likely interested in learning more about your offering.

Once you have an idea of the types of users you want to target, you can leverage [lookalike audience targeting](https://www.stackadapt.com/resources/blog/leveraging-lookalike-audiences) to further expand your reach to additional users who share similar characteristics and behaviours with your target audience.

Finally, once your 3rd-party audiences and lookalike audiences have visited your site, you can convert them into 1st-party audiences for retargeting and conversion optimization. This is the ideal [full-funnel approach](https://www.stackadapt.com/resources/blog/executing-a-full-funnel-strategy) to audience targeting.

![Image 2: Marketing funnel with 3rd-party audiences at the top, lookalike audiences in the middle, and 1st-party audiences at the bottom](https://www.stackadapt.com/main/wp-content/uploads/sites/2/2022/11/Funnel.jpg?resize=710%2C450)
## **What’s an example of a 3rd-party audience segment?**

Third-party audience segments can come in various types and sizes. Depending on the campaign you’re looking to run and the ideal audience you want to reach, you can find an audience segment that should fit your specific criteria.

Here are some targeting examples based on specific industries and potential segments you could leverage in the StackAdapt platform:

#### [Automotive](https://www.stackadapt.com/resources/blog/automotive-digital-marketing-strategy/)

**Scenario:**Vehicle launch campaign to target households looking to buy a new SUV.

**Provider:**Polk Audiences from S&P Global Mobility

**Segment Name:**Polk Audiences by S&P Global Mobility > In Market > Body Style > Sport Utility Vehicle

**Segment Description:**Individuals interested in family cars based on automotive ownership data, surveys, online activity, and social media data.

#### [Healthcare](https://www.stackadapt.com/industry-solutions/healthcare/)

**Scenario:**Pharma brand prospecting people who are likely to be looking for treatment for chronic kidney disease.

**Provider:**PurpleLab

**Segment Name:**PurpleLab > US > B2C > Nephrology Conditions > Chronic Kidney Disease

**Segment Description:**Modeled audience of people who have chronic kidney disease.

#### [Travel](https://www.stackadapt.com/industry-solutions/travel)

**Scenario:** An airline looking to promote one of its routes from Gatwick Airport (UK) to New York.

**Provider:** Starcount

**Segment Name:**UK Starcount > Custom > AirlineX > Likely Airline Bookers

**Segment Description:** Individuals who live within a 2-hour radius of the airport, and have used the airport, associated transit rail, and parking in the past.

#### [Political & public affairs](https://www.stackadapt.com/industry-solutions/political)

**Scenario:** A client wants to persuade a Senator not to support an upcoming legislation or policy. (Senator XYZ = the name of a Senator the user is looking to target.)

**Provider:** Atlas Basic (via Unearth)

**Segment Name:**Atlas Basic > Political Influencers > U.S. Elected Official > Senator XYZ (R-ND) + Connections

**Segment Description:** Atlas Basic political audience for Senator XYZ, reaching 1st-degree friends, classmates, neighbours, donors, supporters, and constituents, plus 2nd-degree staff and consultant connections. Does not include family, personal associates, former colleagues, associates, journalists or opinion leaders.

With numerous data providers and segments available, it’s easy to incorporate 3rd-party audiences into your digital strategy. Here’s one way to get started.

### 1. Identify your buyer personas

Identify the goals and pain points of your customers and determine how your business can address them. Use this research to identify common characteristics with your ideal audience. By grouping these characteristics together, you can form the basis for your buyer personas.

### 2. Align your personas with 3rd-party audience segments

Determine the key characteristics of your buyer personas and match them with 3rd-party audience segments that share these traits. Look for segments that have similar attributes to those of your buyer personas.

For example, if your buyer personas include young professionals interested in fitness and wellness, you could leverage 3rd-party audience segments to target users who read health articles, go to the gym, or frequently browse workout gear online.

### 3. Build a campaign around those segments

Because 3rd-party audiences are best suited for top-of-funnel campaigns, you’ll likely use them in your prospecting to expand your reach to a wider audience. With the right targeting, you can use your creatives to capture the attention of highly-relevant users.

Once you have attracted new users through 3rd-party segments, you can retarget them with personalized ads or offers to encourage further engagement and move them down the funnel towards a conversion.

Want to learn more about 3rd-party audience segments and how you can use them to expand your reach and drive higher engagement with your target audience? [Request a demo](https://www.stackadapt.com/get-started) to learn more about StackAdapt.

## 3rd-party audience FAQs

### What are the benefits of 3rd-party audience data?

The benefits of 3rd-party audience data include expanding reach to new customers, enhancing targeting precision, and optimizing campaign performance. It offers valuable insights into potential customers’ demographics and behaviours, helping brands increase awareness, drive engagement, and improve their return on investment.

### What is 1st-party, 2nd-party, and 3rd-party data?

First-party data is information collected directly from users through interactions like website visits, purchases, or surveys, providing highly-accurate insights. Second-party data is another company’s first-party data shared through a partnership. Third-party data is aggregated by external providers and sold to businesses, broadening audience reach and improving targeting strategies.

### What are some examples of 3rd-party audience providers?

Examples of third-party audience providers include companies like Adsquare and Epsilon. These providers collect and aggregate data from various sources to create detailed audience segments, which advertisers can use to enhance targeting and reach new customers more effectively with their digital campaigns.
