Title: StackAdapt named 2026 Hermes Creative Awards Platinum winner

URL Source: https://www.stackadapt.com/resources/blog/hermes-creative-award-2026-platinum-winner

Published Time: 2026-04-20T16:54:43+00:00

Markdown Content:
**Toronto, ON****– April 20, 2026** – StackAdapt (www.stackadapt.com), the leading AI advertising and orchestration platform, has been named a Platinum winner in the Marketing Video, Service category at the 2026 Hermes Creative Awards for its [“Every Impression Builds Momentum” video series](https://www.youtube.com/watch?v=iE85eJ21e4Y). The same video series also earned both Gold and Platinum honors at the [Viddy Awards](https://enter.amcpros.com/viddy/winners/) for its video series and product marketing work.

The Hermes Creative Awards is one of the oldest and largest creative competitions in the world, recognizing outstanding work across the industry while honoring creative professionals involved in the concept, writing, and design of traditional and emerging media.

Developed as a true customer zero campaign, “Every Impression Builds Momentum” utilized the StackAdapt platform for planning, activating and optimizing the work as a reflection of the same data-driven strategy and execution the company delivers to marketers every day.

Previously named a Platinum winner at the [2024 Hermes Creative Awards](https://www.stackadapt.com/resources/blog/hermes-creative-awards-platinum-winner) in the Interactive Media and Digital Advertising category, this achievement marks the second time in three years that the company has received this honor. Together, these accolades reinforce the company’s continued investment in high-impact, results-driven creative.

“These accolades mean a lot because they reflect the level of creative ambition the team brought to this work,” said Christiana Marouchos, VP of Marketing at StackAdapt. “By building and running this campaign within our own platform, we connected creative, activation, and optimization in one place. There was a clear focus on creating something distinctive that would stand out, and the results reflect that.”

Hermes Creative Awards is administered and judged by the Association of Marketing and Communication Professionals (AMCP), one of the largest, oldest, and most respected evaluators of creative work in the marketing and communication industry. The international organization consists of several thousand marketing, communication, advertising, public relations, media production, and freelance professionals. AMCP oversees awards and recognition programs, provides judges, and rewards outstanding achievement and service to the profession.

AMCP judges are industry professionals who look for companies and individuals whose talent exceeds a high standard of excellence and whose work serves as a benchmark for the industry. Winners were selected from over 200 categories grouped under advertising, publications, marketing/branding, integrated marketing, public relations/communications, electronic media, and pro bono.

A list of Platinum and Gold Winners can be found on [the Hermes Creative Awards website](https://enter.amcpros.com/hermes/winners/).

**About StackAdapt**

StackAdapt is the leading AI advertising and orchestration platform marketers rely on to drive brand growth and revenue. Built entirely in-house with an easy-to-use interface, StackAdapt unifies programmatic and owned channels—including CTV, DOOH, display, native, audio, email, and more—into one seamless experience. The platform makes it easy to find the right audience, personalize creative, run campaigns, optimize, and measure results in one place. Trusted by the most forward-thinking brands and agencies, StackAdapt combines speed of innovation, deep vertical expertise, and partnership that powers real business growth. For further information, visit www.stackadapt.com.

**Media Contact**  
Alexis Gold  
