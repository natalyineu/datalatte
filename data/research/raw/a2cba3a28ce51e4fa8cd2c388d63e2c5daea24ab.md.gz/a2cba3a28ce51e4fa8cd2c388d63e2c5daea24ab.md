Title: TV dayparting: when local businesses should run ads

URL Source: https://adwave.com/resources/tv-dayparting

Published Time: 2026-10-28T00:00:00+00:00

Markdown Content:
TV dayparting is the practice of buying ad time in blocks of the broadcast day, such as early morning, daytime, early fringe, prime time and late fringe. Each block draws a different audience at a different price. On linear TV you buy those time slots directly.

Streaming TV is usually bought by audience, so a local business chooses dayparts for linear and chooses people and places for streaming.

## What TV dayparting means

A daypart is a segment of the broadcast day. Each segment carries its own type of programming and its own kind of viewer. Morning news draws people getting ready for work. Daytime shows reach people at home. Prime time pulls in the largest household audiences. Dayparting means placing your ads in the segments whose viewers match the customers you want. Broadcasters built their schedules around these blocks long before streaming existed. The [Wikipedia entry on dayparting](https://en.wikipedia.org/wiki/Dayparting) covers that history, including the decades when most stations signed off overnight.

The idea has since spread past TV and radio to online video and other digital channels, where advertisers schedule ads by time of day too. A quick-service restaurant might push breakfast ads in the morning and late-night ads after 10 p.m. For a local business weighing [TV advertising for small businesses](https://adwave.com/resources/small-business-tv-advertising), choosing dayparts is one of the decisions you’ll face whenever you buy linear airtime.

## The standard TV dayparts and their hours

No single official clock exists. Different stations and measurement firms draw the lines differently, and textbooks don’t always agree either. One ad-measurement platform sets prime time at 7 to 11 p.m. every day. A common advertising textbook splits off 7 to 8 p.m. as “prime access” and puts prime time at 8 to 11 p.m. The table below shows typical ranges. Treat them as a guide and confirm the exact hours on any quote you receive.

| Daypart | Typical hours | Who tends to watch |
| --- | --- | --- |
| Early morning | About 5 or 6 a.m. to 9 a.m., weekdays | People getting ready for work and school; morning news viewers |
| Daytime | About 9 a.m. to 4 p.m., weekdays | People at home: retirees, parents, shift workers |
| Early fringe | About 4 p.m. to 7 p.m., weekdays | Viewers coming home; local and evening news |
| Prime access | About 7 p.m. to 8 p.m. (used in some definitions) | Households settling in before prime time |
| Prime time | About 7 or 8 p.m. to 11 p.m. | The largest general audiences, usually at the highest prices |
| Late fringe | About 11 p.m. to 1 or 2 a.m. | Late news and talk show viewers |
| Overnight | About 2 a.m. to 5 or 6 a.m. | The smallest audiences of the broadcast day |
| Weekend morning | About 6 a.m. to noon, Saturday and Sunday | Families, kids’ programming, weekend news |
| Weekend daytime | About noon to 7 p.m., Saturday and Sunday | Sports and movie viewers, people planning errands |

Morning routines are the most predictable of these. People get ready for work and get kids off to school at roughly the same time each day, so the morning block reaches the same viewers consistently. Prime time costs the most because it gathers the most people at once. To see how daypart choice shows up in a rate card, read our guide to [what a local TV ad costs](https://adwave.com/resources/local-tv-ad-cost).

## How linear and streaming TV handle timing differently

Linear TV (broadcast, cable, and satellite) sells time on a schedule. You buy a slot in a program or a daypart, and everyone watching that channel at that moment sees the same ad. Targeting stays broad: geography, the show, and the time of day. Linear usually costs less per thousand viewers because you’re buying large audiences in bulk, though it often takes a bigger commitment and more lead time. Audiences are measured with panel data and ratings, so results are estimated rather than counted, and linear remains strongest for live sports and news, where older viewers still watch in real time.

![Image 1: Family watching television together in a lamplit living room while a teenager holds the remote](https://media.wavefront.adwave-apps.com/ws/ws_adwave/d0fa386addeebb2cb801db317b2b3c25147270e6797dffb68dbf153e7a82fb1e.jpg)

Streaming, or connected TV (CTV), works on a different model. Viewers choose what to watch and when, so a 9 p.m. time slot means far less, and streaming ads are usually bought as impressions served to a chosen audience, defined by age and interests as well as where someone lives. Two neighbors watching the same show can see different ads. Entry budgets tend to be smaller and setup faster, and you get delivery data plus site visits and conversions where tracking allows, though the cost per thousand viewers is usually higher because you’re paying for the targeting.

Universal Ads makes the same distinction in its [TV advertising guide for small businesses](https://www.universalads.com/article/tv-advertising-for-small-businesses-things-to-know). It describes traditional TV as broad local or regional exposure and CTV as audience-based targeting with campaign-level reporting. The shift toward streaming is large: Digital Applied, citing eMarketer, reports [CTV spend set to pass primetime](https://www.digitalapplied.com/blog/connected-tv-ctv-advertising-2026-performance-marketer-guide), projecting US CTV ad spend at $37.95 billion for 2026. The same report says eMarketer projects CTV upfront commitments will exceed primetime linear upfronts for the first time.

In practice, daypart selection is mainly a linear decision. On streaming, the main levers are who sees the ad and where they live. If you’re weighing [local versus national TV buys](https://adwave.com/resources/local-vs-national-tv-advertising), the same logic holds: linear sells you an hour on a channel, while streaming sells you people in a place.

## Which dayparts fit common local businesses

The pairings below are our suggestions to test, not measured results, so let your own response data decide which ones stay.

![Image 2: Homeowner drinking morning coffee in a sunlit kitchen with a television on in the background](https://media.wavefront.adwave-apps.com/ws/ws_adwave/3929ece097500996eefd5727242d1937d4de9f282669263141d644e442affbab.jpg)

Restaurants and cafes do best matching ads to the hour when people decide where to eat. Food advertisers often target breakfast and lunch, and some add a late-night window too. Early fringe also catches the “what’s for dinner” moment. Pair a specific offer, such as a weeknight family special, with a clear next step like reserving a table or ordering online.

Home services and repair businesses (HVAC, plumbing, roofing, cleaning) can use early morning to reach homeowners during predictable routines, and early fringe to reach them after work, when a broken appliance or a leaky faucet is on their mind. Lead with the service and the service area, and drive viewers to call or book an estimate.

Retail stores and boutiques tend to see weekend morning and weekend daytime reach people who are planning errands and shopping trips. Promote a weekend sale or a new arrival, and give viewers a reason to visit this Saturday.

If prime time is out of reach for an advertiser on a tight budget, advertising executive Robert Barrows suggests buying weekends or the late fringe window between 11:30 p.m. and 1 a.m. in [Spectrum’s small business TV advice](https://www.spectrum.com/business/small-business/insights/business-insights/how-to-effectively-utilize-tv-advertising-for-small-business). He also advises: “Buy a ton of frequency and pound your message home.” Cheaper slots let a small budget buy more repetitions instead of one expensive appearance.

The daypart and the message work together. A morning viewer and a late-night viewer are in different frames of mind, and some advertisers run different versions of a spot for each. Our guide on [creative for service and product businesses](https://adwave.com/resources/tv-ad-creative-service-vs-product-businesses) covers how to shape the spot itself.

## How to test dayparts without wasting budget

Treat your first campaign as a test. These steps keep it readable:

![Image 3: Restaurant owner reviewing notes at an empty table before opening, with a laptop and a cup of tea](https://media.wavefront.adwave-apps.com/ws/ws_adwave/effce21353ac072d4b568acb1456223bd94767041bcec85e70c3612364cca832.jpg)

1.   **Pick one goal and one conversion action.** Choose calls, bookings, form fills or store visits, and judge every daypart against that same single action.
2.   Install tracking on your site before you launch, and decide which actions you want to count. You can also give each action a dollar value so you can estimate return on spend. Adwave’s [FAQ on measuring leads and sales](https://adwave.com/help/faq) describes this setup for its own campaigns.
3.   Keep the creative fixed while you test timing. If you run the same ad in two or three dayparts or audiences and change nothing else, you can tell which slot is doing the work; change the ad and the timing together and you lose that signal.
4.   **Compare efficiency, not raw volume.** A busy slot like prime time can produce plenty of response and still cost more per lead than a quieter block, so look at cost per response for each daypart rather than total responses.
5.   Watch the short-term signals too. Keen lists [what to track after an ad airs](https://keends.com/blog/tv-ad-effectiveness/), including QR code scans and search lift along with site visits, while keeping in mind that some viewers act weeks later.
6.   Once you know which blocks perform, cut the dayparts that cost the most per result, move that budget to the winners, and test again.

Be realistic about what you can learn. Linear results are often estimated from panels rather than counted. A small budget also needs enough weeks to separate a real pattern from noise. For more on reading results, see our guides on [measuring TV ad response](https://adwave.com/resources/tv-advertising-attribution-small-business) and [performance TV on a local budget](https://adwave.com/resources/performance-tv-for-local-businesses).

## Where timing fits in an Adwave campaign

Adwave works the streaming way. You paste your website, and Adwave creates ads from it, such as image ads, social video and a TV spot, all of which you can review and edit before you pay. It then runs them on TV, search, social, and the web from one prepaid daily budget. On the [Adwave pricing page](https://adwave.com/pricing/), daily budgets run from $30 to $10,000, with no subscription tying you in.

Your levers are audience and area. You start from suggested customer profiles, then refine the ages and interests, and the locations you want to reach. From there you target a radius, a set of ZIP codes, a city, or the whole country, as [Adwave’s setup steps](https://adwave.com/how-it-works/) describe. Adwave buys media across the channels your campaign is eligible for. Your budget affects which channels run: TikTok starts from $91/day and is opt-in, and you must turn it on and connect your TikTok account.

Search covers the timing question from another angle: a search ad can appear whenever someone is actively looking for what you offer. Combining TV with search means the people your spot reaches can find you when they’re ready to act. To see how the channels work together under one budget, read our guide to [multichannel advertising for small businesses](https://adwave.com/resources/multichannel-advertising-small-business).
