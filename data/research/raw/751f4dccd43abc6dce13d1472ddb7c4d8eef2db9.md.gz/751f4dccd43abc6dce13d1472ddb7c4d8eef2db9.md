Title: CTV Dictionary: Your Guide to Connected TV Terms

URL Source: https://adsmanager.paramount.com/insights/what-is-ctv-advertising-definitions

Published Time: 2026-02-17T19:22:02.326Z

Markdown Content:
If you’ve ever searched “what is CTV?” or “what is CTV advertising?” you’re not alone. These terms get thousands of searches every month. (Yes, we did our SEO research. Consider this blog our official answer to the internet.)

As connected TV continues to reshape television advertising, the terminology can feel overwhelming. Between OTT platforms, CTV measurement, ROAS calculations, geo targeting, programmatic media buying, and full funnel marketing, it’s easy to get lost in the acronyms.

This CTV dictionary is your go-to reference guide. Whether you're new to streaming TV ads or refining your CTV advertising strategy, this glossary breaks down the most important terms in clear, practical language.

CTV (Connected TV) refers to any television that connects to the internet and streams video content. This includes:

*   Smart TVs
*   Streaming devices like Roku, Fire TV, or Apple TV
*   Gaming consoles
*   TVs connected to OTT platforms

In short, if a TV is streaming content through the internet, it qualifies as connected TV.

FYI: [CTV viewership](https://adsmanager.paramount.com/insights/report-ctv-advertising-vs-social-ad-performance) now represents a major share of total TV time, making it one of the most important advertising trends in modern media planning.

## CTV Ads

CTV ads are non-skippable video advertisements served within streaming TV content. They typically run for 15 or 30 seconds and appear full-screen.

[Best practices](https://adsmanager.paramount.com/insights/ctv-video-ad-creative-best-practices-holiday-advertising) to make TV ads engaging for streaming viewers:

*   Strong opening hook in the first 3–5 seconds
*   Clear, simple messaging
*   On-screen branding
*   Verbal and visual call-to-action

## CTV Ads Manager

A CTV ad manager is a campaign management advertising platform that allows advertisers to create, launch, and monitor ads across platforms. Typically includes build-in audience targeting and performance reports. Need an example? [Why not try out Paramount Ads Manager >](https://adsmanager.paramount.com/sign-up)

CTV ad measurement refers to tracking and analyzing the performance of streaming campaigns. Common CTV marketing metrics include:

### Brand Lift:

Measures the impact of advertising on awareness, perception, and purchase intent, often used to measure upper funnel impact beyond direct conversions.

### CTV CPMs (Cost per thousand impressions):

The cost to deliver 1,000 impressions with an ad.

Formula: (Total Spend ÷ Impressions) × 1,000

### CPL (Cost per lead):

The cost to generate one qualified lead from an ad.

### Impressions:

The total number of times an ad is served & seen by a viewer.

### ROAS (Return on Ad Spend):

Measures marketing investment ROI (return on investment) based on revenue generated for every dollar spent on advertising.

ROAS calculation formula: Revenue ÷ Ad Spend

### TV Attribution Analysis:

Measurement that connects CTV exposure to downstream actions such as website visits, app download, in-store visits, or purchases.

### VCR (Video Completion Rate):

The percentage of viewers who watch a video ad from start to finish.

Formula: Completed Views ÷ Total Impressions

## CTV Advertising

CTV advertising refers to video ads that run on connected TV devices through streaming services. Unlike traditional television advertising, CTV ads allow for:

*   Household-level targeting (ZIP code, age, gender, income)
*   Real-time campaign measurement and reporting
*   Attribution tracking
*   Retargeting across devices
*   Self-serve campaign creation through online advertising platforms

## CTV Audience Targeting

The ability to deliver ads based on geographic and demographic filters such as ZIP code, age, gender, or income. With CTV ad platforms like Paramount Ads Manager, you can target based on the following:

### Geo-targeting:

A targeting method that delivers ads based on geographic location, including Country, State, DMA (Designated Market Area), ZIP code, or radius targeting around a specific address. This is particularly valuable for local TV advertising and regional businesses.

### Contextual targeting:

[Contextual targeting](https://adsmanager.paramount.com/insights/ctv-contextual-targeting) serves ads based on the content being watched rather than individual user data. For example, running auto ads during sports content.

### Custom Audiences:

Custom audiences allow advertisers to target viewers using their own first-party data, like CRM email lists, website visitors, App users, and customer databases. These audiences can often be uploaded securely into a CTV advertising platform for retargeting.

### Insights & Behaviors targeting:

Uses aggregated data signals to reach viewers based on likely purchase intent or lifestyle characteristics. This targeting helps align ads with high-intent segments.

### Lookalike Audiences:

Groups of viewers who share similar characteristics with your existing customers or custom audiences. Using first-party data (like CRM lists or website visitors), advertising platforms analyze shared behaviors, demographics, or interests and identify new viewers who “look like” your best customers.

### Retargeting:

[Retargeting campaigns](https://adsmanager.paramount.com/insights/ctv-retargeting) deliver ads to users who have previously interacted with your brand. In CTV, retargeting can:

*   Re-engage website visitors on the big screen
*   Follow up CTV exposure with digital ads
*   Reinforce messaging across devices

## CTV Inventory

Connected TV inventory refers to the available ad placements within streaming TV content.

## Demand Generation

Marketing efforts designed to create awareness and interest in your product or service before a consumer is actively shopping, focusing on:

*   Brand awareness campaigns
*   Educational content
*   Thought leadership
*   Video advertising

Demand generation fuels the top of the funnel and strengthens long-term performance marketing results.

## Device Graph

Device graphs are a foundational component of modern CTV measurement and retargeting strategies, as they connect multiple devices (whether that's a connected TV, mobile phone, laptop, or tablet) to a single household or user profile.

By linking devices together, advertisers can:

*   Retarget viewers across screens
*   Measure cross-device performance
*   Improve attribution accuracy

The process of allocating budget across channels including CTV, search, and social.

## First-Party Data vs Third Party Data

### First-party data

Information a business collects directly from its own customers. Examples include:

*   Email subscribers
*   Website visitors
*   App users
*   Purchase history

First-party data is highly valuable in CTV advertising because it allows advertisers to build custom audiences and retarget known customers in a privacy-compliant way.

### Third-party data

Audience information collected and aggregated by external data providers. It is often used for:

*   Interest targeting
*   Behavioral targeting
*   In-market audience segments

As privacy regulations evolve, many advertisers are shifting toward greater reliance on first-party data in combination with contextual targeting.

## Frequency Capping

Frequency capping limits how often a viewer sees the same ad within a given time frame. (For example: No more than 3 impressions per household per day). Frequency capping helps:

*   Reduce ad fatigue
*   Improve viewer experience
*   Optimize media efficiency

## Funnel Marketing / Marketing Funnel

The practice of aligning campaigns to specific funnel stages in the customer journey:

### TOF (Top of Funnel) / Upper Funnel:

Focuses on awareness, with the goal to introduce your brand to new audiences

### MOF (Mid Funnel):

Focuses on consideration, with the goal to build trust, educate, and nurture interest

### BOF (Bottom of Funnel) / Lower Funnel:

Focuses on conversion, with the goal to drive direct action such as purchases or sign-ups

## Full Funnel Marketing

Running coordinated campaigns across all stages of the customer journey, from awareness through conversion.

## Incremental Reach

Incremental reach refers to the new audience exposure gained by adding a channel to your media mix.

In CTV advertising, incremental reach measures how many viewers you reached on streaming TV who were not exposed to your ads on social, search, or other platforms. CTV is often used specifically to:

*   Reach cord-cutters
*   Extend beyond social platform audiences
*   Reduce reliance on a single channel

## Incrementality Testing

Incrementality testing measures the true impact of an advertising channel by comparing exposed vs. non-exposed audiences.

##Media Buying Media buying is the process of purchasing advertising inventory across channels such as connected TV, social media, search, or display. It includes:

*   Selecting platforms
*   Negotiating pricing or CPMs
*   Choosing targeting parameters
*   Managing budgets
*   Optimizing performance

Media buying can be done manually, programmatically, or through a [self-serve advertising platform](https://adsmanager.paramount.com/sign-up) like Paramount Ads Manager.

## OTT (Over-The Top)

Refers to content delivered over the internet rather than through traditional cable or satellite providers.

So what’s the difference between CTV and OTT? All CTV is OTT, but not all OTT is CTV.

OTT includes:

*   Content watched on connected TVs
*   Content streamed on mobile devices
*   Content streamed on desktop

Still confused? Check out this blog post for the [full breakdown between CTV vs OTT](https://adsmanager.paramount.com/insights/ctv-advertising-examples).

## OTT Platform

An OTT platform is a streaming service that distributes video content via the internet. Examples include:

### Subscription video-on-demand (SVOD):

Subscription-based services with limited or no advertising.

### Ad-supported video-on-demand (AVOD):

Free or lower-cost streaming services supported by ads.Free or lower-cost streaming services supported by ads.

### Free ad-supported streaming TV (FAST):

Streaming channels that are free for viewers and supported entirely by advertising (i.e. Pluto TV). FAST channels have expanded connected TV inventory and increased advertiser access to cost-effective streaming audiences.

![Image 1: Defining and Clarifying the Streaming Video Universe - OTT CTV SVOD AVOD FAST vMVPD](https://adsmanager.paramount.com/api/files/image--36---1--lNuQE3K-KBf5DFK9QHiMAw.png)

## Performance Marketing

Campaigns optimized for measurable BOF outcomes such as:

*   Leads
*   Purchases
*   App installs
*   Revenue

## Programmatic Advertising

Programmatic advertising uses automated technology to buy and serve ads in real time. Instead of negotiating placements manually, advertisers set campaign parameters such as:

*   Audience criteria
*   Budget
*   Bid strategy

The platform automatically purchases available inventory that matches those criteria.

## Sales Funnel

The sales funnel focuses specifically on the revenue stage of the journey, where marketing efforts transition into qualified leads, sales conversations, and closed deals.

While the marketing funnel drives awareness and interest, the sales funnel converts that interest into revenue.

A self-serve advertising platform allows advertisers to create, manage, and optimize campaigns directly without relying on a third-party agency. Key features typically include:

*   Campaign creation tools
*   Audience targeting controls
*   Budget management
*   Creative upload or ad-building tools
*   Real-time reporting dashboards

Self-serve does not mean unsupported. Many platforms (like [Paramount Ads Manager](https://adsmanager.paramount.com/sign-up)) offer help centers, onboarding tools, or optional support teams.

##Sequential Messaging Sequential messaging is a strategy where viewers see a planned series of ads in a specific order. For example:

*   Awareness ad
*   Product feature ad
*   Offer or conversion ad

This approach supports full funnel marketing and builds stronger brand recall over time.

## Video Ads

Promotional videos used in streaming and digital platforms.

## Video Marketing

Using video content as part of a marketing strategy.

## Video Marketing Strategy

A structured plan for using video across funnel stages.

## Ready to put your new terms to work?

Now that you know what CTV is, how CTV advertising works, and how measurement fits into the bigger picture, the next step is applying it.

Connected TV is no longer a niche channel. It is a core part of modern digital media planning.

If you're ready to launch streaming TV ads with real-time measurement, household-level targeting, and premium inventory, you can explore a self-serve connected TV advertising platform built specifically for growing businesses.

[Sign up for Paramount Ads Manager today and get your brand on TV tomorrow. >](https://adsmanager.paramount.com/sign-up)
