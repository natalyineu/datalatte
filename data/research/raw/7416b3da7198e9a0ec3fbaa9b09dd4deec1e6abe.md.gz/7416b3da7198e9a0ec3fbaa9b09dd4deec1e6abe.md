Title: What is Hulu’s share of TV viewing? (Q2 2026)

URL Source: https://adwave.com/resources/hulu-tv-viewing-share-q2-2026

Published Time: 2026-07-21T00:00:00+00:00

Markdown Content:
*   ~5%

Disney's combined streaming share of U.S. TV viewing, including Hulu (April 2026)

*   ~64M

Hulu subscribers, as last officially reported (September 2025)

*   $50

Minimum to start advertising on connected TV with Adwave

Hulu no longer gets its own line in Nielsen's TV ratings. Since early 2025, Nielsen folds Hulu into a combined **Disney streaming bucket, Disney+, Hulu, and ESPN+ together, which held about 5% of all U.S. TV viewing in April 2026**. The last time Hulu was measured on its own, in December 2024, it accounted for about 2.5% of TV viewing. So the honest answer to "what's Hulu's share?" is that Hulu is a major piece of a Disney streaming portfolio that Nielsen now reports as one number.

For a small business, the exact percentage matters less than what Hulu represents: one of the original ad-supported streaming services, with roughly 64 million subscribers and a general-entertainment and live-TV audience that advertisers have been able to reach for years. Hulu helped prove that premium streaming and advertising go together, which is the whole foundation of affordable connected TV. Let's break down Hulu's Q2 2026 standing, why it's measured the way it is, and what it means for reaching its audience.

## What the data shows

[Nielsen's The Gauge](https://www.nielsen.com/data-center/the-gauge/) measures how Americans split their TV time, and until recently it reported Hulu as its own streaming service. That changed in January 2025, when Nielsen began grouping Disney's streaming apps together after Disney integrated Hulu and ESPN+ content into the Disney+ experience. Here's how the picture looks in the [April 2026 Gauge](https://www.nielsen.com/news-center/2026/sports-and-dramas-drive-april-viewing-patterns-in-nielsens-latest-gauge-reports/), released June 25, 2026:

*   **Disney streaming (Disney+, Hulu, ESPN+ combined):** about 5% of total TV viewing

*   **Hulu's last standalone figure:** about 2.5% of TV viewing, December 2024

*   **Total streaming:** a record 47.6% of all TV viewing

*   **For context, YouTube led all streaming at 13.4% and Netflix was second at 7.8%**

So there's no standalone Hulu percentage for 2026, and we're not going to invent one. Historically, Hulu ran around 3% of TV viewing across 2023 and 2024, peaking near 3.4% and landing at 2.5% in its final standalone month. Today that viewing is counted inside Disney's roughly 5% combined bucket. Hulu remains a substantial part of that total, anchored by general-entertainment programming and next-day broadcast shows.

That combined 5% sits inside a streaming category that hit a record 47.6% of TV viewing in April 2026, part of the broader shift we track in our [most-watched streaming service](https://adwave.com/resources/most-watched-streaming-service-q1-2026) rankings. Hulu is one of the services that helped build that streaming majority.

![Image 1: What is Hulu's share of TV viewing? (Q2 2026) - Body1](https://media.adwave.com/fia320z3blxi/jQEF7kYJLHMoGFzDuyJ2Q/f68c3bad0b439838bf84bf6b82be1bd4/body1.png)
## How Nielsen measures Hulu, and why April is the latest number

The reason Hulu disappeared as a standalone line isn't that it shrank, it's that Disney merged its streaming apps into one experience. When Hulu content became available inside the Disney+ app, Nielsen decided that crediting viewing between the services had become too tangled to split cleanly, so it began reporting them together.

A few points help you read Hulu's numbers correctly:

*   **Hulu isn't broken out anymore.** Since January 2025, Nielsen reports Disney+, Hulu, and ESPN+ as one combined figure of about 5%. No standalone Hulu percentage is published for 2026.

*   **2.5% was the last standalone reading.** In December 2024, Hulu's final month measured on its own, it held about 2.5% of TV viewing, fourth among streaming services that month.

*   **April 2026 is the latest confirmed month.** Nielsen delayed its March Gauge amid a methodology dispute, and a recalibrated version is expected in the fall. Every figure here reflects data through April 2026.

The takeaway is that Hulu is very much alive and widely watched, it's just measured as part of Disney's streaming whole now. For advertisers, what matters isn't the Nielsen line item, it's that Hulu's audience remains large, engaged, and reachable.

## Breaking down the numbers

Hulu's real scale shows up better in subscribers than in a viewing-share line. As of Disney's last official report, for the quarter ending September 2025, Hulu had about 64 million subscribers, making it one of the largest premium streaming services in the U.S.

Here's how Hulu's audience breaks down:

*   **Hulu total:** about 64.1 million subscribers, spanning the on-demand service and the live-TV bundle

*   **Hulu + Live TV:** about 4.4 million subscribers, the internet cable-replacement bundle with live sports and news

*   **Ad-supported base:** the large majority of Hulu subscribers watch with ads, since Hulu was built as an ad-supported service from launch

One important caveat: Disney stopped reporting subscriber counts starting in fiscal 2026, so 64 million is the most recent official figure rather than a live 2026 number. More recent counts come from third-party estimates. Either way, Hulu's subscriber base is enormous and heavily ad-supported, which is exactly what makes it valuable to advertisers. Our [Hulu subscriber count](https://adwave.com/resources/hulu-subscriber-count) page tracks the detail.

What makes Hulu distinct in the streaming market is its content mix. Where Disney+ is the family and franchise home, Hulu is Disney's hub for adult and general-entertainment programming, next-day broadcast episodes, FX originals like The Bear, whose fifth and final season premiered in June 2026, and a deep library. That general-entertainment focus gives Hulu an older, broader audience than Disney+, which matters for advertisers trying to reach adults rather than kids.

Hulu's live-TV side deserves its own note, because it shows how the cable audience is migrating. Hulu + Live TV is an internet-delivered bundle of live sports, news, and local channels, essentially cable over the internet, and at roughly 4.4 million subscribers it remains one of the larger virtual pay-TV services. In late 2025, Disney combined Hulu + Live TV with Fubo, creating one of the country's larger virtual pay-TV operations. For advertisers, the significance is that even Hulu's live-TV viewers, the ones watching sports and news that used to define cable, are now on connected TVs reachable through streaming ad inventory. The cord-cutting audience and the Hulu audience increasingly overlap on the same internet-connected screens.

## Hulu versus Disney+: two different audiences

Because Hulu and Disney+ now share a bucket in the ratings, it's easy to blur them together. For advertisers, though, they reach different audiences, and knowing the difference sharpens how you think about the streaming audience you're buying.

*   **Disney+ skews younger and family.** It's built around animation, franchises, and kids' content, watched heavily in households with children and often co-viewed by parents and kids together.

*   **Hulu skews older and general.** It's Disney's home for adult programming, next-day network episodes, FX dramas, and a broad catalog that reaches grown-up audiences who aren't necessarily watching cartoons.

*   **Hulu carries live TV.** The Hulu + Live TV bundle adds live sports, news, and local channels, reaching an audience Disney+ alone doesn't.

*   **Hulu is more heavily ad-supported.** Built ad-first since 2007, Hulu's base has always leaned toward ad-supported viewing, making it one of the deepest pools of premium ad inventory in streaming.

For a local business, the practical implication is that the broad, adult, general-entertainment audience Hulu represents is often a better match than a kids-and-family platform. When you reach across the connected TV ecosystem, you want that general audience in the mix, and Hulu-style inventory delivers it. The point isn't to buy Hulu specifically, it's to understand that the streaming audience includes distinct segments, and the general-entertainment segment Hulu pioneered is exactly the one most local advertisers are trying to reach.

## Why it matters for your business

Hulu was one of the first services to prove that people would watch premium streaming with ads, and that legacy is why it matters to a small business today. Hulu didn't add ads as an afterthought, it was ad-supported from the start, which built the model the entire industry now follows.

Hulu's ad audience is part of Disney's broader ad-supported reach, which spanned about 157 million monthly active users globally when Disney last disclosed the figure in early 2025, growing to 164 million by that May. A large share of that reach comes through Hulu, given how heavily ad-supported its base is. Here's why that matters for a local advertiser:

*   **General-entertainment inventory.** Hulu delivers adult, broad-audience programming, next-day network shows and originals, which reaches the kind of general audience most local businesses want, not just kids or sports fans.

*   **Ad acceptance is proven.** Hulu's viewers have watched with ads for nearly two decades. The premise that people accept ads on premium streaming, which underpins affordable [connected TV advertising](https://adwave.com/resources/what-is-connected-tv-advertising), was proven on Hulu first.

*   **Live TV in the mix.** Hulu + Live TV adds live sports, news, and local channels, extending Hulu's ad reach into appointment viewing that commands attention.

Now the practical part. A small business generally won't buy Hulu directly, since Disney's ad deals target large brands. What changed is that the premium ad-supported streaming category Hulu pioneered is reachable through connected TV at small-business budgets. Hulu proved the general-entertainment streaming audience will watch ads. The [connected TV advertising market](https://adwave.com/resources/ctv-advertising-market-size-q1-2026) is how a local business taps that same shift.

![Image 2: What is Hulu's share of TV viewing? (Q2 2026) - Body2](https://media.adwave.com/fia320z3blxi/3K8Q5bsUrPr5QaQXseMlME/6a072d195406eb53d661c4c0d07f647c/body2.png)
## How to take advantage

You can't buy a Hulu ad slot for $50 directly, but you can reach the same kind of general-entertainment streaming audience Hulu built, on the same connected TVs, at a local-business budget. Here's how to think about it.

*   **Reach the audience across services.** Hulu viewers also watch Roku channels, Tubi, Peacock, and dozens of other ad-supported apps. Running across that whole ecosystem builds the frequency any single service can't.

*   **Match your service area.** Set a geographic radius, usually 15 to 25 miles, so every impression reaches a potential customer nearby.

*   **Budget for repetition.** Plan enough spend to reach the same households several times over two to three weeks. On connected TV, meaningful frequency costs hundreds of dollars, not thousands.

*   **Let AI make the ad.** You don't need a studio. AI tools turn your existing website into a broadcast-quality 30-second ad in about two minutes.

*   **Measure brand lift.** Track branded search, direct traffic, and calls during and after a campaign rather than chasing clicks.

The mechanics are simple. With Adwave, ad creation is free, a campaign starts at a $30-a-day minimum, and you can be live across 100+ premium streaming channels in under 10 minutes. You point it at your website, it builds the spot, and you're advertising on the same class of premium, ad-supported connected TV inventory that Hulu helped pioneer. For what that budget buys, our guide to the [average CTV CPM](https://adwave.com/resources/average-ctv-cpm) lays out the costs.

![Image 3: What is Hulu's share of TV viewing? (Q2 2026) - Body3](https://media.adwave.com/fia320z3blxi/4h0HW7N9UABYwT8sZn9nYe/9c8a2d0252bf9c86b90cbd21ec57cbf9/body3.png)
## The bigger picture

Hulu's shift from a standalone Nielsen line to part of Disney's streaming bucket mirrors a larger consolidation reshaping streaming, and understanding it helps you see where the audience and the ad dollars are heading.

A few forces give Hulu's Q2 2026 standing its context:

*   **Consolidation is the theme.** Disney pulled Hulu tighter into Disney+ to create a single, larger streaming destination. As of 2026, Hulu content lives inside Disney+ as a hub, though the standalone Hulu app and subscription still exist, and Disney has said it has no current plans to retire them.

*   **Ad-supported streaming keeps growing.** Hulu's original ad-supported model is now the industry norm, with the majority of new sign-ups across premium services choosing ad tiers. Our [ad-supported streaming viewers](https://adwave.com/resources/ad-supported-streaming-viewers) page tracks how large that audience has become.

*   **Live TV is migrating too.** Hulu + Live TV, combined with the Fubo deal Disney struck in late 2025, shows even the live-TV bundle moving to internet delivery, keeping that audience in the connected TV ecosystem.

For small businesses, the throughline is that Hulu's audience, wherever Nielsen files it, is part of the ad-supported connected TV market you can now reach. Hulu spent years proving that premium streaming and advertising work together. That proof is exactly what makes connected TV affordable and effective for a local business today.

## What experts are saying

Industry analysts view Hulu's absorption into the Disney streaming bundle as a natural step in Disney's platform strategy, not a sign of decline. Hulu remains one of the most-watched and most heavily ad-supported streaming services in the country, and its general-entertainment library gives Disney a reach beyond the family-and-franchise core of Disney+. Disney's own framing emphasizes engagement and advertising over subscriber counts, which is why it stopped reporting Hulu's numbers separately.

Hulu helped establish premium ad-supported streaming. Small businesses can reach viewers through platforms that buy inventory across streaming services.

## What the numbers don't tell you

Hulu's data comes with real caveats, so read it carefully.

*   **There's no standalone Hulu viewing number for 2026.** Hulu is inside Disney's combined roughly 5% streaming figure. Anyone citing a precise standalone Hulu Gauge percentage for 2026 is using an outdated or invented figure. The last real standalone reading was 2.5% in December 2024.

*   **Subscriber counts are frozen.** Disney stopped reporting Hulu subscribers in fiscal 2026, so 64 million is the last official figure, not a current one.

*   **Hulu's brand is evolving.** Hulu content now lives inside Disney+ as a hub, and full integration is underway, though the standalone app persists for now. The Hulu name may change form over time even as the audience stays.

*   **Viewing share understates reach.** A 2.5% standalone figure, or a share of Disney's 5%, undersells an audience of roughly 64 million subscribers who watch heavily and mostly with ads.

Read Hulu's numbers as proof of a large, durable, ad-friendly audience: one of streaming's original ad-supported services, now measured as part of Disney but as watched and as valuable to advertisers as ever.

The disappearing standalone line is, in a way, a sign of Hulu's success rather than its decline. Disney folded Hulu into a unified experience precisely because streaming had become central enough to the company's future to warrant one flagship destination. Hulu's audience didn't scatter, it got consolidated into a bigger platform, and its ad-supported DNA spread across the entire streaming industry. A service that changed how television gets watched and paid for doesn't need its own row in a ratings chart to matter to advertisers. What matters is that its audience is still there, still watching, and still reachable.

## Common questions answered

**What is Hulu's share of TV viewing?** Nielsen no longer reports Hulu on its own. Since January 2025, Hulu is counted inside a combined Disney streaming figure, Disney+, Hulu, and ESPN+, which was about 5% of U.S. TV viewing in April 2026. Hulu's last standalone reading was about 2.5% in December 2024.

**Why isn't Hulu measured separately anymore?** Disney integrated Hulu and ESPN+ content into the Disney+ app, which made it hard for Nielsen to credit viewing cleanly between the services. So in January 2025, Nielsen began reporting Disney's streaming apps as one combined bucket rather than splitting Hulu out.

**How many subscribers does Hulu have?** As of Disney's last official report, for the quarter ending September 2025, Hulu had about 64.1 million subscribers, including roughly 4.4 million on Hulu + Live TV. Disney stopped reporting subscriber counts in fiscal 2026, so more recent figures come from third-party estimates.

**Can a small business advertise on Hulu?** Not directly, in most cases, since Disney's ad deals target large brands. But the premium ad-supported streaming audience Hulu pioneered is reachable through connected TV at small-business budgets. With Adwave, you can run 30-second ads across 100+ premium streaming channels from a $30-a-day minimum, reaching the same general-entertainment living-room audience Hulu built without a national contract or a Disney-scale budget.

**How much does streaming TV advertising cost?** The [average CTV CPM](https://adwave.com/resources/average-ctv-cpm) runs roughly $15 to $35, and with Adwave a campaign starts at a $30-a-day minimum with free ad creation. That reaches the general-entertainment streaming audiences Hulu and the wider streaming shift created, without a national-brand budget.

## The numbers at a glance

Key figures behind Hulu's Q2 2026 standing, with sources:

*   **~5%**: Disney's combined streaming share of U.S. TV viewing, including Hulu (Nielsen, The Gauge, April 2026)

*   **2.5%**: Hulu's last standalone TV viewing share, December 2024 (Nielsen, The Gauge)

*   **47.6%**: total streaming share of U.S. TV viewing, a record (Nielsen)

*   **~64.1 million**: Hulu subscribers, as last officially reported in September 2025 (Disney)

*   **~4.4 million**: Hulu + Live TV subscribers (Disney)

*   **157 million / 164 million**: Disney's global ad-supported reach, early and mid 2025, which includes Hulu viewers (Disney)

*   **2007**: the year Hulu launched as an ad-supported service, pioneering the model (Hulu)

## Reach Hulu-style audiences, starting at $30 a day

Hulu is one of streaming's largest and most heavily ad-supported services, now measured as part of Disney's roughly 5% combined streaming share. Whatever line Nielsen files it under, Hulu's general-entertainment audience is part of the connected TV market any business can now reach.

You don't need a Disney-sized budget to reach premium streaming viewers. See [how Adwave works](https://adwave.com/how-it-works) to turn your website into a broadcast-quality 30-second ad in minutes, or check [pricing](https://adwave.com/pricing) to launch a connected TV campaign from a $30-a-day minimum. The premium screen opened up. It's a good time to be on it.
