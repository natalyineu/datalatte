Title: Claude Code Pricing 2026: Plans, Limits, and Hidden Costs

URL Source: https://www.superblocks.com/blog/claude-code-pricing

Published Time: 2026-06-19

Markdown Content:
Confused by Claude Code pricing in 2026? Plans range from $0 to $200/month for individuals and $20 to $125/seat for teams, with **weekly usage limits that can automatically switch a subscription to pay-per-token mode** without warning. Comparing it with Cursor? See our [Cursor vs Claude Code](https://www.superblocks.com/blog/cursor-vs-claude-code) breakdown.

## **Claude Code pricing at a glance**

Claude Code ships inside Anthropic's paid Claude plans. The same subscription covers **Claude on web, desktop, and mobile, as well as the Claude Code command-line tool**.

Here's how the pricing tiers compare:

| Plan | Starting price | Best for |
| --- | --- | --- |
| [Free](https://claude.com/pricing) | $0 | Casual Claude use (Claude Code not included) |
| [Pro](https://claude.com/pricing) | $20/mo or $17/mo annual | Daily individual coding |
| [Max 5x](https://claude.com/pricing) | $100/mo | Heavy individual coding |
| [Max 20x](https://claude.com/pricing) | $200/mo | Daily power users |
| [Team Standard](https://claude.com/pricing) | $25/seat/mo or $20 annual | Teams of 5 to 150 |
| [Team Premium](https://claude.com/pricing) | $125/seat/mo or $100 annual | Power users on teams |
| [Enterprise](https://claude.com/solutions/enterprise) | $20/seat + usage | Large organizations |
| [API](https://claude.com/pricing#api) | Pay per token | Developers using Claude programmatically |

_Pricing correct as of June 2026. See_[_Anthropic's pricing page_](https://claude.com/pricing)_for the latest rates._

## **How Claude Code pricing works**

Anthropic bundles Claude Code into subscription plans alongside **Claude.ai chat and Claude Cowork**. A Pro subscription covers all three under one price, with usage shared across them.

That bundling has two implications worth understanding before you pick a plan.

First, your Claude Code usage **counts against the same limits as your Claude chat usage**.

If you spend the morning chatting with Claude in the browser and then switch to Claude Code in your terminal, both eat into the same five-hour session and weekly caps.

Second, the per-token cost of Claude Code through a subscription is **effectively much lower than the same usage on the API**, but only until you hit your plan's limit.

After that, you either wait for the reset or pay for additional usage at API rates.

## **Free plan and why Claude Code isn't included**

The Free plan gives you access to Claude on web, iOS, Android, and desktop, but **does not include Claude Code**. If you want to try Claude Code without paying upfront, the lowest-cost path is one month of Pro at $20.

What the Free plan does include:

*   Chat on web, iOS, Android, and desktop.
*   Generate code and visualize data **inside chat**.
*   Web search and memory across conversations.
*   Create files and execute code **(with limits)**.
*   Connect Slack and Google Workspace services.
*   **Extended thinking** for complex work.

What's missing for developers:

*   **No Claude Code** (terminal access **requires Pro or higher**).
*   **No Claude Cowork** (the desktop file and task agent).
*   **Limited usage** that kicks in fast on coding-heavy work.
*   **No access to all models** (Opus 4.8 and Fable 5 are gated to paid tiers).

The Free plan works for evaluating Claude's writing and chat capabilities. **Claude Code itself requires a paid plan** to test meaningfully.

See [Anthropic's Free plan page](https://claude.com/pricing) for current feature parity and limits.

## **Pro plan for daily individual coding**

The Pro plan is the **entry point for using Claude Code**. At $20/month on a monthly plan or $17/month on an annual plan ($200 upfront), it covers a single user across all three Claude products.

What you get on Pro:

*   **Claude Code in your terminal:**with shared usage limits across Claude products.
*   **Claude on web, desktop, and mobile:**with the full chat experience.
*   **Claude Cowork:**desktop agent for file and task automation.
*   **Access to Claude's full model lineup:** Opus 4.8 for ambitious agentic coding, Sonnet 4.6 for the best mix of capability and price, and Haiku 4.5 for fast, low-cost runs. Fable 5 access ships in [promotional mode](https://support.claude.com/en/articles/15424964-claude-fable-models-on-your-plan) on consumer plans (prior to June 12, 2026).
*   **Claude for Microsoft 365 and Claude for Microsoft Outlook:** two distinct integrations covering Office documents and email respectively.
*   **Unlimited projects:**to organize chats, code, and knowledge bases.

Usage limits reset weekly and across **five-hour sessions**, with the exact token count Anthropic permits varying by model selection.

Most light-to-moderate Claude Code users (a few hours per day, mainly Sonnet) stay within Pro limits. **Heavy Opus users on large repositories** typically hit caps and need Max.

See [Anthropic's Pro plan page](https://claude.com/pricing) for current pricing and feature details.

## **Max plan for heavy individual users**

The Max plan is for individual developers who **consistently hit the Pro limits** while coding. It comes in two tiers.

**Max 5x ($100/month):**

*   5x Pro capacity per five-hour session.
*   Higher output limits for all tasks.
*   Early access to advanced Claude features.
*   Priority access during high-traffic periods.

**Max 20x ($200/month):**

*   20x Pro capacity per five-hour session.
*   Everything in Max 5x with substantially higher caps.

For Claude Code specifically, the jump from Pro to Max 5x makes sense if you **regularly hit usage limits during the workday**, especially when running multi-step coding tasks on large repositories with Opus.

Max 20x is for power users who treat Claude Code as their primary coding tool and run it for several hours a day.

The math: $200/month is roughly **$6.67/day**, which beats the API rate for sustained Opus usage.

See [Anthropic's Max plan page](https://claude.com/pricing) for current pricing and capacity-per-session figures.

## **Team plan for collaborative teams**

The Team plan is the entry-level option for organizations that want Claude Code (plus Claude chat) for multiple people under **centralized billing and admin controls**. It requires a minimum of 5 members and tops out at 150 seats.

Team plans come in two seat types you can mix within the same organization:

**Standard seats:**

*   $25/seat/month on a monthly plan or $20/seat/month on an annual plan.
*   More usage per session than Pro.
*   Single sign-on (SSO) and domain capture.
*   Admin tools and billing management.
*   **Claude Code is not included on Standard seats** (Premium only).

**Premium seats:**

*   $125/seat/month on a monthly plan or $100/seat/month on an annual plan.
*   5x more usage per session than Standard seats.
*   Same governance features as Standard, with higher caps.
*   **Includes Claude Code access** alongside the other Claude apps.

Premium seats are the only Team option that bundles Claude Code, while both seat types include Claude Cowork, enterprise search, and connectors to **Microsoft 365, Slack, GitHub, Google Drive, and Gmail**.

Team plans also support purchasing usage credits that let members continue working after hitting their seat's included limits.

That's the lever to pull if some users consistently exceed their Standard seat capacity **without a valid justification for a Premium upgrade**. Organizations with more than 150 seats need to upgrade to Enterprise.

See [Anthropic's Team plan page](https://claude.com/pricing) for current per-seat pricing and feature parity.

## **Enterprise plan for large organizations**

The Enterprise plan is built for larger organizations that need everything in Team plus **deeper governance, advanced identity management, and tailored procurement terms**. Pricing starts at $20/seat with usage billed at API rates.

What Enterprise adds over Team:

*   **Role-based access control:**with fine-grained permissioning.
*   **SCIM provisioning:**for automated user lifecycle management.
*   **Audit logs and Compliance API:**for observability and monitoring.
*   **Custom data retention controls:**for regulated industries.
*   **Network-level access control:**and IP allowlisting.
*   [**HIPAA-ready offering**](https://support.claude.com/en/articles/13296973-hipaa-ready-enterprise-plans)**:**available for healthcare deployments.
*   **Claude Security (beta):**for security teams investigating threats.

**Enterprise pricing separates access from usage:** $20/seat covers platform access, while usage is billed separately at API rates.

That model favors organizations with variable usage across their workforce, since light users don't subsidize heavy ones.

For larger contracts, Enterprise also supports **invoicing, net terms, AWS Marketplace, and non-standard MSAs** through Anthropic's sales team.

See [Anthropic's Enterprise plan page](https://claude.com/solutions/enterprise) for current pricing and feature details.

## **Claude API pay-as-you-go pricing for developers**

Claude Code also accepts **API credits as authentication** and billing usage at standard per-token rates.

This makes sense for developers running intensive sprints or for teams already using Claude through Anthropic's API.

**Current API pricing for the most-used Claude models:**

| Model | Input | Output | Cache write | Cache read |
| --- | --- | --- | --- | --- |
| Fable 5 | $10/MTok | $50/MTok | $12.50/MTok | $1/MTok |
| Opus 4.8 | $5/MTok | $25/MTok | $6.25/MTok | $0.50/MTok |
| Sonnet 4.6 | $3/MTok | $15/MTok | $3.75/MTok | $0.30/MTok |
| Haiku 4.5 | $1/MTok | $5/MTok | $1.25/MTok | $0.10/MTok |

**_Note:_**_As of June 12, 2026, Anthropic removed access to Fable 5 and Mythos 5 for all users in response to a_[_US export control directive_](https://www.anthropic.com/news/fable-mythos-access)_that bars access by foreign nationals. Other Claude models are unaffected._

MTok = million tokens. **Prompt caching can dramatically reduce costs** for repeated prompts, especially in codebases where the same context is loaded repeatedly.

**Important catch:**If you have an ANTHROPIC_API_KEY environment variable set, Claude Code authenticates with the API key, charging your API account at pay-per-token rates.

Many developers get surprised by API bills this way.

To stick with your subscription, run **"claude logout"** and re-authenticate using only your Pro or Max credentials. To allow API credit fallback when subscription limits hit, leave the environment variable set.

See [Anthropic's API pricing page](https://claude.com/pricing#api) for the latest per-token rates and prompt caching details.

## **Which Claude Code plan should you choose**

The right plan depends on whether you're an individual developer, part of a team, or running Claude Code at organizational scale. Here's how to map the decision.

**Choose Pro ($17-$20/month) if you:**

*   Are an **individual developer** using Claude Code for daily coding work.
*   Want the cheapest legitimate way to access Claude Code.
*   Don't hit Pro's usage limits more than **once or twice a week**.

**Choose Max 5x ($100/month) if you:**

*   **Regularly hit Pro limits** during the workday.
*   Run multi-step coding tasks on **larger repositories**.
*   Want priority access during high-traffic periods.

**Choose Max 20x ($200/month) if you:**

*   Treat Claude Code as your **primary coding tool**.
*   **Run Opus heavily** for hours every day.
*   Want the highest individual capacity Anthropic offers.

**Choose Team ($20-$125/seat/month) if you:**

*   Have **5 or more developers** who need Claude Code access (**requires Team Premium seats at $100-$125/seat/month**, since Standard seats don't include Claude Code).
*   Need SSO, domain capture, and centralized billing.
*   Want a mix of Standard and Premium seats for different user types.

**Choose Enterprise ($20/seat + usage) if you:**

*   Have **more than 150 seats** or need **RBAC, SCIM, and audit logs**.
*   Operate in a **regulated industry** (financial services, healthcare, government).
*   Need custom MSAs, invoicing, or AWS Marketplace procurement.

**Choose API pay-as-you-go if you:**

*   Build agents, tools, or integrations that **programmatically call Claude**.
*   Have **spiky usage** that doesn't fit a flat monthly subscription.
*   Already manage Anthropic API credits for other workloads.

## **When AI work moves beyond CLI coding**

Claude Code is exceptional at **terminal-based coding for individual developers and engineering teams**. It's the right tool when you're generating code, refactoring repositories, or running coding tasks directly from the command line.

The picture changes when your AI work moves beyond code generation into **building internal apps that business teams use**, with a UI, role-based permissions, and audit trails on every action.

That's a different category from CLI coding, and where governed AI app platforms come in.

[Superblocks](https://www.superblocks.com/) is one of these platforms, with [Clark AI](https://docs.superblocks.com/building-with-clark) (its app-building agent) powered by Claude Opus. Business teams can build apps from natural-language prompts, while IT configures the guardrails **(RBAC, SSO, audit logs, BYO inference)** once and applies them to every app the platform produces.

For teams who want Claude Opus paired with governance for business-team app building, our [introduction to Superblocks](https://docs.superblocks.com/getting-started/what-is-superblocks) walks through the setup.

Or [book a demo](https://www.superblocks.com/book-a-demo) to test it with your own stack.

## **Frequently asked questions**

### **Is Claude Code free?**

No. Claude Code requires a Pro, Max, Team Premium, or Enterprise subscription starting at $20/month on a monthly plan (or $17/month with an annual plan), or you can pay per token through the Claude API.

### **How much does Claude Code cost per month?**

Claude Code costs **$20/month on Pro monthly** (or $17/month annual), $100/month on Max 5x, $200/month on Max 20x, or $100-$125/seat/month on Team Premium seats (Standard seats don't include Claude Code), plus optional API credits if you exceed limits.

### **Does Claude Code count against my Claude usage limits?**

Yes, Claude Code shares usage limits with the Claude chat interface across all paid plans, meaning every coding session counts against the same **five-hour session and weekly usage caps** that apply to web, desktop, and mobile chats.

### **What's the difference between Pro and Max for Claude Code?**

The difference between Pro and Max for Claude Code is **usage capacity**: Pro gives you standard access at $17-20/month; Max 5x gives 5x more capacity per session for $100/month; and Max 20x gives 20x more capacity for $200/month.

### **Can I use Claude Code with API credits instead of a subscription?**

Yes, Claude Code accepts API credits directly through a Claude Console account, charging **standard API rates per token** ($3 to $5 per million input tokens depending on the model).

### **Is Claude Code worth it compared to GitHub Copilot or Cursor?**

Claude Code is worth it for developers who prefer **terminal-based workflows to IDE plugins, want access to Claude Opus**for complex coding tasks, and already use Claude.ai, since one Pro or Max subscription covers both products.
