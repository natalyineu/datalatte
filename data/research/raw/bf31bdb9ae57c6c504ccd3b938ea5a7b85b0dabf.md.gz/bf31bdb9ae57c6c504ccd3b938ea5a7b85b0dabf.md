Title: Top 5 benefits of native outstream video

URL Source: https://www.stackadapt.com/resources/blog/benefits-of-native-outstream-video

Published Time: 2023-09-28T17:00:00+00:00

Markdown Content:
Video advertising is the perfect programmatic advertising channel for creating an emotional connection between a brand and an audience. This medium captures undivided attention, and provides an opportunity to educate viewers, build brand awareness, and develop trust.

[Video advertising](https://www.stackadapt.com/video-advertising) allows you to reach potential customers wherever they may be watching video content online. Depending on the type of video ad format you leverage, audiences might see a video ad before streaming a TV series, or while scrolling through a blog.

There are 3 main [programmatic video ad types](https://www.stackadapt.com/resources/blog/programmatic-video-advertising) that you can leverage in programmatic campaigns: In-stream, interstitial, and native outstream.

*   In-stream is a classic video advertising format. This short-form video ad is delivered before, during, or after a user’s intended video.
*   Interstitial video expands to fill a mobile screen.
*   Native outstream is a non-intrusive user experience because it delivers video ads between the paragraphs of an article. The outstream format delivers high-performing video content that plays only when in view.

Let’s unpack what native outstream video is, and the 5 benefits of this type of programmatic video ad.

## What is native outstream video

Native outstream video is an ad unit that doesn’t interrupt a user’s experience. It’s “native” because the video content seamlessly fits in with the content around it. It’s “outstream” because the video autoplays in a large format player whenever a user navigates to it within text content, like a blog article.

**What is outstream vs. instream video?**

Outstream ads automatically play when a user scrolls over a video, and then pauses when the user scrolls away. An outstream video ad unit is also commonly called ‘in-read’ or ‘native video.’ Meanwhile, instream ads start playing during a video, and play for several seconds before the user is able to skip them.

## An example of native outstream video

One example of native outstream video is when a user is scrolling through a blog article. As the user scrolls past the video, which is placed between paragraphs, the video will start to play. At this moment, that user’s attention may be captured by the video ad. If they continue scrolling, the video will automatically stop.

![Image 1: Animation of an outstream video ad](https://www.stackadapt.com/main/wp-content/uploads/sites/2/2023/09/Native-Outstream-1.gif?resize=700%2C700)
## 5 benefits of native outstream video

Here are the top 5 benefits of native outstream video.

### 1. Native outstream video is always viewable

The native outstream format was born at a time when publishers were already taking the mobile-first approach to building their properties. As a result, this ad format is viewable by design. Native outstream video auto-plays only when in view and pauses if the viewer scrolls past. Since playtime is not forced, but is determined by user activity, this format delivers advertisers deep, accurate data.

### 2. Native outstream delivers true completions

Unlike pre-roll video that doesn’t pause when a user scrolls past, completions for native outstream video are ‘true’ in the sense that the video only plays through while in view. This means, every video completion was actually watched by the user from start to finish.

### 3. Massive scale on tier 1 publishers

Video advertising on tier 1 publishing websites has typically been reserved for direct deals, due to the limited inventory designed for pre-roll format. Native outstream allows tier 1 publishers to monetize both video content and editorial content. This additional scale gives advertisers access to hundreds of tier 1 publishers, and most notably, scale programmatically run campaigns.

### 4. Support for long form format

With more brands looking to create value-adding content, the length of videos has gone up significantly. The barrier that many marketers are running into is that most pre-roll inventory supports video up to 30 seconds. The native outstream format provides marketers with a content distribution channel for long-form video.

### 5. Native outstream delivers performance

Automatic video play and pause makes this format highly viewable. It also guarantees that completed views accurately demonstrate user intent than more traditional formats. Because of the scale of inventory and the non-interruptive nature of the format, marketers find native outstream very effective for achieving their [programmatic KPI goals](https://www.stackadapt.com/resources/blog/programmatic-kpis-explained) when measuring cost per completed view (CPCV).

## Get started with native outstream video

Organizations that value audience engagement through storytelling are leveraging compelling video content that speaks to their audiences, and they’re leveraging the native outstream format to distribute their content.

When including native outstream video as part of your media mix, consider a holistic approach. Leverage these ads as part of a [multi-channel strategy](https://www.stackadapt.com/resources/blog/multi-channel-strategy). Integrate display to supplement inventory and increase reach and product recognition, and use [native ads](https://www.stackadapt.com/resources/blog/native-advertising-explained-examples) to drive interest and engagement.

_I_ nterested in running native outstream video ads? [Request a demo](https://www.stackadapt.com/get-started?utm_source=stackadapt&utm_medium=blog&utm_campaign=demo_request) to learn more about StackAdapt.
