Title: TV Buying, Now Built Into the Platforms You Already Use

URL Source: https://www.universalads.com/blog/tv-buying-into-the-platforms-you-already-use

Published Time: 2026-10-28T21:46:56.726Z

Markdown Content:
![Image 1](https://cdn.prod.website-files.com/67531bf977554bf997f89ef9/6ae22fb3e3a5056259d8f0d0_Campaign%20Management%20Announce.png)

## **TV Buying, Now Built Into the Platforms You Already Use**

###### **_The Business Partners Program expands with a new Campaign Management category, bringing TV advertising into the platforms brands already use, with launch partners including Adlyse, Atrium, Concord, Kochava, Koddi, Olyzon, Orbee, Scale Up, SearchKings, Stellair AI, Topsort, and WorkMagic._**

[Universal Ads](https://www.universalads.com/)has launched a brand-new category within its Business Partners Program to bring TV advertising into the platforms brands already use for their media buying. These Campaign Management partners can embed TV activation into their workflows, so advertisers can easily include TV alongside search, social, and other digital channels without switching tools or adding another step to the process.

As an API-first, MCP (Model Context Protocol)-enabled platform, Universal Ads was built to help digital marketers extend their brands to TV advertising regardless of how they buy. Advertisers can build, launch, optimize, and measure campaigns through the Universal Ads Manager, MCP integrations, Universal Ads API, and now through partners that have integrated Universal Ads buying directly into their own platforms.

> “Advertisers should not have to change the way they work in order to add TV to their media plans,” said Daniel Druger, VP of Product at Universal Ads. “With Campaign Management, we are making it possible for TV to show up in the same places marketers already plan, activate, and optimize campaigns. This could start by asking a partner's agent to build a plan across search, social and TV, using retail data to reach a TV audience from the same platform, or turning measurement insights into the next TV campaign without moving into a separate buying workflow.”

Campaign Management launch partners include Adlyse, Atrium, Concord, Kochava, Koddi, Olyzon, Orbee, Scale Up, SearchKings, Stellair AI, Topsort, and WorkMagic with additional partners to come. Many of these partners are familiar to Universal Ads clients because of their partnership in other categories like creative, measurement, mobile measurement, and more. These companies represent a range of platforms including agentic buying, creative-led buying, measurement-driven buying solutions, commerce and retail media platforms, and agency tools that help advertisers connect TV to the broader ways they plan and manage media.

> "Adding Universal Ads gives advertisers on Topsort-powered retail media networks a new offsite channel, so they can extend their campaigns to premium TV and reach shoppers at more points along the purchase journey, without leaving the workflow they already use," says Joe Connolly, Sales Engineer at Topsort.

> "TV has been the white whale for a lot of marketers who know it can perform, it's just difficult to prove. Our integration with Universal Ads not only lets brands understand the true return of their CTV spend, they can either act on those insights directly from our platform, or they can leverage our AI Agents to automatically optimize based on true incremental impact. Today's marketer needs to move faster than ever, and our expanded partnership with UA allows them to do exactly that," says Frank Yang, CEO @ WorkMagic.

By working with industry-leading partners across categories — from agentic and creative-led buying to commerce, retail media, measurement and agency tools — Universal Ads is helping reduce friction, drive better performance and make TV advertising easier to activate within the systems marketers use every day.

**FAQS**

*   **What is Campaign Management, and who are the launch partners?**Campaign Management is a new category in the Universal Ads Business Partners Program. Partners embed TV activation into their own platforms, so advertisers can add TV alongside search, social, and other digital channels without switching tools. Launch partners are Adlyse, Atrium, Concord, Kochava, Koddi, Olyzon, Orbee, Scale, SearchKings, Stellair AI, Topsort, and WorkMagic, with more to come. They cover agentic buying, creative-led buying, measurement-driven buying, commerce and retail media platforms, and agency tools. 

*   **What can advertisers do with a Campaign Management partner?** They can ask a partner's agent to build a plan across search, social, and TV. They can use retail data to reach a TV audience from the same platform. They can also turn measurement insights into the next TV campaign without moving to a separate buying workflow. 

*   **Do advertisers have to buy through a partner?** No. Advertisers can build, launch, optimize, and measure campaigns through Universal Ads Manager, MCP integrations, the Universal Ads API, or partner platforms that have integrated Universal Ads buying. 

*   **What does "API-first and MCP-enabled" mean?** Universal Ads was built so digital marketers can reach TV however they buy. Partners and developers connect through the Universal Ads API and Marketing API, which support automating campaigns, reporting, and attribution. MCP integrations let AI agents and tools work with Universal Ads. 

*   **What does it cost to use Universal Ads?** Universal Ads has no markups, no upfront commitment, and no contracts. 

*   **What is Universal Ads?** Universal Ads is Comcast Advertising's self-service platform. Brands of any size use it to create, buy, and measure TV and premium video ads directly from top publishers. Advertisers choose a goal, audience, and spend, and measure results from awareness to conversions.
