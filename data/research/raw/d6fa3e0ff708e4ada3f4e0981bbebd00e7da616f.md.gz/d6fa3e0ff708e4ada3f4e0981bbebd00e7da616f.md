Title: 6 strategies for harnessing travel and tourism marketing

URL Source: https://www.stackadapt.com/resources/blog/travel-and-tourism-marketing

Published Time: 2022-11-25T15:52:00+00:00

Markdown Content:
Travel is back, and it’s [coming back strong](https://www.entrepreneur.com/living/this-is-what-travel-will-look-like-in-a-post-pandemic-world/377253). Since 2020, [US digital ad spend](https://www.statista.com/statistics/235955/online-ad-spending-of-the-us-leisure-travel-industry/) has been steadily increasing year over year. In 2023, it’s projected that spend will reach $4.54 billion USD, a 12% increase from 2022.

For travel marketers, this growth signals that it’s time for a fresh tourism marketing strategy. To help you build a programmatic strategy for travel that drives results, we’re unpacking the latest trends in the industry, and sharing top-of-mind travel and tourism marketing strategies.

## Travel and tourism trends

It’s clear that the [travel revival](https://www.travelpulse.com/opinions/column/pandemic-travel-revival.html) has started. Across the industry, there have been positive signs, from [increasing traffic in US airports](https://www.tsa.gov/coronavirus/passenger-throughput) to [growing ad spend](https://www.statista.com/statistics/235955/online-ad-spending-of-the-us-leisure-travel-industry/). Let’s dive into some of those travel and tourism marketing trends in detail.

### Domestic tourism is booming

Although international destinations also account for a large amount of US consumer spending on travel, it’s important not to forget about domestic travellers. Americans go on over 2.29 billion domestic trips every year!

In fact, [one study](https://passport-photo.online/blog/domestic-tourism/) found that 96% of the survey respondents took (or planned to take) at least one domestic leisure trip in 2022. And, 80% of those respondents described their most recent local travel experience as positive or very positive.

### Consumers are looking to travel with purpose

Travellers are becoming increasingly value driven, which is influencing their decisions when purchasing travel products and services. [Seventy-two percent](https://www.americanexpress.com/en-us/travel/discover/get-inspired/global-travel-trends) of travellers are looking to have a positive impact and support communities and businesses through tourism.

Sixty-nine percent of consumers said they are more mindful of choosing hotels and airlines that align with their values and support diversity and inclusion within their workforce. Travellers are also becoming more [eco-friendly](https://www.americanexpress.com/en-us/travel/discover/get-inspired/global-travel-trends) and many are looking to support airline brands that are sustainable (68%) and carbon negative (55%).

### Personalized experiences are for travellers, too

Consumers are increasingly expecting [personalized marketing experiences](https://www.stackadapt.com/resources/blog/personalizing-your-digital-marketing-strategy) at every touch point through the marketing funnel, from their first exposure to a brand, all the way to their post-purchase experience.

This is relevant across all industries, including travel and tourism marketing. Personalized marketing in travel is now a must-have. [According to Skift](https://skift.com/wp-content/uploads/2014/09/Skift-Boxever-The_Future-of-Personalized-Marketing.pdf), That personalized touch can drive increased conversion rates and revenue, and improve customer loyalty.

## 6 travel and tourism marketing strategies

Here are 6 travel and tourism marketing strategies that will help map out your next travel campaign.

### 1. Use geotargeting to reach nearby consumers

[Geotargeting](https://www.stackadapt.com/resources/blog/mapping-out-your-geotargeting-strategy) is the practice of delivering content to a consumer—via mobile or web—using the geographic location information of the recipient. For travel and tourism marketing, it’s the perfect strategy for tapping into the booming domestic tourism market.

For example, if a destination marketing organization (DMO) based in Nevada wants to attract travellers from their neighbour state, California, they can leverage [geofencing](https://www.stackadapt.com/resources/blog/what-is-geofencing) to capture the attention of people located there. Geofencing targets users based on the geographic location information of the recipient. This tactic draws a virtual fence around a geographic location, so that users who enter that “fenced” area are served your ads.

You can target audiences using location data like country, state, postal or zip code, or even a specific address. If you’re looking to attract domestic consumers, geotargeting is one strategy that will help you remind travellers of what’s in their own backyard.

### 2. Use video to entice consumers to book

Travel is an emotional experience for consumers. Therefore, leveraging a channel that speaks to that emotion is a great way to capture the interest of your target audience. [Video](https://www.stackadapt.com/video-advertising) is particularly effective for travel because it’s an engaging and immersive medium that uses visual cues to create emotion in viewers.

Travel brands can use [video advertising](https://www.stackadapt.com/resources/blog/programmatic-video-advertising) to engage viewers with storytelling and showcase the experiences that they are offering. By engaging a viewer’s emotion, your video may entice them to book a weekend getaway at your hotel, or travel to your resort for the gorgeous beaches. When you run your video campaign on [connected TV](https://www.stackadapt.com/resources/blog/introduction-to-connected-tv) (CTV), you can capture and hold user attention particularly well because CTV provides a natural, full-screen experience.

Ads shown on CTV are highly viewable, and are served in an environment in which the audience is already engaged. When watching a connected TV device, viewers understand and accept that ads are part of the viewing experience.

Knowing this, they are more receptive to them. These benefits combined with CTV’s enhanced targeting options and inventory selection are just part of why we’re seeing CTV overtake linear ad spend. For travel marketers, CTV is the perfect channel for delivering video ads that will entice consumers to book travel.

### 3. Appeal to the audiences through eye-catching creative

Video is a fantastic channel for emotionally engaging consumers, but all formats of ad creative have a similar effect. Your campaign’s messaging, regardless of the medium, plays an important role in capturing the interest of your target audience. Build creatives that resonate with your target audience, so you can attract the travellers who are most likely to engage with your campaign.

When running a travel campaign, use your ads to grab the interest of your audience by showing content that is relevant to them. For example, target users in cold geographic regions with images that show warm and sunny destinations. Hook your target demographic in the first few seconds by using language that speaks to them, intrigues them, or spurs an emotional response.

### 4. Leverage contextual advertising to reach the right audience

[Contextual targeting](https://www.stackadapt.com/resources/blog/behavioural-vs-contextual) in travel and tourism marketing can enable you to reach audiences who are ready to travel. This targeting tactic uses algorithms to place ads based on keywords, website content, and other metadata. This way, users are targeted based on the environment in which an ad appears, which places focus on the consumer’s current frame of mind to show an ad that is hyper relevant.

Capturing an audience that is currently receptive to travel is the key to success. For example, by using contextual advertising to target content like, “best destinations in 2023,” you can reach travellers who are planning to travel soon, or planning to travel in the near future. To reach the people who are considering travel, make sure to first engage with those who are most interested—they will be more likely to book a trip.

### 5. Measure travel advertising results with a brand lift study

[Brand lift studies](https://www.stackadapt.com/resources/blog/brand-lift-studies) go beyond traditional metrics, like impressions, to help you measure a travel campaign’s impact on [consumer perceptions and behaviour](https://www.stackadapt.com/resources/blog/how-agencies-thrive-podcast-episode-11/). A brand lift study measures the impact of your campaigns across all your programmatic channels, typically providing a picture of the consumer sentiment and brand affinity of people who have been exposed to your media.

For travel marketing, it can be used to measure the impact of upper funnel campaigns on your consumers’ perception of your brand. Or, leverage it to measure consideration or purchase intent in the mid- to lower funnel.

Let’s say a hotel chain has just launched its first marketing campaign around a new hotel perk. The chain runs a brand lift study to understand whether their target audience is interested in the new offering. The study can discover how likely travellers are to pay more for access to the hotel perk, as well as the perception a consumer has about the chain after seeing an ad that mentions it.

### 6. Use messaging to highlight the value of your offering

Messaging in your travel marketing campaigns is your best tool for letting consumers know _why_ they should book with you. In travel and tourism marketing, it can be leveraged to build consumer confidence, as well as to personalize. It’s your opportunity to share what makes your offering stand out.

For example, if an airline offers a flexible rebooking policy, this should be highlighted in their digital campaigns. This way, airlines can capture the interest of hesitant travellers. The knowledge that an airline offers flexibility builds consumer trust, and may be the deciding factor for that consumer who might be on the fence.

For personalization, consider what it is about your offering that will appeal to specific target audiences. For example, resorts that are eco-friendly should highlight this within their messaging. Let your audience know what the resort is doing that aligns with their values. With so many consumers looking to travel with purpose, this could be the deciding factor in making a purchase decision.

## Use case: How to reach beach goers

A resort in a sunny destination wants to attract beach goers. Here’s how this resort could use a combination of the above travel advertising strategies to reach their target audience.

*   Leverage a video campaign to engage viewers with storytelling and showcase the experiences that the resort offers. Imagery of the resort will engage a viewer’s emotion, and entice them to book a vacation so that they can experience what they’ve seen in the video.
*   Incorporate into the campaign messaging that addresses common travel concerns. Build the trust of beach goers by highlighting a flexible rebooking policy, resort features, and more.
*   Incorporate creatives that targets users with video of a sunny, hot, beach, while targeting users in warmer climates with creatives of breezy ocean. By tailoring the creative based on geographic location, the campaign will appeal to the desires of consumers according to their customer profile.
*   Use contextual targeting to capture an audience that is currently receptive to a beach vacation. To reach beach goers, target content like, “best beach vacations 2023.” That way, the campaign reaches consumers who are actually eager to go on vacation, or are receptive to the idea of a beach vacation in the near future.

## Travel and tourism marketing is going places

Are your travel and tourism marketing campaigns ready to take flight? To keep up with the current trends in travel, be sure to leverage strategies that reach the right audiences, at the right moment. That could mean using geotargeting to attract domestic travellers, or crafting messaging that aligns your offering with consumer values. The key is to test your strategies until you find the perfect mix.

StackAdapt is partnered with Adara, the leader in travel data, to offer solutions for travel campaigns, including unique audiences, insights and targeting.

Want to get started with travel and tourism marketing? [Request a demo](https://www.stackadapt.com/get-started) to learn more about our travel solutions.
