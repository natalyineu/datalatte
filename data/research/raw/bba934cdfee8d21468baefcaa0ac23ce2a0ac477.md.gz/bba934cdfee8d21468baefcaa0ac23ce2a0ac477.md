Title: How big is the CTV advertising market? (Q1 2026)

URL Source: https://adwave.com/resources/ctv-advertising-market-size-q1-2026

Published Time: 2026-04-28T00:00:00+00:00

Markdown Content:
*   $37.95B

U.S. CTV ad spending forecast for 2026

*   +14.5%

YoY CTV ad spending growth 2025 to 2026

*   2028

Year CTV projected to surpass linear TV ad spend

Connected TV advertising is one of the fastest-growing major advertising categories in U.S. media. eMarketer's December 2025 forecast projects U.S. CTV ad spending to reach $37.95 billion in 2026, up 14.5% year-over-year from $33.35 billion in 2025. The category is on pace to surpass linear TV advertising by 2028.

For small business advertisers, the scale of the CTV market affects what inventory is available, how easy it is to buy, and what CPMs look like. A $37.95 billion market is no longer emerging: it is a core category of U.S. advertising and will continue growing for the foreseeable future.

This post breaks down the CTV advertising market size in Q1 2026 based on eMarketer's publicly published forecast, and translates the data into practical implications for local advertisers.

## What the data shows

Based on eMarketer's December 2025 CTV advertising forecast:

![Image 1: CTV Advertising Market Size Q1 2026 - Body1](https://media.adwave.com/fia320z3blxi/5nr02AEcP4AP2YpFsSVKY5/4a6cd2393b42030b7170350f5e46fa4d/body1.png)
*   **2025 U.S. CTV ad spending:** $33.35 billion (actual)

*   **2026 U.S. CTV ad spending forecast:** $37.95 billion (projected, +14.5% YoY)

*   **2028 projection:** $46.89 billion (forecast to surpass linear TV ad spending)

*   **2029 projection:** Approximately $51 billion

*   **Growth rate trajectory:** Moderating from ~14.5% in 2026 toward ~11% by 2029 as the category matures

CTV's projected 14.5% 2026 growth rate is faster than other major advertising categories per eMarketer's comparable forecasts. Growth is driven by continued migration of TV viewing to streaming, expanding ad-tier subscribers on major SVOD platforms (especially Netflix and Disney+), and deeper integration of programmatic buying infrastructure.

Industry reporting in early 2026 highlighted several specific drivers, including the NBA's rights move to Prime Video (starting October 2025 season) adding meaningful new CTV inventory, continued growth of Netflix's ad tier, and 2026 as a U.S. midterm election year driving political CTV advertising.

## What "CTV advertising" means

Connected TV (CTV) advertising refers to video ads delivered to television screens through an internet connection, rather than through traditional broadcast, cable, or satellite distribution. The "connected" in CTV means the TV is connected to the internet, typically through a smart TV, a streaming device (Roku, Apple TV, Amazon Fire TV, Chromecast, etc.), a game console, or a cable/streaming hybrid box.

CTV advertising includes:

*   **Ads on subscription streaming services with ad tiers.** Netflix's Basic with Ads, Hulu's ad tier, Disney+'s ad tier, Peacock Premium's ads, Max's Basic with Ads, Paramount+'s ad tier, and Amazon Prime Video's ad layer.

*   **Ads on free ad-supported streaming TV (FAST) services.** Tubi, Roku Channel, Pluto TV, Freevee, and similar platforms that are free to viewers and entirely ad-supported.

*   **Ads on YouTube when watched on TV screens.** YouTube viewing delivered through smart TVs, streaming devices, or game consoles counts as CTV.

*   **Ads on virtual MVPD services.** YouTube TV, Hulu + Live TV, Sling TV, FuboTV all deliver live TV content through streaming infrastructure.

*   **Ads on broadcast OTT feeds.** When broadcast network programming streams through an app (Peacock's NBC content, Paramount+'s CBS content, the broadcast networks' own apps), the ads that appear count as CTV.

CTV advertising is distinct from:

*   **Online video advertising** on desktop or mobile (not watched on a TV screen)

*   **Traditional TV advertising** delivered through linear broadcast, cable, or satellite without internet connection

*   **Social video advertising** on mobile devices in apps like Instagram, TikTok, or Facebook

The $37.95 billion 2026 forecast specifically measures CTV as defined above. When advertisers buy CTV, they're buying video ad impressions on television screens delivered through streaming infrastructure.

## Why the market scale matters for your business

The $37.95 billion CTV market size matters to small business advertisers in three practical ways.

![Image 2: CTV Advertising Market Size Q1 2026 - Body2](https://media.adwave.com/fia320z3blxi/3NHU8gjm2NkgWyjq98RQHz/6f1962a76a6abce468345b742b28d2a0/body2.png)
**First, inventory is abundant.** The scale of the market means CTV advertising inventory is widely available across hundreds of streaming platforms. Local advertisers rarely encounter scarcity at typical small-business budget levels.

**Second, the category's growth drives infrastructure investment.** Major CTV platforms are investing in AI-driven targeting, cross-platform measurement, shoppable ad formats, and programmatic tools. Small business advertisers benefit from these improvements without needing to build them.

**Third, supply growth supports moderate CPMs.** Supply in FAST (free ad-supported) and mid-tier SVOD has grown faster than advertiser demand for some segments, keeping CPMs in those tiers relatively flat. Premium placements (live sports, tentpole programming on Netflix, Hulu, Prime) continue to command premium pricing.

## How CTV advertising is bought

There are three main buying mechanisms in the CTV market:

**Programmatic (auction-based):** The largest share of CTV buying. Advertisers use demand-side platforms (DSPs) like The Trade Desk, Google DV360, Amazon DSP, or others to bid on CTV impressions in real time. Programmatic offers the widest reach, flexible targeting, and efficient pricing but requires expertise to operate effectively.

**Direct (negotiated):** Advertisers negotiate directly with CTV platform sales teams for specific placements, packages, or audience commitments. Direct buying is typical for large brands, premium content adjacencies, and major events. Minimum commitments are generally high.

**Bundled self-serve platforms:** Third-party platforms aggregate access across multiple streaming services and provide a simplified buying interface. Small businesses use these platforms to run multi-platform CTV campaigns without managing multiple vendor relationships.

For most small business local advertisers, bundled self-serve platforms are the appropriate entry point. Direct buying generally requires budgets starting in five figures. Programmatic through major DSPs requires internal expertise. Bundled platforms lower the entry point to $50-$500 per month and abstract the complexity.

## Who's spending on CTV

Advertisers on CTV span every major industry category. Industry reporting consistently identifies these as significant CTV advertiser categories:

*   **Quick-service restaurants and food and beverage:** Heavy CTV users given broad demographic targeting

*   **Auto manufacturers and dealers:** Significant CTV spending for vehicle launches and local dealer advertising

*   **Consumer packaged goods (CPG):** Major category given broad household reach

*   **Financial services:** Banking, insurance, investment services

*   **Retail (national and local):** Seasonal and evergreen campaigns

*   **Entertainment and media:** Movie studios, upcoming series promotions, concert announcements

*   **Healthcare and pharma:** DTC pharma, healthcare systems, telehealth services

*   **Travel and hospitality:** Airlines, hotels, destinations

*   **Direct-to-consumer brands:** Mattresses, fitness equipment, food delivery, subscription services

*   **Local services:** Home services, professional services, healthcare, automotive

Small business participation has grown meaningfully as self-serve CTV platforms have lowered entry barriers. The category mix at small business scale differs from national brand mix: local service businesses (home services, healthcare, auto, restaurants) represent a larger share of small business CTV spending than their share of national CTV spending.

## How to take advantage

Knowing the CTV market is $37.95 billion is useful. Turning that into specific campaign decisions is where the wins happen.

*   **Allocate 10-25% of total marketing budget to CTV.** If you're currently spending nothing on CTV, you're likely under-allocating relative to where your customer's attention is.

*   **Prioritize multi-platform CTV over single-platform.** Access to 100+ streaming apps through one buy beats fragmented buys on individual platforms.

*   **Test FAST platforms for cost efficiency.** Tubi, Roku Channel, Pluto TV deliver generally lower CPMs than premium streamers.

*   **Add live sports inventory for surge events.** NFL on Prime, NBA on Prime, Peacock Olympics all represent targeted surge opportunities.

*   **Track measurement maturity.** CTV measurement has improved dramatically. Current tools provide attribution, reach/frequency, and incrementality analysis that rivals traditional TV.

*   **Budget for creative refresh.** CTV campaigns burn out faster than linear TV because of tighter frequency caps. Plan quarterly creative rotation.

The most common mistake small business advertisers make with CTV is treating it as a single category. CTV is dozens of distinct advertising opportunities (YouTube, Netflix, Hulu, Peacock, Prime Video, FAST platforms, live sports, etc.) each with different audiences, CPMs, and targeting capabilities. Bundled CTV platforms simplify this by aggregating access, but knowing the underlying landscape helps you evaluate whether your platform choices match your goals.

## Measuring CTV campaign performance

CTV measurement has matured significantly in recent years. Current capabilities include:

*   **Household-level reach and frequency:** How many unique households saw the ad and how many times on average.

*   **View-through rate (VTR):** The percentage of ads that viewers watched to completion. CTV VTR is generally very high (90%+) because most CTV ad placements are non-skippable.

*   **Brand lift measurement:** Changes in brand awareness, consideration, or preference among audiences exposed to the ad versus control groups.

*   **Attribution to downstream outcomes:** Website visits, store visits, app installs, or sales among audiences exposed to the campaign. Typically measured through pixel-based tracking or data-room integrations.

*   **Incrementality testing:** The lift in outcomes specifically attributable to CTV advertising versus what you would have gotten from other channels.

*   **Cross-device measurement:** Linking CTV ad exposure to subsequent actions on mobile or desktop devices.

Small business CTV campaigns typically focus on reach, frequency, VTR, and branded-search lift as core metrics. Incrementality and cross-device attribution are usually reserved for larger campaigns with dedicated measurement budgets.

## The bigger picture

CTV's $37.95 billion 2026 forecast reflects the maturation of streaming TV as an advertising category. The rapid growth of the past several years has brought CTV to mainstream scale.

Several structural drivers point to continued growth:

**Audience migration continues.** Nielsen reported streaming at 47.0% of total U.S. TV viewing in January 2026, a record high. As viewing time shifts to streaming, advertising dollars follow.

**Measurement and targeting improve.** CTV now supports audience targeting, frequency capping, and attribution that match or exceed linear TV capabilities. That makes CTV more attractive to advertisers who want measurable outcomes.

**Corporate restructuring accelerates streaming investment.** Comcast spun off cable networks into Versant in late 2025. Warner Bros. Discovery is exploring similar separation. These moves reflect strategic prioritization of streaming.

**Small and local advertisers are entering CTV at growing rates.** Self-serve CTV platforms have reduced the entry-point minimum from traditional $50,000+ commitments to campaigns starting at $50. That expanded advertiser base is bringing new spending into the category.

## What this forecast doesn't tell you

EMarketer's $37.95 billion projection is a useful planning anchor, but has limitations:

*   **Forecasts are not guarantees.** The December 2025 forecast reflects expectations as of that date. Economic conditions, platform changes, or unexpected events can move the actual result up or down.

*   **Aggregate market size doesn't indicate your campaign's cost.** The total market is the sum of thousands of advertisers' spending. Your specific costs depend on your targeting, timing, and competition in your audience segment.

*   **Growth rates vary by segment.** FAST is growing differently than premium SVOD, which grows differently than YouTube CTV. The 14.5% aggregate growth rate masks meaningful variation.

*   **National advertiser growth may not equal local advertiser growth.** Small and local CTV advertising is growing from a smaller base and may not track the aggregate rate precisely.

Advertisers should use the forecast for directional planning rather than precise budgeting decisions.

## Common questions answered

**Is the $37.95 billion number U.S. only or global?**

U.S. only. Global CTV advertising is larger. The U.S. accounts for a majority share of global CTV spending in 2026. International CTV markets are growing faster on a percentage basis from smaller bases.

**How does CTV advertising spending compare to linear TV?**

Linear TV (combined broadcast and cable) advertising is currently larger than CTV advertising in total dollars, but linear is declining while CTV is growing. eMarketer projects CTV to surpass linear TV ad spending in 2028.

**What percentage of CTV spending is small business?**

Small and local businesses are a growing share of CTV spending but still a minority of the total. Large national brands remain the primary CTV ad spenders. The small business share has grown meaningfully since self-serve CTV platforms lowered entry points.

**What are the biggest CTV advertising platforms by spend?**

YouTube, Hulu (Disney), Prime Video, and Netflix are consistently among the largest individual CTV platforms for advertiser spending. Platform-level advertiser spending figures are generally not published publicly at quarterly precision; industry analysts publish estimates.

**Is CTV advertising effective for small local businesses?**

For businesses with appropriate customer match, yes. Local service businesses (home services, auto, healthcare, restaurants, retail) and family-targeted products tend to see strong CTV performance. Campaigns as small as $500-$1,000 monthly can generate measurable results in most DMAs.

**What happens to CTV CPMs as the market grows?**

Supply and demand dynamics vary by tier. Premium SVOD CPMs have generally been stable or slightly increasing. FAST platform CPMs have been stable or slightly declining as supply has grown faster than demand. YouTube CTV CPMs have remained relatively moderate.

**Will CTV continue to grow at 14.5% annually?**

EMarketer's December 2025 forecast shows growth moderating from the 14-15% range in 2026 toward 11% by 2029 as the category matures. The direction is consistent strong growth, with rates slowing as the category scales.

**Do I need a separate budget for CTV or can it come from existing TV budget?**

Many advertisers fund CTV from existing TV budget (shifting from cable or broadcast). Others carve CTV from digital budget. Some create a dedicated CTV line. The right approach depends on how you account for marketing spend internally. The important thing is that CTV gets enough budget to generate meaningful reach, which typically means at least $500 per month for local campaigns.

## Where to start

The CTV advertising market at $37.95 billion in 2026 is no longer emerging. For small businesses that haven't allocated to CTV, the scale of the market and the ease of access through self-serve platforms make it a practical starting point.

![Image 3: CTV Advertising Market Size Q1 2026 - Body3](https://media.adwave.com/fia320z3blxi/2Ua5TDoXWVv4baNWCbwL1s/d651faece81c7572bd5ad5b089a0a965/body3.png)
Start with a 30-60 day test. Use a bundled CTV platform that covers multiple streaming services. Measure brand lift and downstream conversion over the test window. Adjust allocation based on results.

Adwave lets local advertisers participate in the CTV market with campaigns starting at $50, providing access to 100+ premium streaming channels including YouTube, Netflix, Hulu, Peacock, Prime Video, Tubi, and Roku Channel through a single self-serve platform. [See how it works](https://adwave.com/how-it-works).
