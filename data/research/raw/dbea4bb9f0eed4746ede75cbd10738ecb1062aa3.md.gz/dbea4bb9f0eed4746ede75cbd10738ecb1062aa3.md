Title: Women working in tech share their experiences in the industry

URL Source: https://www.stackadapt.com/resources/blog/women-working-in-tech-2023

Published Time: 2023-03-08T13:58:58+00:00

Markdown Content:
On March 8 of every year, International Women’s Day is celebrated all around the world. The day is about acknowledging the social, economic, cultural, and political achievements of women, and bringing awareness and attention to the barriers that women continue to face.

According to [Deloitte Insights](https://www2.deloitte.com/us/en/insights/industry/technology/women-tech-leadership.html), women in tech are gaining ground as the tech industry makes slow, but steady progress toward shrinking its gender gap. A [growing body of research](https://www.forbes.com/sites/forbesinsights/2020/01/15/diversity-confirmed-to-boost-innovation-and-financial-results/?sh=9466296c4a6a) is finding that diverse teams perform better and are more innovative.

According to Deloitte’s estimates, women’s share in the overall global-tech workforce has increased 6.9% from 2019 to 2022, while their share in technical roles has grown by 11.7%. Notably, the fastest growth has been in leadership positions. The percentage of women in leadership roles has grown by nearly 20% in the last three years.

This International Women’s Day, we’re highlighting women in tech from various StackAdapt teams to learn how they got into the industry, have been able to grow their career, and words of wisdom to those starting out in tech.

### Saleha Azmi – business development representative

Something I had to learn as I got into my tech career was how important it is to trust the process. I’m an impatient person who wants results right away. But the reality is, it can take time to learn, and that’s okay. Being a student, and learning, is an important aspect of all jobs, so don’t rush it.

Mentorship is also crucial for women working in tech. A mentor is somebody who is invested in you and your future growth. In my experience, a mentor will provide you with objective viewpoints that help you to become more self-aware, and to grow.

### Carly Foy – director of sales, North America

One thing I personally struggled with when I started out in the tech space was vocalizing my thoughts. It’s funny because I actually am an outgoing person! In the workplace, it wasn’t that I was worried about rejection, it was more so that I was worried someone would think I wasn’t smart enough to be there. I had ideas, but was scared of sharing them, and so I often kept them to myself.

Throughout my career I’ve learned that you should share your ideas whether they are good or bad. If an idea isn’t any good, a team can just move on. But some of the ideas you have may be great, and so if you don’t share them, your team can miss out on great opportunities.

Don’t be scared of the word no. It’s not the end of the world if someone says no to you, just move on and think of your next idea, and make sure to share that idea as well. That next idea could be a total game changer.

### Mira Rawady – digital marketing and social media specialist

Being your own cheerleader is so important. Nobody knows your capabilities like you do. Being a woman in tech, or in any male-dominated industry, takes having confidence in yourself without the need for validation from others. So, that job you think you’re underqualified for? Apply for it. That meeting you’re excited to attend? Make sure your voice is heard without waiting for anyone to give you permission.

As you advance in your career, I think it’s important to keep track of all your wins. Whether you use them to show how great a candidate you are, or just as something to remind yourself of all the incredible things you’ve achieved. I personally keep a folder on my desktop called “WINS,” where I save any screenshots or files that represent anything I’ve accomplished that I’m proud of—big or small.

### Nadine Winkler – senior procurement specialist in operations

Something my mom used to say when I was growing up was “less talk, more action.” I think for women who want to work in tech, it’s important to seek out the companies that are doing exactly that.

The best way that companies can foster inclusive environments is simple. Hire women, promote women, and give women the tools that are needed to be successful. A big gap in diversity, equity, and inclusion right now is that we aren’t seeing enough women in leadership positions. It’s fundamentally important that companies tackle this by actively bringing in women for high-level positions.

For women who are applying for jobs in tech, it’s important to look at the structure of the company. Take a look at whether women there are in higher-level positions, and whether women have the support and mentorship needed to progress their careers.

### Gazel Shah – sales manager

The way I take on challenges, especially as a woman in tech, is by focusing on how I approach them from a mindset perspective. I like to think about the three “B’s.” The first “B” stands for “believe in yourself.” Do your best to feel comfortable in your own skin and your skills.

The second “B” is to “be kind.” Being kind to yourself, as well as others, will only help you grow in your career. Community and mentorship is so important and kindness will help support that. The last “B” stands for “be there.” This means being present, aware, and engaged with your team and your workplace.

Ready to explore a career in adtech? See our open roles and apply,[here](https://job-boards.greenhouse.io/stackadapt?departments%5B%5D=4009596009).
