Title: Devin: the autonomous software engineer

URL Source: https://devin.ai/

Markdown Content:
[We're giving enterprises $100M+ in credits to fix critical vulnerabilities with Claude Mythos. Terms apply. Apply now →$100M+ in Devin Security credits. Terms and conditions apply. Apply now →$100M+ in Devin Security credits. Apply →](https://devin.ai/security)

*   Product
*   Solutions
*   Resources

[Get a demo](https://devin.ai/demo)[Log in](https://app.devin.ai/login)[Get started](https://app.devin.ai/auth/signup)

# Meet Devin, your team's autonomous software engineer

Devin runs in the cloud or on your machine, tests in its own browser, and won't stop until the PR is ready to merge

[Get started](https://app.devin.ai/auth/signup)[Book a demo](https://devin.ai/demo)

![Image 4](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fhorizontal%2Fhorizontal-04.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 5](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-06.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 6](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fsquare%2Fsquare-04.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 7](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-05.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 8](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-03.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 9](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-08.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 10](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fhorizontal%2Fhorizontal-07.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 11](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fhorizontal%2Fhorizontal-05.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 12](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-02.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 13](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-04.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 14](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fhorizontal%2Fhorizontal-02.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 15](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fsquare%2Fsquare-02.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 16](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fsquare%2Fsquare-03.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 17](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fhorizontal%2Fhorizontal-01.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 18](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fhorizontal%2Fhorizontal-03.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 19](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fhorizontal%2Fhorizontal-06.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 20](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-02.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 21](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-07.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 22](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fhorizontal%2Fhorizontal-03.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 23](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-01.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 24](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fhorizontal%2Fhorizontal-07.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 25](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-08.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 26](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-04.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 27](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fsquare%2Fsquare-02.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 28](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-06.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 29](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fsquare%2Fsquare-04.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 30](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fhorizontal%2Fhorizontal-02.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 31](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fsquare%2Fsquare-03.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 32](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fhorizontal%2Fhorizontal-04.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 33](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-05.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 34](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fhorizontal%2Fhorizontal-05.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 35](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcollage%2Fvertical%2Fvertical-03.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

New session

Automations

Security

Review

Wiki

More

Sessions

Pinned 3

Add enterprise SSO

Add multi-region failover

Upgrade Node.js across services

Investigate API latency spike

Patch vulnerable dependencies

Fix failing checkout tests

Review authentication changes

Expand payment test coverage

Document service architecture

More

Participated 12

Review API changes

Optimize database queries

Fix failing checkout tests

More

![Image 36](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fhero%2Favatar-kenzo.webp&w=64&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Kenzo Park Cognition

Add enterprise SSO

XL

![Image 37](https://devin.ai/assets/images/new-home/hero/slack.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 38](https://devin.ai/assets/images/new-home/hero/linear.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Add SAML SSO for enterprise customers.

Follow our existing auth patterns and let admins configure it in organization settings. Keep email login working for everyone else.

Explored authentication across 3 repositories

Implemented SSO and organization settings+13-1

![Image 39](https://devin.ai/assets/images/new-home/proactive-issues/devin.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Devin 8:05 PM

Here’s the PR. Enterprise admins can now configure SSO in organization settings, and members can sign in through their identity provider.

I tested setup, sign-in, and account linking in the browser. Existing email login still works, and all checks pass.

Tested sign-in and account linking in the browser 5 tests passed

feat: Add SAML SSO for enterprise

acme/platform #2922·+9-14

![Image 40](https://devin.ai/assets/images/new-home/hero/github.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

View PR

Added to the PR. Admins can require SSO once setup is verified. I also added tests for enforcement and recovery access.

Plan a feature, fix bugs, or perform a security scan

Ultra

PR Open·acme/platform #2922

Add enterprise SSO

![Image 41](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Freview%2Favatar.png&w=32&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)bwhuffman

main enterprise-sso

12 files changed+8-14

![Image 42](https://devin.ai/assets/images/new-home/review/analysis.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)Devin’s analysis

Adds SAML single sign-on for enterprise organizations. Admins can configure their identity provider, verify the connection, and require SSO from organization settings.

Test recording on Mac OS X virtual environment

2/5

![Image 43](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Freview%2Frecording.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

New session

Automations

Security

Review

Wiki

More

Sessions

Pinned 3

Add enterprise SSO

Add multi-region failover

Upgrade Node.js across services

Investigate API latency spike

Patch vulnerable dependencies

Fix failing checkout tests

Review authentication changes

Expand payment test coverage

Document service architecture

More

Participated 12

Review API changes

Optimize database queries

Fix failing checkout tests

More

![Image 44](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fhero%2Favatar-kenzo.webp&w=64&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Kenzo Park Cognition

Add enterprise SSO

XL

![Image 45](https://devin.ai/assets/images/new-home/hero/slack.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 46](https://devin.ai/assets/images/new-home/hero/linear.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Add SAML SSO for enterprise customers.

Follow our existing auth patterns and let admins configure it in organization settings. Keep email login working for everyone else.

Explored authentication across 3 repositories

Implemented SSO and organization settings+13-1

![Image 47](https://devin.ai/assets/images/new-home/proactive-issues/devin.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Devin 8:05 PM

Here’s the PR. Enterprise admins can now configure SSO in organization settings, and members can sign in through their identity provider.

I tested setup, sign-in, and account linking in the browser. Existing email login still works, and all checks pass.

Tested sign-in and account linking in the browser 5 tests passed

feat: Add SAML SSO for enterprise

acme/platform #2922·+9-14

![Image 48](https://devin.ai/assets/images/new-home/hero/github.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

View PR

Added to the PR. Admins can require SSO once setup is verified. I also added tests for enforcement and recovery access.

Plan a feature, fix bugs, or perform a security scan

Ultra

PR Open·acme/platform #2922

Add enterprise SSO

![Image 49](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Freview%2Favatar.png&w=32&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)bwhuffman

main enterprise-sso

12 files changed+8-14

![Image 50](https://devin.ai/assets/images/new-home/review/analysis.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)Devin’s analysis

Adds SAML single sign-on for enterprise organizations. Admins can configure their identity provider, verify the connection, and require SSO from organization settings.

Test recording on Mac OS X virtual environment

2/5

![Image 51](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Freview%2Frecording.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 52: OpenRouter](https://devin.ai/images/customer-logos/openrouter.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 53: Modal](https://devin.ai/images/customer-logos/modal.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/modal)

![Image 54: Gamma](https://devin.ai/images/customer-logos/gamma.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 55: Citi](https://devin.ai/images/customer-logos/citi.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 56: Reducto](https://devin.ai/images/customer-logos/reducto.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/reducto)

[![Image 57: Mercor](https://devin.ai/images/customer-logos/mercor.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/mercor)

![Image 58: Mercedes](https://devin.ai/images/customer-logos/mercedes.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 59: AngelList](https://devin.ai/images/customer-logos/angellist.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/angellist)

![Image 60: Fox](https://devin.ai/images/customer-logos/fox.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 61: NVIDIA](https://devin.ai/images/customer-logos/nvidia.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 62: RV Tech](https://devin.ai/images/customer-logos/rivian-vw.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/rvtech)

![Image 63: AT&T](https://devin.ai/images/customer-logos/att.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 64: Profound](https://devin.ai/images/customer-logos/profound.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 65: Rohlik Group](https://devin.ai/images/customer-logos/rohlik.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/rohlikgroup)

![Image 66: Cloudflare](https://devin.ai/images/customer-logos/cloudflare.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 67: Lowe's](https://devin.ai/images/customer-logos/lowes.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 68: Exa](https://devin.ai/images/customer-logos/exa.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/exa)

[![Image 69: Wayfair](https://devin.ai/images/customer-logos/wayfair.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/wayfair)

![Image 70: Elevance Health](https://devin.ai/images/customer-logos/elevance.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 71: OpenRouter](https://devin.ai/images/customer-logos/openrouter.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 72: Modal](https://devin.ai/images/customer-logos/modal.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/modal)

![Image 73: Gamma](https://devin.ai/images/customer-logos/gamma.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 74: Citi](https://devin.ai/images/customer-logos/citi.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 75: Reducto](https://devin.ai/images/customer-logos/reducto.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/reducto)

[![Image 76: Mercor](https://devin.ai/images/customer-logos/mercor.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/mercor)

![Image 77: Mercedes](https://devin.ai/images/customer-logos/mercedes.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 78: AngelList](https://devin.ai/images/customer-logos/angellist.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/angellist)

![Image 79: Fox](https://devin.ai/images/customer-logos/fox.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 80: NVIDIA](https://devin.ai/images/customer-logos/nvidia.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 81: RV Tech](https://devin.ai/images/customer-logos/rivian-vw.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/rvtech)

![Image 82: AT&T](https://devin.ai/images/customer-logos/att.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 83: Profound](https://devin.ai/images/customer-logos/profound.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 84: Rohlik Group](https://devin.ai/images/customer-logos/rohlik.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/rohlikgroup)

![Image 85: Cloudflare](https://devin.ai/images/customer-logos/cloudflare.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 86: Lowe's](https://devin.ai/images/customer-logos/lowes.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 87: Exa](https://devin.ai/images/customer-logos/exa.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/exa)

[![Image 88: Wayfair](https://devin.ai/images/customer-logos/wayfair.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/wayfair)

![Image 89: Elevance Health](https://devin.ai/images/customer-logos/elevance.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 90: OpenRouter](https://devin.ai/images/customer-logos/openrouter.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 91: Modal](https://devin.ai/images/customer-logos/modal.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/modal)

![Image 92: Gamma](https://devin.ai/images/customer-logos/gamma.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 93: Citi](https://devin.ai/images/customer-logos/citi.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 94: Reducto](https://devin.ai/images/customer-logos/reducto.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/reducto)

[![Image 95: Mercor](https://devin.ai/images/customer-logos/mercor.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/mercor)

![Image 96: Mercedes](https://devin.ai/images/customer-logos/mercedes.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 97: AngelList](https://devin.ai/images/customer-logos/angellist.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/angellist)

![Image 98: Fox](https://devin.ai/images/customer-logos/fox.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 99: NVIDIA](https://devin.ai/images/customer-logos/nvidia.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 100: RV Tech](https://devin.ai/images/customer-logos/rivian-vw.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/rvtech)

![Image 101: AT&T](https://devin.ai/images/customer-logos/att.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 102: Profound](https://devin.ai/images/customer-logos/profound.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 103: Rohlik Group](https://devin.ai/images/customer-logos/rohlik.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/rohlikgroup)

![Image 104: Cloudflare](https://devin.ai/images/customer-logos/cloudflare.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 105: Lowe's](https://devin.ai/images/customer-logos/lowes.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 106: Exa](https://devin.ai/images/customer-logos/exa.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/exa)

[![Image 107: Wayfair](https://devin.ai/images/customer-logos/wayfair.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/wayfair)

![Image 108: Elevance Health](https://devin.ai/images/customer-logos/elevance.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 109: OpenRouter](https://devin.ai/images/customer-logos/openrouter.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 110: Modal](https://devin.ai/images/customer-logos/modal.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/modal)

![Image 111: Gamma](https://devin.ai/images/customer-logos/gamma.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 112: Citi](https://devin.ai/images/customer-logos/citi.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 113: Reducto](https://devin.ai/images/customer-logos/reducto.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/reducto)

[![Image 114: Mercor](https://devin.ai/images/customer-logos/mercor.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/mercor)

![Image 115: Mercedes](https://devin.ai/images/customer-logos/mercedes.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 116: AngelList](https://devin.ai/images/customer-logos/angellist.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/angellist)

![Image 117: Fox](https://devin.ai/images/customer-logos/fox.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 118: NVIDIA](https://devin.ai/images/customer-logos/nvidia.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 119: OpenRouter](https://devin.ai/images/customer-logos/openrouter.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 120: Modal](https://devin.ai/images/customer-logos/modal.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/modal)

![Image 121: Gamma](https://devin.ai/images/customer-logos/gamma.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 122: Citi](https://devin.ai/images/customer-logos/citi.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 123: Reducto](https://devin.ai/images/customer-logos/reducto.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/reducto)

[![Image 124: Mercor](https://devin.ai/images/customer-logos/mercor.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/mercor)

![Image 125: Mercedes](https://devin.ai/images/customer-logos/mercedes.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 126: AngelList](https://devin.ai/images/customer-logos/angellist.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/angellist)

![Image 127: Fox](https://devin.ai/images/customer-logos/fox.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 128: NVIDIA](https://devin.ai/images/customer-logos/nvidia.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 129: OpenRouter](https://devin.ai/images/customer-logos/openrouter.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 130: Modal](https://devin.ai/images/customer-logos/modal.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/modal)

![Image 131: Gamma](https://devin.ai/images/customer-logos/gamma.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 132: Citi](https://devin.ai/images/customer-logos/citi.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 133: Reducto](https://devin.ai/images/customer-logos/reducto.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/reducto)

[![Image 134: Mercor](https://devin.ai/images/customer-logos/mercor.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/mercor)

![Image 135: Mercedes](https://devin.ai/images/customer-logos/mercedes.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 136: AngelList](https://devin.ai/images/customer-logos/angellist.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/angellist)

![Image 137: Fox](https://devin.ai/images/customer-logos/fox.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 138: NVIDIA](https://devin.ai/images/customer-logos/nvidia.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 139: RV Tech](https://devin.ai/images/customer-logos/rivian-vw.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/rvtech)

![Image 140: AT&T](https://devin.ai/images/customer-logos/att.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 141: Profound](https://devin.ai/images/customer-logos/profound.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 142: Rohlik Group](https://devin.ai/images/customer-logos/rohlik.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/rohlikgroup)

![Image 143: Cloudflare](https://devin.ai/images/customer-logos/cloudflare.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 144: Lowe's](https://devin.ai/images/customer-logos/lowes.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 145: Exa](https://devin.ai/images/customer-logos/exa.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/exa)

[![Image 146: Wayfair](https://devin.ai/images/customer-logos/wayfair.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/wayfair)

![Image 147: Elevance Health](https://devin.ai/images/customer-logos/elevance.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 148: RV Tech](https://devin.ai/images/customer-logos/rivian-vw.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/rvtech)

![Image 149: AT&T](https://devin.ai/images/customer-logos/att.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 150: Profound](https://devin.ai/images/customer-logos/profound.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 151: Rohlik Group](https://devin.ai/images/customer-logos/rohlik.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/rohlikgroup)

![Image 152: Cloudflare](https://devin.ai/images/customer-logos/cloudflare.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 153: Lowe's](https://devin.ai/images/customer-logos/lowes.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 154: Exa](https://devin.ai/images/customer-logos/exa.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/exa)

[![Image 155: Wayfair](https://devin.ai/images/customer-logos/wayfair.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/wayfair)

![Image 156: Elevance Health](https://devin.ai/images/customer-logos/elevance.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 157: RV Tech](https://devin.ai/images/customer-logos/rivian-vw.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/rvtech)

![Image 158: AT&T](https://devin.ai/images/customer-logos/att.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 159: Profound](https://devin.ai/images/customer-logos/profound.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 160: Rohlik Group](https://devin.ai/images/customer-logos/rohlik.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/rohlikgroup)

![Image 161: Cloudflare](https://devin.ai/images/customer-logos/cloudflare.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 162: Lowe's](https://devin.ai/images/customer-logos/lowes.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

[![Image 163: Exa](https://devin.ai/images/customer-logos/exa.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/exa)

[![Image 164: Wayfair](https://devin.ai/images/customer-logos/wayfair.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/customers/wayfair)

![Image 165: Elevance Health](https://devin.ai/images/customer-logos/elevance.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

## Your teammate’s favorite teammate

![Image 166](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fgraphic-backgrounds%2Fvellum-blur-2.webp&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 167](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Ffully-verified%2Fselecting-seat.jpg&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 168](https://devin.ai/assets/images/new-home/fully-verified/select-cursor.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Selecting seat

![Image 169](https://devin.ai/assets/images/new-home/fully-verified/scrubber.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Devin’s computer

Flag enabled; mobile viewport on enterprise child org

![Image 170](https://devin.ai/assets/images/new-home/fully-verified/previous.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 171](https://devin.ai/assets/images/new-home/fully-verified/next.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Testing 3/12

0:24

![Image 172](https://devin.ai/assets/images/new-home/fully-verified/check.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)
Ensure compatibility across various screen sizes and maintain usability features

0:36

![Image 173](https://devin.ai/assets/images/new-home/fully-verified/check.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)
Incorporate accessibility guidelines to enhance user experience for all

0:24

![Image 174](https://devin.ai/assets/images/new-home/fully-verified/check.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)
Render in light and dark themes

0:24

![Image 175](https://devin.ai/assets/images/new-home/fully-verified/loading.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)
Test for offline mode

0:30

![Image 176](https://devin.ai/assets/images/new-home/fully-verified/loading.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)
Loading screen improvement

0:45

![Image 177](https://devin.ai/assets/images/new-home/fully-verified/loading.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)
User feedback integration

1:00

![Image 178](https://devin.ai/assets/images/new-home/fully-verified/pending.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)
Sync error handling

1:15

![Image 179](https://devin.ai/assets/images/new-home/fully-verified/pending.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)
Data retrieval optimization

1:30

![Image 180](https://devin.ai/assets/images/new-home/fully-verified/pending.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)
Offline data storage enhancement

2:15

![Image 181](https://devin.ai/assets/images/new-home/fully-verified/pending.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)
Real-time analytics integration

3:00

![Image 182](https://devin.ai/assets/images/new-home/fully-verified/pending.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)
User interface optimization

### Tests end to end on its own computer

Devin spins up its own Windows, Mac, and Linux virtual machines as needed to build, test in its browser, and record itself clicking through what it built

![Image 183](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Ffrontier-models%2Fbackground-1.jpg&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 184](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Ffrontier-models%2Fbackground-2.png&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 185](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Ffrontier-models%2Fbackground-3.png&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 186](https://devin.ai/assets/images/new-home/frontier-models/search.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)Search all models

Fusion

Ultra

Normal

Lite

![Image 187](https://devin.ai/assets/images/new-home/frontier-models/divider.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

All models

![Image 188](https://devin.ai/assets/images/new-home/frontier-models/cognition.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)SWE-2

![Image 189](https://devin.ai/assets/images/new-home/frontier-models/claude.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)Fable 5.1

![Image 190](https://devin.ai/assets/images/new-home/frontier-models/openai.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)GPT-6 Astra

![Image 191](https://devin.ai/assets/images/new-home/frontier-models/grok.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)Grok 4.7

![Image 192](https://devin.ai/assets/images/new-home/frontier-models/gemini.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)Gemini 3.8 Flash

Fusion

Pairs frontier intelligence with cost-efficient execution

Lead Claude Fable 5.1![Image 193](https://devin.ai/assets/images/new-home/frontier-models/chevron-down.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Effort High![Image 194](https://devin.ai/assets/images/new-home/frontier-models/chevron-down.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Sidekick SWE-2 Medium![Image 195](https://devin.ai/assets/images/new-home/frontier-models/chevron-down.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Fast mode![Image 196](https://devin.ai/assets/images/new-home/frontier-models/toggle.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 197](https://devin.ai/assets/images/new-home/frontier-models/model-cost.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)Fusion

![Image 198](https://devin.ai/assets/images/new-home/frontier-models/model-cursor.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

### Gets the best from every frontier model

Access frontier performance for up to 60% less. Devin mixes and matches models to get the most from each

![Image 199](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fgraphic-backgrounds%2Fbg-2.jpg&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Sessions

![Image 200](https://devin.ai/assets/images/new-home/repeated-delivery/plus.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 201](https://devin.ai/assets/images/new-home/repeated-delivery/settings.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 202](https://devin.ai/assets/images/new-home/repeated-delivery/more.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Weekly dependency upgrades

1 min

![Image 203](https://devin.ai/assets/images/new-home/repeated-delivery/pull-request.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)1![Image 204](https://devin.ai/assets/images/new-home/repeated-delivery/closed.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)1

![Image 205](https://devin.ai/assets/images/new-home/repeated-delivery/timeslot.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Upgrade React to 19.2

PR is ready

![Image 206](https://devin.ai/assets/images/new-home/repeated-delivery/pull-request.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)1![Image 207](https://devin.ai/assets/images/new-home/repeated-delivery/merged.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)1

Bump Next.js to 16.3

PR is ready

![Image 208](https://devin.ai/assets/images/new-home/repeated-delivery/pull-request.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)1![Image 209](https://devin.ai/assets/images/new-home/repeated-delivery/merged.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)1

Architecture rewrite

Working·56 hours·![Image 210](https://devin.ai/assets/images/new-home/repeated-delivery/timeslot.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Notification panel UX

Review PR

![Image 211](https://devin.ai/assets/images/new-home/repeated-delivery/pull-request.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)1

Refactor artifact library

1 min

![Image 212](https://devin.ai/assets/images/new-home/repeated-delivery/pull-request.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)1

Update CSS styles for mobile responsiveness

5 min

![Image 213](https://devin.ai/assets/images/new-home/repeated-delivery/merged.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)1

Optimize images for faster loading

3 min

![Image 214](https://devin.ai/assets/images/new-home/repeated-delivery/merged.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)1

Architecture rewrite

XL

![Image 215](https://devin.ai/assets/images/new-home/repeated-delivery/slack.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 216](https://devin.ai/assets/images/new-home/automate/linear.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 217](https://devin.ai/assets/images/new-home/repeated-delivery/clock.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 218](https://devin.ai/assets/images/new-home/repeated-delivery/pr-purple.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

J

![Image 219](https://devin.ai/assets/images/new-home/code-test/slack.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Jin Park

8:05 PM

Hello there

I want to build a mobile webapp

Rewrite the notification inbox architecture to simplify state management, component boundaries, and data flow while preserving all existing user-facing behavior.

Worked for 1 min

+13-1

![Image 220](https://devin.ai/assets/images/new-home/proactive-issues/devin.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Devin

8:05 PM

Hey! I have this cool idea can you help me create an awesome snake game for my portfolio? Like those ones you use to play on the old Nokia phones? I’ve attached some reference pics

generic-file.txt

321 KB

### Keeps working when your laptop is closed

Delegate a big task, then Devin splits it across parallel cloud agents, manages them, and reports back

![Image 221](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fgraphic-backgrounds%2Fbg-6.jpg&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

#eng-bugs

![Image 222](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fjoins-thread%2Fjin.png&w=64&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Jin Park 11:55

The API is returning duplicate results when loading the next page.@Devin can you help fix this?

👀1

![Image 223](https://devin.ai/assets/images/new-home/joins-thread/devin.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Devin 11:55

Fixed it and added a regression test.  
Here’s the PR: #1934 Duplicate content

![Image 224](https://devin.ai/assets/images/new-home/joins-thread/devin-small.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 225](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fjoins-thread%2Fjin.png&w=48&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 226](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fjoins-thread%2Fparticipant-1.png&w=48&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 227](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fjoins-thread%2Fparticipant-2.png&w=48&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Devin is working...

### Joins the thread when you @Devin

Tag @Devin in Slack, Teams, and more. Devin reads the thread, responds to follow-ups, and gets to work

![Image 228](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fgraphic-backgrounds%2Fbg-3.jpg&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 229](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fproactive-issues%2Fpagerduty-background.png&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

PagerDuty 8:05 PM

🔴 High severity: Elevated error rate in api-server. Error rate exceeded 8% following the latest deployment.

![Image 230](https://devin.ai/assets/images/new-home/proactive-issues/devin.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Devin 8:05 PM

I found the errors were introduced by the latest deployment to api-server. I’m reproducing the failure and preparing a fix.

![Image 231](https://devin.ai/assets/images/new-home/proactive-issues/chevron-right.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)Worked for 1 min

+13-1

fix: handle null user in api-server auth middleware

![Image 232](https://devin.ai/assets/images/new-home/code-test/pull-request.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)acme-api #30146·

+13-1

View PR

### Watches for issues and fixes them proactively

Set up automations so Devin handles bugs, failed CI, and other alerts as they land

## From problem to merged PR,  
Devin gets hard engineering work done.

01

### Understand and plan

Map the codebase and systems architecture accurately and efficiently. Devin updates diagrams and code maps as quickly as the codebase changes

![Image 233](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fgraphic-backgrounds%2Fvellum-blur-2.webp&w=1920&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 234](https://devin.ai/assets/images/new-home/understand-plan/connector-left.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 235](https://devin.ai/assets/images/new-home/understand-plan/connector-right.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 236](https://devin.ai/assets/images/new-home/understand-plan/connector-center.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Getting Started

Overview

![Image 237](https://devin.ai/assets/images/new-home/understand-plan/divider.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Purpose and scope

Technology stack

Application architecture

MyApp Component Wrapper

File-based routing structure

Homepage structure

Core dependencies

Key dependency roles

Global styling system

Typography system

Layout utilities

Custom components

Font loading

Metadata & SEO management

System architecture

Core agent framework

Jobs and schedules

DBT integration

Client library

AI integration

Identity and organization data

Lifecycle email system

MCP

Web framework integration

Example and guides

Development and deployment

Overview

Evalon supports three distinct authentication methods.

Password Validation

User enters password in ChoosePassword

Check Biometrics Availability

Proceed without Biometrics

Display Error Message

User chooses Biometrics

Valid

Invalid

Not Available / User declines

Available

Key features

Password sign-in: ChoosePassword validates the password against the policy in auth/passwordRules.ts before creating a session.

Biometric unlock: After a valid password, users can enroll Face ID or fingerprint; BiometricGate checks device support first.

Graceful fallback: When biometrics are unavailable or declined, sign-in continues with the password and the choice is stored per device.

Single sign-on: Enterprise orgs authenticate through SAML or OIDC via SsoProvider, which maps identity claims to organization roles.

Note: Session tokens are refreshed by AuthProvider and revoked on sign-out across all three methods.

Tech Stack

Authentication is built on React Native with Expo LocalAuthentication for biometrics, secure token storage in the device keychain, and a Node.js auth service that issues short-lived JWTs backed by refresh tokens.

![Image 238](https://devin.ai/assets/images/new-home/understand-plan/github.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

aws

backend-api

Synced just now

![Image 239](https://devin.ai/assets/images/new-home/understand-plan/gitlab.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

gitlab

marketing-site

12s ago

![Image 240](https://devin.ai/assets/images/new-home/understand-plan/github.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

aws

infrastructure

Synced just now

02

### Code and test

Delegate to Devin Cloud, iterate in Desktop or CLI, or tag @Devin. Wherever you work, Devin gives you the best of all frontier models

![Image 241](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fgraphic-backgrounds%2Fbg-5.jpg&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 242](https://devin.ai/assets/images/new-home/code-test/video.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)iOS Finance app 2 passed

![Image 243](https://devin.ai/assets/images/new-home/code-test/chain-link.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 244](https://devin.ai/assets/images/new-home/code-test/arrow-up-right.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 245](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcode-test%2Frecording-base.png&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 246](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcode-test%2Frecording-desktop.png&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 247](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fcode-test%2Frecording-phone.png&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

J

![Image 248](https://devin.ai/assets/images/new-home/code-test/slack.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Jin Park 8:05 PM

Add bulk actions to the table. Support labeling,  
and archiving, and test the flows end-to-end.

![Image 249](https://devin.ai/assets/images/new-home/proactive-issues/devin.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Devin 8:05 PM

Implemented bulk actions and verified all three flows in the browser. Added tests for selection, permissions, and error handling.

Here’s the PR. All tests are passing, ready for review.

![Image 250](https://devin.ai/assets/images/new-home/proactive-issues/chevron-right.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)Worked for 1 min·18 tests passed

+13-1

feature: Add bulk actions to the transaction table

![Image 251](https://devin.ai/assets/images/new-home/code-test/pull-request.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)acme-mobile #30146·

+9-14

View pull request

03

### Review

Devin Review finds bugs and vulnerabilities before they reach production. Assign Devin to fix in one click

![Image 252](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fgraphic-backgrounds%2Fbg-1.jpg&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 253](https://devin.ai/assets/images/new-home/review/pull-request.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)Open

Add session attribution UI

![Image 254](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Freview%2Favatar.png&w=32&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)bwhuffman

main![Image 255](https://devin.ai/assets/images/new-home/review/arrow-left.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)devin/USA-938-176594

12 files

+8-14

![Image 256](https://devin.ai/assets/images/new-home/review/analysis.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)Devin’s analysis

The ComparePage fetches job details for two batches to display a comparison table. Previously, all jobs were fetched in a single query:

`const gulp = require('gulp');const util = require('./build/lib/util');const path = require('path');const compilation = require('./build/lib/compilation');// Fast compile for development timegulp.task('clean-client', util.rimraf('out'));gulp.task('compile-client', ['clean-client'], compilation.compileTask('out', false));gulp.task('watch-client', ['clean-client'], compilation.watchTask('out', false));`
This caused double-fetching: when batch2 arrived after batch1, allJobIds changed, invalidating the cache and refetching all jobs including batch1's. The fix uses useQueries to cache each job independently, so only new job IDs trigger fetches.

3 stacked

![Image 257](https://devin.ai/assets/images/new-home/review/stack-pr.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

#6481 Remove dead variables

+3-12

![Image 258](https://devin.ai/assets/images/new-home/review/stack-pr-settings.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

#6474 Update /settings routes to match session attribution UI

+72-28

![Image 259](https://devin.ai/assets/images/new-home/review/stack-pr-session.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

#6472 Add session attribution UI for scheduled Devins

+218-14

![Image 260](https://devin.ai/assets/images/new-home/review/branch-connector.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

main

![Image 261](https://devin.ai/assets/images/new-home/review/stack-divider.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

1 ready, 2 pending changes

![Image 262](https://devin.ai/assets/images/new-home/review/shield.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)1 vulnerability

![Image 263](https://devin.ai/assets/images/new-home/review/shield-outline-red.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

JWT signature check is skipped when the key is chased

Chain: a cached key plus an unvalidated alg header

![Image 264](https://devin.ai/assets/images/new-home/review/bug.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)2 bugs

![Image 265](https://devin.ai/assets/images/new-home/review/bug-outline.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Collapse toggle icon vanishes when you move the cursor onto it

AccountSwitcherContent.tsx:135

![Image 266](https://devin.ai/assets/images/new-home/review/bug-outline.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

DS examples not updated for new `onToggleChildSessions` and `isChildSessionsCollapsed` props

AccountSwitcherContent.tsx:135

![Image 267](https://devin.ai/assets/images/new-home/review/flag.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)3 flags

![Image 268](https://devin.ai/assets/images/new-home/review/flag-outline.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Left-side hover zone captures clicks on the title's leading text

AccountSwitcherContent.tsx:135

04

### Automate and maintain

Create scheduled workflows and trigger-based automations for repetitive work. Devin swarms can proactively find novel vulnerabilities, performance issues, and gaps in test coverage

![Image 269](https://devin.ai/_next/image?url=%2Fassets%2Fimages%2Fnew-home%2Fautomate%2Fbackground.jpg&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

“Every morning, find stale Linear tickets and  
clean them up or nudge the owner.”

Trigger

![Image 270](https://devin.ai/assets/images/new-home/automate/clock.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Every day at 9:00am

![Image 271](https://devin.ai/assets/images/new-home/automate/linear.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 272](https://devin.ai/assets/images/new-home/automate/connector.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

Issue in team engineering

and status is todo

Action

Review open issues with no activity in the last 14 days. Close any confirmed resolved by linked PRs, update outdated labels, and ask the owner for a status update on anything still outstanding.

## Connect once, deliver repeatedly  
with your favorite tools

[Triage bugs as they land](https://docs.devin.ai/integrations/slack)[Fix CI when it fails](https://docs.devin.ai/integrations/gh)[Investigate alerts as they fire](https://docs.devin.ai/product-guides/auto-triage#mcp-integrations)[Turn errors into fixes](https://docs.devin.ai/product-guides/auto-triage#mcp-integrations)[Triage issues when they get posted](https://docs.devin.ai/integrations/microsoft-teams)[Pick up issues as they're assigned](https://docs.devin.ai/integrations/linear)[Assign a ticket, get a PR](https://docs.devin.ai/integrations/jira)[Build from a spec page](https://docs.devin.ai/work-with-devin/mcp)

## Recently shipped

[ 01 ]

[![Image 273: Claude Mythos 5.2 is now available in Devin Security](https://devin.ai/_next/image?url=%2Fimages%2Fblog%2Fclaude-mythos-5-2-security%2Fcard.png&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 274](https://devin.ai/_next/image?url=%2Fimages%2Fblog%2Fgemini-4-carbon%2Fcover.png&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 275](https://devin.ai/_next/image?url=%2Fimages%2Fblog%2Fclaude-fable-5-2%2Fcover.png&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 276](https://devin.ai/_next/image?url=%2Fimages%2Fblog%2Fdevin-review-2%2Fcover.png&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 277](https://devin.ai/_next/image?url=%2Fimages%2Fblog%2Fhierarchical-budgets%2Fcover.png&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 278](https://devin.ai/_next/image?url=%2Fimages%2Fblog%2Fdevin-security-2%2Fcover.png&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)![Image 279](https://devin.ai/_next/image?url=%2Fimages%2Fblog%2Fvulnerability-fixes-plugin%2Fsecurity-blog-2.jpg&w=3840&q=75&dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)](https://devin.ai/blog/claude-mythos-5-2-security)

[11.11 Claude Mythos 5.2 is now available in Devin Security Product Read more](https://devin.ai/blog/claude-mythos-5-2-security)[11.10 Gemini 4 Carbon is now available in Devin Product Read more](https://devin.ai/blog/gemini-4-carbon)[11.09 Claude Fable 5.2 is now available in Devin Product Read more](https://devin.ai/blog/claude-fable-5-2)[11.05 Devin Review 2.0 Product Read more](https://devin.ai/blog/devin-review-2)[11.02 Hierarchical budgets: manage AI spend the way your company is organized Product Read more](https://devin.ai/blog/hierarchical-budgets)[10.26 Devin Security 2.0: Built for the new threat landscape Product Read more](https://devin.ai/blog/devin-security-2)[10.22 Fixing Critical Node & PHP Flaws Product Read more](https://devin.ai/blog/vulnerability-fixes-plugin)

## Enterprise security  
with fine-grained controls

![Image 280: SOC 2](https://devin.ai/assets/images/new-home/soc-2.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 281: ISO 27001](https://devin.ai/assets/images/new-home/iso-27001.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

![Image 282: FedRAMP](https://devin.ai/assets/images/new-home/fedramp.svg?dpl=dpl_FsaHkddKX1Jg66qWHHXnap1jQWa8)

*   Inputs and outputs are always your IP
*   Zero data retention enforced with model providers
*   Comprehensive audit logs

*   Every session runs in its own VM
*   RBAC / SSO / SCIM / OIDC
*   Private networking available

## Stop deprioritizing Do it all with Devin

[Get started](https://app.devin.ai/auth/signup)[Book a demo](https://devin.ai/demo)

[](https://devin.ai/)[](https://cognition.com/)

## Company

## Legal

## Connect

[We're giving enterprises $100M+ in credits to fix critical vulnerabilities with Claude Mythos. Terms apply. Apply now →$100M+ in Devin Security credits. Terms and conditions apply. Apply now →$100M+ in Devin Security credits. Apply →](https://devin.ai/security)

*   Product
*   Solutions
*   Resources

[Get a demo](https://devin.ai/demo)[Log in](https://app.devin.ai/login)[Get started](https://app.devin.ai/auth/signup)
