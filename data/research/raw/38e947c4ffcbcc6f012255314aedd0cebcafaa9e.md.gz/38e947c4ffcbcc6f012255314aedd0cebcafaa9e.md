Title: StackAdapt places no. 71 on the Globe and Mail’s fifth-annual ranking of Canada’s top growing companies

URL Source: https://www.stackadapt.com/resources/blog/stackadapt-canadas-top-growing-companies

Published Time: 2023-09-29T17:18:24+00:00

Markdown Content:
**Toronto, ON –****September 29, 2023****–**StackAdapt ([www.stackadapt.com](https://www.stackadapt.com/best-demand-side-platform-dsp)), the leading self-serve programmatic advertising platform, is pleased to announce it placed No. 71 on the 2023 Report on Business ranking of Canada’s Top Growing Companies.

Canada’s Top Growing Companies ranks Canadian companies on three-year revenue growth. StackAdapt earned its spot with three-year revenue growth of 601%.

StackAdapt is a self-serve programmatic advertising platform used by hundreds of brands and agencies around the world. Every day, the platform empowers digitally-focused companies to deliver outcomes and exceptional campaign performance. StackAdapt users can execute campaigns across a variety of channels and devices, reach tailored audiences, and find, track, and share important metrics.

“It’s an immense honour to be featured on The Globe and Mail’s list of Canada’s Top Growing Companies for the fifth year in a row,” said Vitaly Percherskiy, co-founder and COO of StackAdapt. “While we’ve grown considerably and globally since our first time listed, this recognition underscores our team’s relentless drive and our clients’ unwavering faith in our abilities.”

Canada’s Top Growing Companies is an editorial ranking that was launched in 2019. It aims to bring the accomplishments of innovative businesses in Canada to the forefront. In order to qualify for this voluntary program, companies had to complete an in-depth application process and fulfill requirements. In total, 425 companies earned a spot on this year’s ranking.

“Canada’s Top Growing Companies acknowledges the drive and ingenuity displayed by Canadian business,” says Dawn Calleja, Editor of Report on Business magazine. “This year’s ranking serves as an inspiration for future business owners.”

“This year’s Report on Business magazine’s list of Top Growing Companies shows how innovative ideas always rise to the top, perhaps even more so in times of uncertainty,” says Andrew Saunders, CEO of The Globe and Mail. “The Globe and Mail congratulates this year’s winners for meeting and surpassing those economic challenges.”

The full list of 2023 winners along with editorial coverage is published in the October issue of Report on Business magazine. The list is out now and online [here](https://www.theglobeandmail.com/business/rob-magazine/top-growing-companies/).

**About The Globe and Mail**

The Globe and Mail is Canada’s foremost news media company, leading the national discussion and causing policy change through brave and independent journalism since 1844. With our award-winning coverage of business, politics and national affairs, The Globe and Mail newspaper reaches 6.2 million readers every week in our print or digital formats, and Report on Business magazine reaches 2.7 million readers in print and digital every issue. Our investment in innovative data science means that as the world continues to change, so does The Globe. The Globe and Mail is owned by Woodbridge, the investment arm of the Thomson family.

### **About StackAdapt**

StackAdapt is a self-serve programmatic advertising platform used by hundreds of brands and agencies around the world. StackAdapt’s data-driven platform combines state-of-the-art machine learning with a clean and intuitive user interface to provide media buyers with an easy way to plan, execute and drive the best performance across all devices, inventory, and publishing partners. StackAdapt has been recognized as one of the fastest-growing technology companies in North America, is rated the number 1 demand-side platform (DSP) on G2, and is the highest performing and easiest to use platform. For further information, visit [www.stackadapt.com](https://www.stackadapt.com/).

**Media Contact**  
Luke Gillespie  
luke@purposenorthamerica.com
